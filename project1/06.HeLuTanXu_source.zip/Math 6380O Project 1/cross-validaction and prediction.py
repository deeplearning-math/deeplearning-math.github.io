# -*- coding: utf-8 -*-
"""
Created on Sat Feb 24 12:22:42 2018

@author: Thinkpad
"""

print(__doc__)
from time import time
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import offsetbox
from sklearn import (manifold, decomposition, ensemble,
                     discriminant_analysis, random_projection)
from sklearn.decomposition import PCA
from matplotlib import pyplot as plt
from matplotlib import font_manager
from sklearn.manifold import TSNE
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB



dataset = pd.read_csv('resnet18.txt',delim_whitespace=True,header =None)
dnp = dataset.drop(0,axis = 1).values


print dnp[33]



dnp2 = []

for i in range(10,20):
    
    dnp2.append(dnp[i])
    
dnp2.append(dnp[1])
dnp2.append(dnp[2])
dnp2.append(dnp[3])
dnp2.append(dnp[4])
dnp2.append(dnp[5])
dnp2.append(dnp[7])
dnp2.append(dnp[8])

dnp2.append(dnp[20])
dnp2.append(dnp[21])
dnp2.append(dnp[23])

for j in range(26,35):
    
    dnp2.append(dnp[j])
    
test1 = []

for a in range(9):
    
    test1.append(0)
    
for b in range(20):
    
    test1.append(1)
    



# Create classifiers
lr = LogisticRegression()
gnb = GaussianNB()
svc = LinearSVC(C=1.0)
rfc = RandomForestClassifier(n_estimators=100)





train_x = dnp2
test_x = train_x.pop(28)
train_y = test1
test_y = train_y.pop(28)  



result = []

for clf, name in [(lr, 'Logistic'),
                  (gnb, 'Naive Bayes'),
                  (svc, 'Support Vector Classification'),
                  (rfc, 'Random Forest')]:
    clf.fit(train_x, train_y)
    abc = clf.predict(test_x)
    result.append(abc)

print result


unlabled = []

unlabled.append(dnp[0])
unlabled.append(dnp[6])
unlabled.append(dnp[9])
unlabled.append(dnp[22])
unlabled.append(dnp[24])
unlabled.append(dnp[25])

for each in unlabled:
    
    prediction = []
    for clf, name in [(lr, 'Logistic'),
                  (gnb, 'Naive Bayes'),
                  (svc, 'Support Vector Classification'),
                  (rfc, 'Random Forest')]:
        
        clf.fit(dnp2, test1)
        abc = clf.predict(each)
        prediction.append(abc)
        
    print prediction


