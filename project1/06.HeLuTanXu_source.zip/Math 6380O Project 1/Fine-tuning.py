from keras.applications.resnet50 import ResNet50
from keras.preprocessing import image
import numpy as np
from skimage import transform
import matplotlib.pyplot as plt
from keras.applications.vgg16 import VGG16
from keras.applications.vgg16 import preprocess_input
import sys
sys.path.append('..')
import torch
from torch import nn
from torch.autograd import Variable
from torch.utils.data import DataLoader
from torchvision import models
from torchvision import transforms as tfs
from torchvision.datasets import ImageFolder
import os
from PIL import Image
from datetime import datetime
import torch.nn.functional as F
from torchvision.datasets import CIFAR10#最终要求分10类
from matplotlib import style

style.use('ggplot')

def conv3x3(in_channel, out_channel, stride=1):
    return nn.Conv2d(in_channel, out_channel, 3, stride=stride, padding=1, bias=False)

class residual_block(nn.Module):
    def __init__(self, in_channel, out_channel, same_shape=True):
        super(residual_block, self).__init__()
        self.same_shape = same_shape
        stride=1 if self.same_shape else 2
        
        self.conv1 = conv3x3(in_channel, out_channel, stride=stride)
        self.bn1 = nn.BatchNorm2d(out_channel)
        
        self.conv2 = conv3x3(out_channel, out_channel)
        self.bn2 = nn.BatchNorm2d(out_channel)
        if not self.same_shape:
            self.conv3 = nn.Conv2d(in_channel, out_channel, 1, stride=stride)
        
    def forward(self, x):
        out = self.conv1(x)
        out = F.relu(self.bn1(out), True)
        out = self.conv2(out)
        out = F.relu(self.bn2(out), True)
        
        if not self.same_shape:
            x = self.conv3(x)
        return F.relu(x+out, True)
    
class resnet(nn.Module):
    def __init__(self, in_channel, num_classes, verbose=False):
        super(resnet, self).__init__()
        self.verbose = verbose
        
        self.block1 = nn.Conv2d(in_channel, 64, 7, 2)
        
        self.block2 = nn.Sequential(
            nn.MaxPool2d(3, 2),
            residual_block(64, 64),
            residual_block(64, 64)
        )
        
        self.block3 = nn.Sequential(
            residual_block(64, 128, False),
            residual_block(128, 128)
        )
        
        self.block4 = nn.Sequential(
            residual_block(128, 256, False),
            residual_block(256, 256)
        )
        
        self.block5 = nn.Sequential(
            residual_block(256, 512, False),
            residual_block(512, 512),
            nn.AvgPool2d(3)
        )
        
        self.classifier = nn.Linear(512, num_classes)
        
    def forward(self, x):
        x = self.block1(x)
        if self.verbose:
            print('block 1 output: {}'.format(x.shape))
        x = self.block2(x)
        if self.verbose:
            print('block 2 output: {}'.format(x.shape))
        x = self.block3(x)
        if self.verbose:
            print('block 3 output: {}'.format(x.shape))
        x = self.block4(x)
        if self.verbose:
            print('block 4 output: {}'.format(x.shape))
        x = self.block5(x)
        if self.verbose:
            print('block 5 output: {}'.format(x.shape))
        x = x.view(x.shape[0], -1)
        x = self.classifier(x)
        return x

def data_tf(x):
    x = x.resize((96, 96), 2) # 将图片放大到 96 x 96
    x = np.array(x, dtype='float32') / 255
    x = (x - 0.5) / 0.5 # 标准化，这个技巧之后会讲到
    x = x.transpose((2, 0, 1)) # 将 channel 放到第一维，只是 pytorch 要求的输入方式
    x = torch.from_numpy(x)
    return x

def get_acc(output, label):
    total = output.shape[0]
    _, pred_label = output.max(1)
    num_correct = (pred_label == label).sum().data[0]
    return num_correct / total


def train(net, train_data, valid_data, num_epochs, optimizer, criterion):
    if torch.cuda.is_available():
        net = net.cuda()
    prev_time = datetime.now()
    for epoch in range(num_epochs):
        train_loss = 0
        train_acc = 0
        net = net.train()
        for im, label in train_data:
            if torch.cuda.is_available():
                im = Variable(im.cuda())  # (bs, 3, h, w)
                label = Variable(label.cuda())  # (bs, h, w)
            else:
                im = Variable(im)
                label = Variable(label)
            # forward
            output = net.forward(im)
            loss = criterion(output, label)
            # backward
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            train_loss += loss.data[0]
            train_acc += get_acc(output, label)

        cur_time = datetime.now()
        h, remainder = divmod((cur_time - prev_time).seconds, 3600)
        m, s = divmod(remainder, 60)
        time_str = "Time %02d:%02d:%02d" % (h, m, s)
        if valid_data is not None:
            valid_loss = 0
            valid_acc = 0
            net = net.eval()
            for im, label in valid_data:
                if torch.cuda.is_available():
                    im = Variable(im.cuda(), volatile=True)
                    label = Variable(label.cuda(), volatile=True)
                else:
                    im = Variable(im, volatile=True)
                    label = Variable(label, volatile=True)
                output = net.forward(im)
                print(output)
                loss = criterion(output, label)
                valid_loss += loss.data[0]
                valid_acc += get_acc(output, label)
            epoch_str = (
                "Epoch %d. Train Loss: %f, Train Acc: %f, Valid Loss: %f, Valid Acc: %f, "
                % (epoch, train_loss / len(train_data),
                   train_acc / len(train_data), valid_loss / len(valid_data),
                   valid_acc / len(valid_data)))
        else:
            epoch_str = ("Epoch %d. Train Loss: %f, Train Acc: %f, " %
                         (epoch, train_loss / len(train_data),
                          train_acc / len(train_data)))
        prev_time = cur_time
        print(epoch_str + time_str)
        
train_set = CIFAR10('./data', train=True, transform=data_tf)
train_data = torch.utils.data.DataLoader(train_set, batch_size=64, shuffle=True)
test_set = CIFAR10('./data', train=False, transform=data_tf)
test_data = torch.utils.data.DataLoader(test_set, batch_size=128, shuffle=False)

net = resnet(3, 10)
optimizer = torch.optim.SGD(net.parameters(), lr=0.01)
criterion = nn.CrossEntropyLoss()

train(net, train_data, test_data, 20, optimizer, criterion)

#after train net by CIFAR10, use fine-turning method to do Raphael
train_tf = tfs.Compose([
    tfs.RandomResizedCrop(96),
    tfs.RandomHorizontalFlip(),
    tfs.ToTensor(),
    tfs.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]) # 使用 ImageNet 的均值和方差
])

valid_tf = tfs.Compose([
    tfs.Resize(224),
    tfs.CenterCrop(96),
    tfs.ToTensor(),
    tfs.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])
# 使用 ImageFolder 定义数据集
train_set = ImageFolder('G:/Raphael Project final copy/train/', train_tf)
valid_set = ImageFolder('G:/Raphael Project final copy/val/', valid_tf)
# 使用 DataLoader 定义迭代器
train_data = DataLoader(train_set, 128, True, num_workers=0)
valid_data = DataLoader(valid_set, 128, False, num_workers=0)

net.classifier = nn.Linear(512, 2)        
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.SGD(net.parameters(), lr=1e-2, weight_decay=1e-4)


train(net, train_data, valid_data, 20, optimizer, criterion)

im1 = Image.open('G:/Raphael Project final copy/T/26.jpg')
im = valid_tf(im1) # 做数据预处理
out = net.forward(Variable(im.unsqueeze(0)).cuda())
pred_label = out.max(1)[1].data[0]
print('predict label: {}'.format(train_set.classes[pred_label]))

#then 不用迁移学习，看直接训练的结果
train_data = DataLoader(train_set, 128, True, num_workers=0)
valid_data = DataLoader(valid_set, 128, False, num_workers=0)
netnofine = resnet(3, 2)
optimizer = torch.optim.SGD(net.parameters(), lr=0.01)
criterion = nn.CrossEntropyLoss()
train(netnofine, train_data, valid_data, 20, optimizer, criterion)

#将精度数据可视化
ft_trainacc=[0.674375, 0.78125, 0.843125, 0.866875, 0.881875, 0.89375, 0.9, 0.915625, 0.919375, 0.9175,
             0.924375, 0.92625, 0.926875, 0.943125, 0.931875, 0.925625, 0.930625, 0.938125, 0.93625,
             0.943125]
ft_validacc=[0.755000, 0.845000, 0.805000, 0.806250, 0.888125, 0.824375, 0.902500, 0.814375, 0.881250,
             0.868125, 0.916875, 0.863125, 0.859375, 0.771250, 0.708125, 0.792500, 0.906250, 0.929375, 
             0.927500, 0.951875]
nft_trainacc=[ 0.559495, 0.573918, 0.569712, 0.571514, 0.558894, 0.563702, 0.542067, 0.567909, 0.567308,
               0.570913,  0.575120,  0.559495, 0.560697, 0.574519, 0.587740, 0.578125, 0.570312, 0.567909,
                0.576322, 0.564303]
nft_validacc=[0.579327, 0.579327, 0.600361, 0.584135, 0.577524, 0.564904, 0.559495, 0.554087, 0.555288,
              0.555889, 0.556490, 0.552284, 0.552885, 0.553486, 0.554688, 0.552284, 0.557692, 0.549880,
              0.576322, 0.554087]
epoch= [n for n in range(1, 21)]
plt.figure(figsize=(10,6))
plt.xlabel('epoch')
plt.ylabel('accuracy')
plt.title("train accuracy of fine-tuning and non-fine-tuning")
plt.plot(epoch, ft_trainacc,'red',linewidth=1.0, label="fine-tuning")
plt.plot(epoch, nft_trainacc,'blue',linewidth=1.0, label="non-fine-tuning")
plt.legend(loc='upper left')
plt.xticks(np.linspace(1,20,20,endpoint=True))
plt.show()

plt.figure(figsize=(10,6))
plt.xlabel('epoch')
plt.ylabel('accuracy')
plt.title("test accuracy of fine-tuning and non-fine-tuning")
plt.plot(epoch, ft_validacc,'red',linewidth=1.0, label="fine-tuning")
plt.plot(epoch, nft_validacc,'blue',linewidth=1.0, label="non-fine-tuning")
plt.legend(loc='upper left')
plt.xticks(np.linspace(1,20,20,endpoint=True))
plt.show()
