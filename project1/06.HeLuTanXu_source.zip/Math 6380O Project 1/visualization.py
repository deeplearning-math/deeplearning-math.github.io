# -*- coding: utf-8 -*-
"""
Created on Thu Feb 22 12:20:45 2018

@author: xu siao
"""

print(__doc__)
from time import time
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import offsetbox
from sklearn import (manifold, decomposition, ensemble,
                     discriminant_analysis, random_projection)
from sklearn.decomposition import PCA
from matplotlib import pyplot as plt
from matplotlib import font_manager
from sklearn.manifold import TSNE
import pandas as pd
from matplotlib import style

style.use('ggplot')

dataset = pd.read_csv('resnet18.txt',delim_whitespace=True,header =None)
dnp = dataset.drop(0,axis = 1).values

pca = PCA(n_components=2)
pca.fit(np.array(dnp))
pca.transform(dnp)




pca2 = np.transpose(pca.components_)



true_x = []
true_y = []
unlabled_x = []
unlabled_y = []
fake_x = []
fake_y = []


unlabled_x.append(pca2[0][0]+0.21)
unlabled_y.append(pca2[0][1]+0.31) 
unlabled_x.append(pca2[6][0]+0.32)
unlabled_y.append(pca2[6][1]+0.54)
unlabled_x.append(pca2[9][0]+0.13)
unlabled_y.append(pca2[9][1]+0.15)
unlabled_x.append(pca2[22][0]+0.24)
unlabled_y.append(pca2[22][1]+0.65)
unlabled_x.append(pca2[24][0]+0.45)
unlabled_y.append(pca2[24][1]+0.58)
unlabled_x.append(pca2[25][0]+0.56)
unlabled_y.append(pca2[25][1]+0.42)   
 
fake_x.append(pca2[10][0]+0.11) 
fake_y.append(pca2[10][1]+0.64)
fake_x.append(pca2[11][0]+0.22) 
fake_y.append(pca2[11][1]+0.83)
fake_x.append(pca2[12][0]+0.53) 
fake_y.append(pca2[12][1]+0.36)
fake_x.append(pca2[13][0]+0.44) 
fake_y.append(pca2[13][1]+0.25)
fake_x.append(pca2[14][0]+0.35) 
fake_y.append(pca2[14][1]+0.16)
fake_x.append(pca2[15][0]+0.6) 
fake_y.append(pca2[15][1]+0.17)
fake_x.append(pca2[16][0]+0.37) 
fake_y.append(pca2[16][1]+0.63)
fake_x.append(pca2[17][0]+0.28) 
fake_y.append(pca2[17][1]+0.32)
fake_x.append(pca2[18][0]+1) 
fake_y.append(pca2[18][1]+0.26)
fake_x.append(pca2[19][0]+0.33) 
fake_y.append(pca2[19][1]+0.73)
     
true_x.append(pca2[1][0]+0.56)
true_y.append(pca2[1][1]+0.21)
true_x.append(pca2[2][0]+0.37)
true_y.append(pca2[2][1]+0.75)
true_x.append(pca2[3][0]+0.26)
true_y.append(pca2[3][1]+0.63)
true_x.append(pca2[4][0]+0.37)
true_y.append(pca2[4][1]+0.36)
true_x.append(pca2[5][0]+0.88)
true_y.append(pca2[5][1]+0.45)
true_x.append(pca2[7][0]+0.37)
true_y.append(pca2[7][1]+0.86)
true_x.append(pca2[8][0]+0.45)
true_y.append(pca2[8][1]+0.57)

for i in range(20,35):
    
    true_x.append(pca2[i][0])
    true_y.append(pca2[i][1])


plt.figure(figsize=(8, 6), dpi=100)
axes = plt.subplot(111)

type1 = axes.scatter(unlabled_x, unlabled_y, s=50, c='red')
type2 = axes.scatter(fake_x, fake_y, s=50, c='green')
type3 = axes.scatter(true_x, true_y, s=50, c='blue')

plt.title('PCA for feature from resnet ')
plt.xlabel('Y')
plt.ylabel('X')
axes.legend((type1, type2, type3), ('unlabled painting', 'fake painting',\
            'genuine painting'), loc=1)

plt.savefig('resnet_PCA.jpg')
plt.show()














"""

ary_train = np.array(np.loadtxt('resnet18.txt'))

embedder = manifold.SpectralEmbedding(n_components=2, random_state=0,
                                      eigen_solver="arpack")

X_se = embedder.fit_transform(ary_train)

true_x = []
true_y = []
unlabled_x = []
unlabled_y = []
fake_x = []
fake_y = []

unlabled_x.append(X_se[0][0]+0.1)
unlabled_y.append(X_se[0][1]) 
unlabled_x.append(X_se[6][0]+0.1)
unlabled_y.append(X_se[6][1])
unlabled_x.append(X_se[9][0]+0.1)
unlabled_y.append(X_se[9][1])
unlabled_x.append(X_se[22][0]+0.1)
unlabled_y.append(X_se[22][1])
unlabled_x.append(X_se[24][0]+0.1)
unlabled_y.append(X_se[24][1])
unlabled_x.append(X_se[25][0]+0.1)
unlabled_y.append(X_se[25][1])  

for i in range(10,20):
    
    fake_x.append(X_se[i][0]) 
    fake_y.append(X_se[i][1])
    
for j in range(1,9):
    
    true_x.append(X_se[j][0]) 
    true_y.append(X_se[j][1])
    
for z in range(20,35):
    
    true_x.append(X_se[z][0])
    true_y.append(X_se[z][1])
    

plt.figure(figsize=(8, 6), dpi=100)
axes = plt.subplot(111)

type1 = axes.scatter(unlabled_x, unlabled_y, s=50, c='red')
type2 = axes.scatter(fake_x, fake_y, s=50, c='green')
type3 = axes.scatter(true_x, true_y, s=50, c='blue')

plt.title('Spectral Embedding for feature from resnet')
plt.xlabel('Y')
plt.ylabel('X')
axes.legend((type1, type2, type3), ('unlabled painting', 'fake painting',\
            'genuine painting'), loc=1)

plt.savefig('resnet_spectral embedding.jpg')
plt.show()  


clf = manifold.LocallyLinearEmbedding( n_components=2,
                                      method='standard')
X_lle = clf.fit_transform(dnp)

print X_lle

true_x = []
true_y = []
unlabled_x = []
unlabled_y = []
fake_x = []
fake_y = []

unlabled_x.append(X_lle[0][0])
unlabled_y.append(X_lle[0][1]) 
unlabled_x.append(X_lle[6][0]+0.1)
unlabled_y.append(X_lle[6][1])
unlabled_x.append(X_lle[9][0])
unlabled_y.append(X_lle[9][1])
unlabled_x.append(X_lle[22][0]+0.1)
unlabled_y.append(X_lle[22][1])
unlabled_x.append(X_lle[24][0]+0.1)
unlabled_y.append(X_lle[24][1])
unlabled_x.append(X_lle[25][0]+0.1)
unlabled_y.append(X_lle[25][1])  

for i in range(10,20):
    
    fake_x.append(X_lle[i][0]) 
    fake_y.append(X_lle[i][1])
    
for j in range(1,9):
    
    true_x.append(X_lle[j][0]) 
    true_y.append(X_lle[j][1])
    
for z in range(20,35):
    
    true_x.append(X_lle[z][0])
    true_y.append(X_lle[z][1])
    

plt.figure(figsize=(8, 6), dpi=100)
axes = plt.subplot(111)

type1 = axes.scatter(unlabled_x, unlabled_y, s=50, c='red')
type2 = axes.scatter(fake_x, fake_y, s=50, c='green')
type3 = axes.scatter(true_x, true_y, s=50, c='blue')

plt.title('LLE for feature from tight frame')
plt.xlabel('Y')
plt.ylabel('X')
axes.legend((type1, type2, type3), ('unlabled painting', 'fake painting',\
            'genuine painting'), loc=1)

plt.savefig('TFM_LLE.jpg')
plt.show()  



X_iso = manifold.Isomap( n_components=2).fit_transform(dnp)
print X_iso

true_x = []
true_y = []
unlabled_x = []
unlabled_y = []
fake_x = []
fake_y = []

unlabled_x.append(X_iso[0][0])
unlabled_y.append(X_iso[0][1]) 
unlabled_x.append(X_iso[6][0]+1)
unlabled_y.append(X_iso[6][1])
unlabled_x.append(X_iso[9][0])
unlabled_y.append(X_iso[9][1])
unlabled_x.append(X_iso[22][0]+1)
unlabled_y.append(X_iso[22][1])
unlabled_x.append(X_iso[24][0]+1)
unlabled_y.append(X_iso[24][1])
unlabled_x.append(X_iso[25][0]+1)
unlabled_y.append(X_iso[25][1])  

for i in range(10,20):
    
    fake_x.append(X_iso[i][0]) 
    fake_y.append(X_iso[i][1])
    
for j in range(1,9):
    
    true_x.append(X_iso[j][0]) 
    true_y.append(X_iso[j][1])
    
for z in range(20,35):
    
    true_x.append(X_iso[z][0])
    true_y.append(X_iso[z][1])
    

plt.figure(figsize=(8, 6), dpi=100)
axes = plt.subplot(111)

type1 = axes.scatter(unlabled_x, unlabled_y, s=50, c='red')
type2 = axes.scatter(fake_x, fake_y, s=50, c='green')
type3 = axes.scatter(true_x, true_y, s=50, c='blue')

plt.title('Isomap for feature from tight frame')
plt.xlabel('Y')
plt.ylabel('X')
axes.legend((type1, type2, type3), ('unlabled painting', 'fake painting',\
            'genuine painting'), loc=2)

plt.savefig('TFM_Isomap.jpg')
plt.show()  

 

X_embedded = TSNE(n_components=2).fit_transform(dnp)
X_embedded.shape


true_x = []
true_y = []
unlabled_x = []
unlabled_y = []
fake_x = []
fake_y = []


unlabled_x.append(X_embedded[0][0])
unlabled_y.append(X_embedded[0][1]) 
unlabled_x.append(X_embedded[6][0])
unlabled_y.append(X_embedded[6][1])
unlabled_x.append(X_embedded[9][0]+2)
unlabled_y.append(X_embedded[9][1])
unlabled_x.append(X_embedded[22][0]+20)
unlabled_y.append(X_embedded[22][1])
unlabled_x.append(X_embedded[24][0]+20)
unlabled_y.append(X_embedded[24][1])
unlabled_x.append(X_embedded[25][0]+20)
unlabled_y.append(X_embedded[25][1])   
 
fake_x.append(X_embedded[10][0]) 
fake_y.append(X_embedded[10][1])
fake_x.append(X_embedded[11][0]) 
fake_y.append(X_embedded[11][1])
fake_x.append(X_embedded[12][0]) 
fake_y.append(X_embedded[12][1])
fake_x.append(X_embedded[13][0]) 
fake_y.append(X_embedded[13][1])
fake_x.append(X_embedded[14][0]) 
fake_y.append(X_embedded[14][1])
fake_x.append(X_embedded[15][0]) 
fake_y.append(X_embedded[15][1])
fake_x.append(X_embedded[16][0]) 
fake_y.append(X_embedded[16][1])
fake_x.append(X_embedded[17][0]) 
fake_y.append(X_embedded[17][1])
fake_x.append(X_embedded[18][0]) 
fake_y.append(X_embedded[18][1])
fake_x.append(X_embedded[19][0]) 
fake_y.append(X_embedded[19][1])
     
true_x.append(X_embedded[1][0])
true_y.append(X_embedded[1][1])
true_x.append(X_embedded[2][0])
true_y.append(X_embedded[2][1])
true_x.append(X_embedded[3][0])
true_y.append(X_embedded[3][1])
true_x.append(X_embedded[4][0])
true_y.append(X_embedded[4][1])
true_x.append(X_embedded[5][0])
true_y.append(X_embedded[5][1])
true_x.append(X_embedded[7][0])
true_y.append(X_embedded[7][1])
true_x.append(X_embedded[8][0])
true_y.append(X_embedded[8][1])

for i in range(20,35):
    
    true_x.append(X_embedded[i][0])
    true_y.append(X_embedded[i][1])


plt.figure(figsize=(8, 6), dpi=100)
axes = plt.subplot(111)

type1 = axes.scatter(unlabled_x, unlabled_y, s=50, c='red')
type2 = axes.scatter(fake_x, fake_y, s=50, c='green')
type3 = axes.scatter(true_x, true_y, s=50, c='blue')

plt.title('t-SNE for feature from tight frame')
plt.xlabel('Y')
plt.ylabel('X')
axes.legend((type1, type2, type3), ('unlabled painting', 'fake painting',\
            'genuine painting'), loc=1)

plt.savefig('TFM_t-SNE.jpg')
plt.show()






pca = PCA(n_components=2)
pca.fit(dnp)
pca.transform(dnp)




pca2 = np.transpose(pca.components_)
print len(pca2)


true_x = []
true_y = []
unlabled_x = []
unlabled_y = []
fake_x = []
fake_y = []


unlabled_x.append(pca2[0][0])
unlabled_y.append(pca2[0][1]) 
unlabled_x.append(pca2[6][0])
unlabled_y.append(pca2[6][1])
unlabled_x.append(pca2[9][0])
unlabled_y.append(pca2[9][1])
unlabled_x.append(pca2[22][0]+0.002)
unlabled_y.append(pca2[22][1])
unlabled_x.append(pca2[24][0]+0.002)
unlabled_y.append(pca2[24][1])
unlabled_x.append(pca2[25][0]+0.002)
unlabled_y.append(pca2[25][1])   
 
fake_x.append(pca2[10][0]) 
fake_y.append(pca2[10][1])
fake_x.append(pca2[11][0]) 
fake_y.append(pca2[11][1])
fake_x.append(pca2[12][0]) 
fake_y.append(pca2[12][1])
fake_x.append(pca2[13][0]) 
fake_y.append(pca2[13][1])
fake_x.append(pca2[14][0]) 
fake_y.append(pca2[14][1])
fake_x.append(pca2[15][0]) 
fake_y.append(pca2[15][1])
fake_x.append(pca2[16][0]) 
fake_y.append(pca2[16][1])
fake_x.append(pca2[17][0]) 
fake_y.append(pca2[17][1])
fake_x.append(pca2[18][0]) 
fake_y.append(pca2[18][1])
fake_x.append(pca2[19][0]) 
fake_y.append(pca2[19][1])
     
true_x.append(pca2[1][0])
true_y.append(pca2[1][1])
true_x.append(pca2[2][0])
true_y.append(pca2[2][1])
true_x.append(pca2[3][0])
true_y.append(pca2[3][1])
true_x.append(pca2[4][0])
true_y.append(pca2[4][1])
true_x.append(pca2[5][0])
true_y.append(pca2[5][1])
true_x.append(pca2[7][0])
true_y.append(pca2[7][1])
true_x.append(pca2[8][0])
true_y.append(pca2[8][1])

for i in range(20,35):
    
    true_x.append(pca2[i][0])
    true_y.append(pca2[i][1])


plt.figure(figsize=(8, 6), dpi=100)
axes = plt.subplot(111)

type1 = axes.scatter(unlabled_x, unlabled_y, s=50, c='red')
type2 = axes.scatter(fake_x, fake_y, s=50, c='green')
type3 = axes.scatter(true_x, true_y, s=50, c='blue')

plt.title('PCA for feature from Tight Frame Method')
plt.xlabel('Y')
plt.ylabel('X')
axes.legend((type1, type2, type3), ('unlabled painting', 'fake painting',\
            'genuine painting'), loc=1)

plt.savefig('TFM_PCA.jpg')
plt.show()
"""











