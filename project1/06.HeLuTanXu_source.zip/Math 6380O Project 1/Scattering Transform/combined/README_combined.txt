This software implements the algorithm described in the paper :
"Combined Scattering for Rotation Invariant Texture Analysis" L. Sifre and S. Mallat. Proceedings of the ESANN 2012 conference. 

To get started run the file /combined/outex10reproducescore.m 

Questions about combined scattering : laurent.sifre@polytechnique.edu
