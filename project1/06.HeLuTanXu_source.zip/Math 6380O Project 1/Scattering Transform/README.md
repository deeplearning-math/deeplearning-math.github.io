run Scattering Transform.m in MATLAB
