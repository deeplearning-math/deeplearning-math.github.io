from __future__ import print_function
import torch.utils.data as data
from PIL import Image
import os
import os.path
import errno
import torch
import codecs
import os
import torch
import torch.nn as nn
from torch.autograd import Variable
import torchvision.datasets as dset
import torch.nn.functional as F
import torch.optim as optim
from torchvision import transforms, models
use_cuda = torch.cuda.is_available()
import numpy as np
from utils.dataset import FashionMNIST

def make_data_set(name="MNIST",model="resnet18"):
    root = './data'
    if not os.path.exists(root):
        os.mkdir(root)

    if(model =="resnet18"):
        scale_num = 224 
    elif(model =="vgg19"):
        scale_num = 224
    elif(model =="inception_v3"):
        scale_num = 299
    elif(model =="densenet161"):
        scale_num = 224

    trans = transforms.Compose([        
            transforms.Scale(scale_num),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])
    
    if name == "MNIST":
        # if not exist, download mnist dataset
        train_set = dset.MNIST(root=root, train=True, transform=trans, download=True)
        test_set = dset.MNIST(root=root, train=False, transform=trans, download=True)
    elif name == "FashionMNIST":
        # if not exist, download mnist dataset
        train_set = FashionMNIST(root=root, train=True, transform=trans, download=True)
        test_set = FashionMNIST(root=root, train=False, transform=trans, download=True)
    elif name == "CIFAR10":
        # if not exist, download mnist dataset
        train_set = dset.CIFAR10(root=root, train=True, transform=trans, download=True)
        test_set = dset.CIFAR10(root=root, train=False, transform=trans, download=True)
        
    batch_size = 32

    train_loader = torch.utils.data.DataLoader(
                     dataset=train_set,
                     batch_size=batch_size,
                     shuffle=True)
    test_loader = torch.utils.data.DataLoader(
                    dataset=test_set,
                    batch_size=batch_size,
                    shuffle=False)

    print('==>>> total trainning batch number: {}'.format(len(train_loader)))
    print('==>>> total testing batch number: {}'.format(len(test_loader)))
    return train_loader, test_loader

def make_model(name = "resnet18"):
    if(name =="resnet18"):
        model_conv = models.resnet18(pretrained=True)
    elif(name =="vgg19"):
        model_conv = models.vgg19(pretrained=True)
    elif(name =="inception_v3"):
        model_conv = models.inception_v3(pretrained=True)
    elif(name =="densenet161"):
        model_conv = models.densenet161(pretrained=True)

    for param in model_conv.parameters():
        param.requires_grad = False
    #new_classifier = nn.Sequential(*list(model_conv.children())[:-1])
    #model_conv = new_classifier
    model_conv = model_conv.cuda()
    return model_conv


datasets = ["FashionMNIST","CIFAR10"]
models_list = ["vgg19"] 
for m in models_list:
    model = make_model(m)
    for d in datasets:
        train_loader, test_loader = make_data_set(d,m)
        features = []
        label = []
        for X,y in test_loader:
            inputs = X.expand(-1, 3, -1,-1) ## for single channel img
            outputs = model(inputs.cuda()).squeeze()
            features.append(outputs.cpu().numpy())
            label.append(y.numpy())
        features = np.vstack(features)
        label = np.hstack(label)
        np.save("features/X_test_{}_{}_compressed".format(m,d), features)
        np.save("features/y_test_{}_{}_compressed".format(m,d), label)
        print("done",m,d)
