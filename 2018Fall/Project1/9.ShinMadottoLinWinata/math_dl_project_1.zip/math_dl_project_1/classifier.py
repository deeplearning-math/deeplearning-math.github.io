import numpy as np
from sklearn.metrics import accuracy_score,confusion_matrix,classification_report,log_loss
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC

def feature_loader(dataset, extractor, layer=1):
    if extractor == 'scatternet':
        X_train = np.load('features/train_X_{}_{}_bsz128_layer{}.npy'.format(extractor, dataset,layer))
        y_train = np.load('features/train_Y_{}_{}_bsz128_layer{}.npy'.format(extractor, dataset,layer))
        X_test = np.load('features/test_X_{}_{}_bsz128_layer{}.npy'.format(extractor, dataset,layer))
        y_test = np.load('features/test_Y_{}_{}_bsz128_layer{}.npy'.format(extractor, dataset,layer))
    else:
        X_train = np.load('features/X_train_{}_{}.npy'.format(extractor, dataset))
        y_train = np.load('features/y_train_{}_{}.npy'.format(extractor, dataset))
        X_test = np.load('features/X_test_{}_{}.npy'.format(extractor, dataset))
        y_test = np.load('features/y_test_{}_{}.npy'.format(extractor, dataset))
    print(X_train.shape)
    return X_train.reshape(X_train.shape[0],-1), y_train, X_test.reshape(X_test.shape[0],-1), y_test

class Classifier():
    def __init__(self, data):
        self.X_train = data[0]
        self.y_train = data[1]
    
        self.X_test = data[2]
        self.y_test = data[3]
    
    def LDA(self):
        model = LinearDiscriminantAnalysis()
        print('training LDA model...')
        model.fit(self.X_train, self.y_train)
        y_pred = model.predict(self.X_test)
        acc = accuracy_score(y_pred,self.y_test)
        print('acc_LDA:{}'.format(acc))
        return acc

    def RF(self):
        model = RandomForestClassifier(random_state=0)
        print('training RandomForest model...')
        model.fit(self.X_train, self.y_train)
        y_pred = model.predict(self.X_test)
        acc = accuracy_score(y_pred,self.y_test)
        print('acc_RF:{}'.format(acc))
        return acc

    def LR(self):
        model = LogisticRegression(solver='saga',n_jobs=8,max_iter=1000)
        print('training LogisticRegression model...')
        model.fit(self.X_train, self.y_train)
        y_pred = model.predict(self.X_test)
        acc = accuracy_score(y_pred,self.y_test)
        print('acc_LR:{}'.format(acc))
        return acc
    
    def SVM(self):
        model = SVC()
        print('training SVM model...')
        model.fit(self.X_train, self.y_train)
        y_pred = model.predict(self.X_test)
        acc = accuracy_score(y_pred,self.y_test)
        print('acc_SVM:{}'.format(acc))
        return acc

if __name__=='__main__':
    #extractor_name = [ 'scatternet','resnet18', 'vgg19']
    extractor_name = [ 'vgg19','raw','scatternet']
    gi_dataset_name = ['fashion-mnist']
    ma_dataset_name = ['FashionMNIST' ,'MNIST','CIFAR10'] 
    #gi_dataset_name = ['fashion-mnist','mnist','cifar-10'] 
    
    for extractor in extractor_name:
        if extractor == 'scatternet':
            dataset_name = gi_dataset_name
        else:
            dataset_name = ma_dataset_name
        for dataset in dataset_name:
            if extractor == 'scatternet':
                for layer in [1,2]:
                    data = feature_loader(dataset, extractor, layer)
                    clf = Classifier(data)
                    acc_lda = clf.LDA()
                    acc_rf = clf.RF()
                    acc_lr = clf.LR()
                    acc_svm = clf.SVM()
                    info = 'dataset:{}, extractor:{}, layer:{}, LDA_acc:{}, random_forest_acc:{}, logistic_regression_acc:{}, SVM_acc:{}'.format(dataset,extractor, layer,acc_lda,acc_rf,acc_lr,acc_svm)
                    with open('classification_log', 'a', encoding='utf-8') as f:
                        f.write(info)
                        f.write('\n')
                    print(info)
            else:
                if extractor == 'vgg19':
                    dataset = dataset+'_compressed'
                data = feature_loader(dataset, extractor)
                clf = Classifier(data)
                acc_lda = clf.LDA()
                acc_rf = clf.RF()
                acc_lr = clf.LR()
                acc_svm = clf.SVM()
                info = 'dataset:{}, extractor:{}, LDA_acc:{}, random_forest_acc:{}, logistic_regression_acc:{}, SVM_acc:{}'.format(dataset,extractor,acc_lda,acc_rf,acc_lr,acc_svm)
                with open('classification_log', 'a', encoding='utf-8') as f:
                    f.write(info)
                    f.write('\n')
                print(info)