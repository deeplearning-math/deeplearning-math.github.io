# math_dl

## Scatter Features
+ https://github.com/edouardoyallon/pyscatwave
+ Features dim: (number_sample, dim)
+ Targets dim: (number_sample,)

### Requirement
+ Python 2.7

### How to run
+ python scatternet_feature_extractor.py

### MNIST
#### train layer-1
+ ori features `(60000, 9, 14, 14)`
+ features `train_X_scatternet_mnist_bsz128_layer1.npy` `(60000, 1764)`
+ targets `train_Y_scatternet_mnist_bsz128_layer1.npy` `(60000,)`

#### test layer-1
+ ori features `(10000, 9, 14, 14)`
+ features `test_X_scatternet_mnist_bsz128_layer1.npy` `(10000, 1764)`
+ targets `test_Y_scatternet_mnist_bsz128_layer1.npy` `(10000,)`

#### train layer-2
+ ori features `(60000, 81, 7, 7)`
+ features `train_X_scatternet_mnist_bsz128_layer2.npy` `(60000, 3969)`
+ targets `train_Y_scatternet_mnist_bsz128_layer2.npy` `(60000,)`

#### test layer-2
+ ori features `(10000, 81, 7, 7)`
+ features `test_X_scatternet_mnist_bsz128_layer2.npy` `(10000, 3969)`
+ targets `test_Y_scatternet_mnist_bsz128_layer2.npy` `(10000,)`

### Fashion MNIST
#### train layer-1
+ ori features `((6000, 9, 14, 14))`
+ features `train_X_scatternet_fashion-mnist_bsz128_layer1.npy` `(60000, 1764)`
+ targets `train_Y_scatternet_fashion-mnist_bsz128_layer1.npy` `(60000,)`

#### test layer-1
+ ori features `((6000, 9, 14, 14))`
+ features `test_X_scatternet_fashion-mnist_bsz128_layer1.npy` `(10000, 1764)`
+ targets `test_Y_scatternet_fashion-mnist_bsz128_layer1.npy` `(10000,)`

#### train layer-2
+ ori features `(60000, 81, 7, 7)`
+ features `train_X_scatternet_fashion-mnist_bsz128_layer2.npy` `(60000, 3969)`
+ targets `train_Y_scatternet_fashion-mnist_bsz128_layer2.npy` `(60000,)`

#### test layer-2
+ ori features `(10000, 81, 7, 7)`
+ features `test_X_scatternet_fashion-mnist_bsz128_layer2.npy` `(10000, 3969)`
+ targets `test_Y_scatternet_fashion-mnist_bsz128_layer2.npy` `(10000,)`

### CIFAR-10
#### train layer-1
+ ori features `(50000, 3, 9, 16, 16)`
+ after avg pooling `(50000, 3, 4, 8, 8)`
+ features `train_X_scatternet_cifar-10_bsz128_layer1.npy` `(50000, 768)`
+ targets `train_Y_scatternet_cifar-10_bsz128_layer1.npy` `(50000,)`

#### test layer-1
+ ori features `(10000, 3, 9, 16, 16)`
+ after avg pooling `(10000, 3, 4, 8, 8)`
+ features `test_X_scatternet_cifar-10_bsz128_layer1.npy` `(10000, 768)` 
+ targets `test_Y_scatternet_cifar-10_bsz128_layer1.npy` `(10000,)`

#### train layer-2
+ ori features `(50000, 3, 81, 8, 8)`
+ after avg pooling `(50000, 3, 40, 4, 4)`
+ features `train_X_scatternet_cifar-10_bsz128_layer2.npy` `(50000, 1920)`
+ targets `train_Y_scatternet_cifar-10_bsz128_layer2.npy` `(50000,)`

#### test layer-2
+ ori features `(10000, 3, 81, 8, 8)`
+ after avg pooling `(10000, 3, 40, 4, 4)`
+ features `test_X_scatternet_cifar-10_bsz128_layer2.npy` `(10000, 1920)`
+ targets `test_Y_scatternet_cifar-10_bsz128_layer2.npy` `(10000,)`