import numpy as np
import scipy.io as sio
import pdb
import json
import proc_data as pd
import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt
from mnist import MNIST
import torch
import torch.nn as nn
from torchvision import models,datasets, transforms
from sklearn.ensemble import RandomForestClassifier


def mnist_rfs():
	''' set variables'''
	norm=True
	random_select=False
	sequence_select=True
	image_show=False
	train_data_idx=[]
	base_line=True

	'''load mnist data'''
	mndata = MNIST('D:/mnist_data/raw')
	train_images, labels_train = mndata.load_training()
	test_images, labels_test = mndata.load_testing()
	test_labels=np.zeros([10000],dtype=np.int8)
	train_labels=np.zeros([60000],dtype=np.int8)
	for i in range(10000):
		test_labels[i]=labels_test[i]
	for j in range(60000):
		train_labels[j]=labels_train[j]
	
	if base_line:
		train_num=0
		test_num=0
		train_features=np.zeros([60000,28*28])
		test_features=np.zeros([10000,28*28])
		for images in train_images:
			train_features[train_num,:]=images
			train_num=train_num+1
		for images in test_images:
			test_features[test_num,:]=images
			test_num=test_num+1 

		train_std=np.std(train_features,axis=0)
		idx_feas=np.where(train_std!=0)
		train_features=np.squeeze(train_features[:,idx_feas])
		test_features=np.squeeze(test_features[:,idx_feas])

	else:
		'''load features'''
		train_features=sio.loadmat("D:/Math 6380p/valid_train_features_all_resnet.mat")['train_features']
		test_features=sio.loadmat("D:/Math 6380p/valid_test_features_resnet.mat")['test_features']


	''' features nomalizaition '''
	if norm:
		meanstd = pd.create_meanstd(train_features)
		train_features = pd.linear_map(train_features, meanstd)
		test_features = pd.linear_map(test_features, meanstd)  # use the train_features to nomalizaion

	size_num=[300,1000,2000,5000,10000,20000,40000,60000]
	train_features_all=train_features
	train_labels_all=train_labels

	for size_selected in size_num:
		size_selected=np.int(size_selected)
		f = open('bf_mnist_rfs_baseline_'+str(size_selected)+'.txt','w')
		if random_select:
			''' random selection '''
			idx = np.random.randint(60000, size=size_selected)
			train_data_idx=train_data[idx,:]
			train_features=train_data_idx[:,:-1]
			train_labels=train_data_idx[:,-1]
		if sequence_select:
			train_features=train_features_all[:size_selected,:]
			train_labels=train_labels_all[:size_selected]

		# clf = RandomForestClassifier(max_depth=2, random_state=0, n_jobs=-1, n_estimators=10)
		clf = RandomForestClassifier(oob_score=False,max_depth=None, n_jobs=-1, n_estimators=1000)
		clf.fit(train_features, train_labels)   # oob_scare: similar to cross validation
		f.write(json.dumps(clf.get_params()))  # write dict to txt
		pre_labels=clf.predict(test_features)
		acc=clf.score(test_features, test_labels, sample_weight=None)

		print("accuracy of test dataset:%f" % acc)
		f.write("accuracy of test dataset:%f\r\n" % acc)
		f.close
		''' show image'''
		if image_show:
			row_tol=5
			col_tol=5
			img_digt=[]
			img_slt=[]
			for row in range(5,10): 
				idx_digt=np.where(pre_labels==row) #digit==row
				img_digt=np.squeeze(test_images[idx_digt,:,:])
				# pdb.set_trace()
				img_idx = np.random.randint(img_digt.shape[0], size=10)
				# img_slt=img_digt[img_idx,:,:].reshape([10,28,28])
				img_slt=np.squeeze(img_digt[img_idx,:,:])
				for col in range(0,5):
					plt.subplot(row_tol, col_tol, (row-5)*5+col+1)   
					# image= img_slt[col,:,:].reshape([28,28])     
					image=(np.reshape(img_slt[col,:,:], (28, 28)) * 255).astype(np.uint8)# subplot with size (width 3, height 5)
					plt.imshow(image, cmap='gray')  # cmap='gray' is for black and white picture.
					plt.axis('off')
			plt.tight_layout()
			plt.savefig('mnist_rfc_5_5_2.eps', format='eps', dpi=600)
			plt.show



# if __name__ == "__mnist__":
#     '''
#     mnist_svc(): classfication with cross validation through SVC
#     mnist_rfs(): classfication with random forest
 #   '''
	# # mnist_svc()
mnist_rfs()