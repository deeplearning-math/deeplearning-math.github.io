
README

The code repository comes with following files:
- scatnet_feature.m: generate features with ScatNet
- resnet_feature.py: generate features with ResNet
- visualize_features.py: visualize features with multiple methods
- preprocess_data.py: preprocess datasets before training models
- mnist_svm.py: train models with SVM
- mnist_rfs.py: train models with Random Forest
