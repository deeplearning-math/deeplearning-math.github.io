function features = feat(X,J,L,M)
%size(X)=[N, 28*28]; N = num of images.
%J is the number of scale.
%L is the number of orientations.
%M (default 2) is the maximum scattering order.
%size(features) = [N,1+J*L+L*L*J*(J-1)/2].

if nargin < 4
    M = 2;
end

N = size(X,1);
filt_opt.J = J;
filt_opt.L = L;
%scat_opt.oversampling = 2;
scat_opt.M = M;

[Wop,filters] = wavelet_factory_2d([28,28], filt_opt, scat_opt); %image size = [28,28]

display_filter_bank_2d(filters);
colormap gray;
axis off;

features = zeros(N,1+J*L+L*L*J*(J-1)/2);    %M=2

h=waitbar(0,'please wait');

for n = 1:N
    x = reshape(X(n,:),[28,28]);
    Sx = scat(x, Wop);
    S_mat = format_scat(Sx);
    features(n,:) = sum(sum(S_mat,2),3);
    str=[num2str(n),'/',num2str(N)];
    waitbar(n/N,h,str)
end
delete(h);






end