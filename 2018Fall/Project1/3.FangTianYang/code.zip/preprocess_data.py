import numpy as np

def check_dim(data):
    if len(data.shape) == 1:
        data = data[:, np.newaxis]
    elif len(data.shape) > 2:
        raise Exception("data should has 1 or 2 dims")
    return data

def create_meanstd(data):
    data = check_dim(data)
    meanstd = np.zeros((2, data.shape[1]), dtype=np.float)
    for i in range(data.shape[1]):
        meanstd[0, i] = np.nanmean(data[:, i])
        meanstd[1, i] = np.nanstd(data[:, i])
    return meanstd

def linear_map(data, meanstd, reverse=False):
    ndims = len(data.shape)
    data = check_dim(data)
    meanstd = check_dim(meanstd)
    if meanstd.shape[1] != data.shape[1]:
        raise Exception("dim not consistent between data and meanstd")
    data_new = data.copy()
    if not reverse:
        for i in range(meanstd.shape[1]):
            data_new[:, i] = (data[:, i] - meanstd[0, i]) / meanstd[1, i]
    else:
        for i in range(meanstd.shape[1]):
            data_new[:, i] = data[:, i] * meanstd[1, i] + meanstd[0, i]
    if ndims == 1:
        data_new = np.squeeze(data_new)
    return data_new
