#!/usr/bin/env python2
# coding: utf-8
"""
1. manifold learing (http://scikit-learn.org/stable/modules/manifold.html)
"""
import subprocess as sp
import sys
res = sp.check_output([ 'pipenv', '--venv' ]).strip()
sys.path.insert(0, res + '/lib/python2.7/site-packages/')

from itertools import islice

import numpy as np
from torchvision import datasets
from progressbar import progressbar
import scipy.io as sio
from sklearn import manifold, decomposition


def plot_embedding(data_path, label_path, fig_path):
    from matplotlib import pyplot as plt
    data = np.load(data_path)
    # labels = datasets.MNIST('data', train=True).train_labels
    labels = np.load(label_path)
    colors = [
        '#D00205', '#FC0001', '#FF7C00', '#F4CA00', '#FDFF05',
        '#02FE02', '#009546', '#932691', '#FB00FF', '#0072C0'
    ]
    buckets = [ [ [], [] ] for _ in range(10) ]
    for x, y, l in progressbar(zip(data[:,0], data[:,1], labels)):
        buckets[l][0].append(x)
        buckets[l][1].append(y)
    for i in range(10):
        plt.scatter(buckets[i][0], buckets[i][1], s=5, c=colors[i])
    plt.savefig(fig_path, format='pdf')


def gen_embedding(algorithm, features, data_path):
    embedding = algorithm.fit_transform(features)
    np.save(data_path, embedding)


def main():
    scat_features = [ (name, 'data/features/scat/{}.mat'.format(name)) for name in [ 'train36' ] ]
    resnet_features = [ ('resnet', 'data/features/resnet/features.npy') ]
    raw_features = [ ('raw', 'data/features/raw/features.npy') ]
    algorithms = [
        ( 'tsne', manifold.TSNE(n_components=2) ),
        ( 'lle', manifold.LocallyLinearEmbedding() ),
        ( 'mds', manifold.MDS() ),
        ( 'se', manifold.SpectralEmbedding() ),
        ( 'isomap', manifold.Isomap(n_neighbors=6, n_components=2) ),
        ( 'pca', decomposition.PCA(n_components=2) )
    ]
    for name, path in scat_features + resnet_features + raw_features:
        for abbr, algorithm in algorithms:
            print(name, path, abbr)
            features = sio.loadmat(path)['train_features'] if path.endswith('.mat') else np.load(path)
            samples = features[:5000]
            labels = datasets.MNIST('data', train=True).train_labels[:5000]
            label_path = 'data/cache/{}/{}-label.npy'.format(abbr, name)
            np.save(label_path, labels)
            cache_path = 'data/cache/{}/{}.npy'.format(abbr, name)
            gen_embedding(algorithm, samples, cache_path)
            plot_embedding(cache_path, label_path, 'data/figures/{}/{}.pdf'.format(abbr, name))


if __name__ == '__main__':
    main()
