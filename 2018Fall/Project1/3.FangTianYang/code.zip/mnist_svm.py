# import mnist #set up
import numpy as np
import scipy.io as sio
import time
import pdb
import math
import xlwt
import json
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn import metrics
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import classification_report
import proc_data as pd
import scipy.misc
import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt
from mnist import MNIST
import torch
import torch.nn as nn
from torchvision import models,datasets, transforms
from sklearn.ensemble import RandomForestClassifier


def mnist_svc():
	''' set variables'''
	norm=True
	random_select=False
	sequence_select=True
	train_data_idx=[]
	image_show=False
	base_line=True
	'''load mnist data'''
	mndata = MNIST('D:/mnist_data/raw')
	train_images, labels_train = mndata.load_training()
	test_images, labels_test = mndata.load_testing()
	test_labels=np.zeros([10000],dtype=np.int8)
	train_labels=np.zeros([60000],dtype=np.int8)
	for i in range(10000):
		test_labels[i]=labels_test[i]
	for j in range(60000):
		train_labels[j]=labels_train[j]

	if base_line:
		train_num=0
		test_num=0
		train_features=np.zeros([60000,28*28])
		test_features=np.zeros([10000,28*28])
		for images in train_images:
			train_features[train_num,:]=images
			train_num=train_num+1
		for images in test_images:
			test_features[test_num,:]=images
			test_num=test_num+1 

		train_std=np.std(train_features,axis=0)
		idx_feas=np.where(train_std!=0)
		train_features=np.squeeze(train_features[:,idx_feas])
		test_features=np.squeeze(test_features[:,idx_feas])

	else:
		'''load features'''
		train_features=sio.loadmat("D:/Math 6380p/valid_train_features_all_resnet.mat")['train_features']
		test_features=sio.loadmat("D:/Math 6380p/valid_test_features_resnet.mat")['test_features']

		''' scat_net'''
		# train_features=sio.loadmat("D:/Math 6380p/train36_bf.mat")['train_features']
		# test_features=sio.loadmat("D:/Math 6380p/test36_bf.mat")['test_features']
		''' resnet'''
		# train_features=sio.loadmat("D:/Math 6380p/valid_train_features_all_resnet.mat")['train_features']
		# test_features=sio.loadmat("D:/Math 6380p/valid_test_features_resnet.mat")['test_features']

	''' features nomalizaition '''
	if norm:
		meanstd = pd.create_meanstd(train_features)
		train_features = pd.linear_map(train_features, meanstd)
		test_features = pd.linear_map(test_features, meanstd)  # use the train_features to nomalizaion


	# train_labels = mnist.train_labels()
	# test_labels = mnist.test_labels()
	# test_images= mnist.test_images()

	train_features_all=train_features
	train_labels_all=train_labels

	size_num=[300,1000,2000,5000,10000,20000,40000,60000]
	for size_selected in size_num:
		f = open('bf_mnist_svc_baseline_'+str(size_selected)+'.txt','w')
		if random_select:
			''' random selection '''
			idx = np.random.randint(60000, size=size_selected)
			train_data_idx=train_data[idx,:]
			train_features=train_data_idx[:,:-1]
			train_labels=train_data_idx[:,-1]

		if sequence_select:
			train_features=train_features_all[:size_selected,:]
			train_labels=train_labels_all[:size_selected]


		''' tune parameters'''
		tuned_parameters = [{'kernel': ['rbf'], 'gamma': [1e-3, 5*1e-4],'C': [50, 100]}]

		# tuned_parameters = [{'kernel': ['rbf'], 'gamma': [1e-3, 1e-4],
		#                      'C': [50, 100]},
		#                     {'kernel': ['linear'], 'C': [1, 10, 100]}]
		# scores = ['precision', 'recall','accuracy']
		scores = ['accuracy']
		# scores stratigy :‘accuracy’ ‘average_precision’ (scoring-parameter)
	 
		for score in scores:
		    print("# Tuning hyper-parameters for %s" % score)
		    print()
		    f.write("# Tuning hyper-parameters for %s:\r\n" % score)

		    ''' cross validation'''

		    if score== "accuracy":
		    	clf = GridSearchCV(SVC(), tuned_parameters, cv=5, scoring='%s' % score)  # micro macro
		    else:
		    	clf = GridSearchCV(SVC(), tuned_parameters, cv=5, scoring='%s_macro' % score)  # micro macro
		    clf.fit(train_features, train_labels)

		    print("Best parameters set found on development set:")
		    print()
		    f.write("Best parameters set found on development set:\r\n")

		    print(clf.best_params_)
		    print()
		    f.write(json.dumps(clf.best_params_)) # write dict to txt

		    print("Grid scores on development set:")
		    print()
		    f.write("Grid scores on development set:\r\n" )
		    means = clf.cv_results_['mean_test_score']
		    stds = clf.cv_results_['std_test_score']
		    for mean, std, params in zip(means, stds, clf.cv_results_['params']):
		        print("%0.3f (+/-%0.03f) for %r" % (mean, std * 2, params))
		        f.write("%0.3f (+/-%0.03f) for %r\r\n" % (mean, std * 2, params))
		    print()

		    ''' test'''
		    print("Detailed classification report:")
		    print()
		    f.write("Detailed classification report:\r\n")

		    print("The model is trained on the full development set.")
		    print("The scores are computed on the full evaluation set.")
		   	# f.write("The model is trained on the full development set.\r\n")
		    f.write("The scores are computed on the full evaluation set \r\n")
		    print()
		    y_true, y_pred = test_labels, clf.predict(test_features)
		    print(classification_report(y_true, y_pred))
		    print()
		    f.write(classification_report(y_true,y_pred))
		    print("Accuracy={}".format(metrics.accuracy_score(y_true, y_pred)))
		    f.write("Accuracy={}\r\n".format(metrics.accuracy_score(y_true, y_pred)))
		f.close()

		''' show image'''
		if image_show:
			row_tol=5
			col_tol=5
			img_digt=[]
			img_slt=[]
			for row in range(5,10): 
				idx_digt=np.where(y_pred_labels==row) #digit==row
				img_digt=np.squeeze(test_images[idx_digt,:,:])
				# pdb.set_trace()
				img_idx = np.random.randint(img_digt.shape[0], size=10)
				# img_slt=img_digt[img_idx,:,:].reshape([10,28,28])
				img_slt=np.squeeze(img_digt[img_idx,:,:])
				for col in range(0,5):
					plt.subplot(row_tol, col_tol, (row-5)*5+col+1)   
					# image= img_slt[col,:,:].reshape([28,28])     
					image=(np.reshape(img_slt[col,:,:], (28, 28)) * 255).astype(np.uint8)# subplot with size (width 3, height 5)
					plt.imshow(image, cmap='gray')  # cmap='gray' is for black and white picture.
					plt.axis('off')
			plt.tight_layout()
			# plt.savefig('mnist_rfc_plot.png')
			plt.savefig('mnist_svc_5_5_2.eps', format='eps', dpi=600)
			plt.show


mnist_svc()