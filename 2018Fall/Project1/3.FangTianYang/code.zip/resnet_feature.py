# coding: utf-8
"""
1. ResNet-18
2. VGG-19
3. Scattering Network
"""
import torch
import torch.nn as nn
from torchvision import models,datasets, transforms
import numpy as np
from progressbar import progressbar
from itertools import islice


def resnet():
    # pretrained resnet18
    pretrained_model = models.resnet18(pretrained=True)

    # remove last fully-connected layer
    resnet = nn.Sequential(*list(pretrained_model.children())[:-1])

    # freeze the network
    for param in resnet.parameters():
        param.requires_grad = False

    #load data
    train_dataset = datasets.MNIST(root='data',
                                   transform=transforms.Compose([
                                       transforms.Resize(size=(224, 224)),
                                       transforms.ToTensor(),
                                       transforms.Lambda(lambda x: x.repeat(3, 1, 1)),
                                       transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
                                   ]),
                                   train = True,
                                   download = True)

    test_dataset = datasets.MNIST(root='data',
                                  transform=transforms.Compose([
                                       transforms.Resize(size=(224, 224)),
                                       transforms.ToTensor(),
                                       transforms.Lambda(lambda x: x.repeat(3, 1, 1)),
                                       transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
                                   ]),
                                  train = False,
                                  download = True)
    # mini batch of data
    batch_size = 100

    train_loader = torch.utils.data.DataLoader(dataset=train_dataset,
                                               batch_size=batch_size,
                                               shuffle=False)

    test_loader = torch.utils.data.DataLoader(dataset=test_dataset,
                                              batch_size=batch_size,
                                              shuffle=False)

    print ('total trainning batch number: {}'.format(len(train_loader)))
    print( 'total testing batch number: {}'.format(len(test_loader)))

    res = []
    # Actual usage of the data loader is as below.
    for images, labels in progressbar(train_loader):
        features = resnet(images)
        res.append(features.reshape(100, 512))

    np.save('data/features/resnet/features.npy', np.concatenate(res))


if __name__ == '__main__':
    resnet()
