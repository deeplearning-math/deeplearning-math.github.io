import torch
import torch.nn as nn
import numpy as np
import time

from torch.autograd import Variable
import torch.optim as optim
import torch.backends.cudnn as cudnn
from torch.utils.data import DataLoader

import torchvision
import torchvision.models as models
import torchvision.transforms as transforms
import torchvision.datasets as datasets

from torch.utils.data import Dataset

from sklearn.metrics import accuracy_score,roc_auc_score
import os
import nibabel as nib
import argparse
from utils import AverageMeter
from distutils.version import LooseVersion
import math
from vgg import vgg16_bn
from resnet import resnet18
from vgg_dcf import vgg16_bn_dcf
from resnet_dcf import resnet18_dcf
import matplotlib.pyplot as plt
# from losses import DICELossMultiClass

def train(train_loader, model, criterion, optimizer, epoch, args):
    losses = AverageMeter()

    model.train()
    iteration = 0
    for images,labels in train_loader:
        # print(sample[:,0,:,:].unsqueeze(dim=1).size())
        image = Variable(images.float()).cuda()
        label = Variable(labels).long().cuda()
        # label = Variable(target).float().cuda()
        out = model(image)
        # out = torch.clamp(out, min = 0.0, max = 1.0)
        # out = out.contiguous()
        # label = label.contiguous()
        # print(out[:,1], label)
        loss = criterion(out, label)
        losses.update(loss.data[0],image.size(0))

        # compute gradient and do SGD step
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # adjust learning rate
        cur_iter = iteration + (epoch - 1) * args.epoch_iters
        adjust_learning_rate(optimizer, cur_iter, args)

        if iteration%500==0:
            print('   * i {} |  lr: {:.7f} | Training Loss: {losses.avg:.3f}'.format(iteration, args.running_lr, losses=losses))
        iteration +=1
    print('   * EPOCH {epoch} | Training Loss: {losses.avg:.3f}'.format(epoch=epoch, losses=losses))
    return losses.avg

def validation(val_loader, model,epoch, args):
    model.eval()
    correct = 0
    total = 0
    for images, labels in val_loader:
        image = Variable(images).float().cuda()
        label = Variable(labels).long().data.cpu().numpy()
        out = model(image)
        with torch.no_grad():
            _, predicted = torch.max(out.data, 1)
            total += labels.size(0)
            correct += (predicted.data.cpu().numpy() == labels).sum()

    print('   * EPOCH {epoch} | Validation accuracy: {losses} '.format(epoch=epoch, losses=float(correct) / float(total)))
    return  float(correct) / float(total)      # print(out[0,0])
            # break

def save_checkpoint(state, epoch, args):
    filename = args.ckpt + '/' + str(epoch) + '_checkpoint.pth.tar'
    print(filename)
    torch.save(state, filename)

# def load_checkpoint(epoch, args):

    # torch.save(state, filename)


def adjust_learning_rate(optimizer, cur_iter, args):
    scale_running_lr = ((1. - float(cur_iter) / args.max_iters) ** args.lr_pow)
    args.running_lr = args.lr * scale_running_lr

    for param_group in optimizer.param_groups:
        param_group['lr'] = args.running_lr

def main(args):
    # import network architecture

    # model = vgg16_bn(pretrained = False, num_classes = args.num_classes)
    model = vgg16_bn_dcf(num_classes = args.num_classes)
    # model = resnet18(num_classes = args.num_classes)
    # model = resnet18_dcf(num_classes = args.num_classes)
    # model = resnet18_dcf(num_classes = args.num_classes, initializer = 'random')

    model = torch.nn.DataParallel(model, device_ids=list(range(args.num_gpus))).cuda()
    cudnn.benchmark = True

    # collect the number of parameters in the network
    print("------------------------------------------")
    # print("Network Architecture of Model %s:" % (args.id))
    num_para = 0
    for name, param in model.named_parameters():
        num_mul = 1
        for x in param.size():
            num_mul *= x
        num_para += num_mul

    print(model)
    print("Number of trainable parameters %d in Model" % (num_para))
    print("------------------------------------------")

    # set the optimizer and loss
    # optimizer = optim.RMSprop(model.parameters(), args.lr, alpha=args.alpha, eps=args.eps, weight_decay=args.weight_decay, momentum=args.momentum)
    optimizer = optim.Adam(model.parameters(), args.lr, eps=args.eps, weight_decay=args.weight_decay)
    # optimizer = optim.SparseAdam(model.parameters(), args.lr, betas=args.betas, eps=args.eps, weight_decay=args.weight_decay)


    # criterion = DICELoss()

    criterion = nn.CrossEntropyLoss()
    # criterion = nn.CrossEntropyLoss(weight = torch.cuda.FloatTensor([1.0,9.0]))
    # criterion = DICELossMultiClass()
    if args.resume:
        if os.path.isfile(args.resume):
            print("=> Loading checkpoint '{}'".format(args.resume))
            checkpoint = torch.load(args.resume)
            start_epoch = checkpoint['epoch']
            model.load_state_dict(checkpoint['state_dict'])
            optimizer.load_state_dict(checkpoint['opt_dict'])
            print("=> Loaded checkpoint (epoch {})".format(checkpoint['epoch']))
        else:
            print("=> No checkpoint found at '{}'".format(args.resume))

    # loading data
    data_transforms = transforms.Compose([
        # transforms.CenterCrop(192),
        # transforms.RandomHorizontalFlip(),
        # transforms.RandomVerticalFlip(),
        # transforms.RandomRotation(degrees = args.rotate_range),
        transforms.ToTensor()
        # transforms.Normalize([63.321, 63.321, 63.321], [40.964, 40.964, 40.964])
    ])
    dataset = torchvision.datasets.FashionMNIST(root = args.root_path, train = True, download = True, transform = data_transforms)
    train_loader = DataLoader(dataset,
                            batch_size=args.batch_size,
                            shuffle=True,
                            num_workers=args.num_workers)
    dataset_val = torchvision.datasets.FashionMNIST(root = args.root_path, train = False, download =True,  transform = data_transforms)
    validation_loader = DataLoader(dataset_val,
                            batch_size=args.batch_size,
                            shuffle=False,
                            num_workers=args.num_workers)

    # num_train = len(dataset)
    # print(num_train)
    # indices = list(range(num_train))
    # split = num_train/10
    # validation_idx = np.random.choice(indices, size=split, replace=False)
    # train_idx = list(set(indices) - set(validation_idx))
    # train_sampler = SubsetRandomSampler(train_idx)
    # validation_sampler = SubsetRandomSampler(validation_idx)
    # # tf = TrainDataset(train_dir, args)
    # train_loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True,sampler=train_sampler)
    # validation_loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True,sampler=validation_sampler)

    print("Start training ...")
    train_loss = []
    avg_accu = []
    # print(avg_accu)
    # avg_accu.append(0)
    best_epoch=0
    best_accu= 0
    for epoch in range(args.start_epoch + 1, args.num_epochs + 1):
        start_time = time.time()
        loss = train(train_loader, model, criterion, optimizer, epoch, args)
        train_loss.append(loss)
        # save models
        # if (epoch >= args.particular_epoch and epoch % args.save_epochs_steps == 0) or epoch % args.save_epochs_steps_before == 0 :
            # if epoch % args.save_epochs_steps == 0:
        save_checkpoint({'epoch': epoch, 'state_dict': model.state_dict(), 'opt_dict': optimizer.state_dict()}, epoch, args)
        filename = args.ckpt + '/' + str(epoch) + '_checkpoint.pth.tar'
        # print(filename)
        checkpoint = torch.load(filename)
        state_dict = checkpoint['state_dict']
        model.load_state_dict(state_dict)
        accu = validation(validation_loader, model, epoch, args)
        avg_accu.append(accu)
        # print(avg_accu)
        if accu > best_accu:
            best_epoch = epoch
            best_accu = accu
        elapsed_time = time.time() - start_time
        print('epoch time ' +str(time.strftime("%H:%M:%S", time.gmtime(elapsed_time))) + ', remaining time ' +str(time.strftime("%H:%M:%S", time.gmtime(elapsed_time*(args.num_epochs - epoch)))))
        if epoch % 5 ==0 or epoch ==args.num_epochs:
            x= range(args.start_epoch +1, epoch+1)

            plt.figure(1)

            plt.plot(x, train_loss, label='loss')
            # plt.plot(x, train_loss, x, avg_accu)
            plt.plot(x, avg_accu, label = 'val_accu')
            plt.legend ()
            plt.xlabel('epoch')

            imgname = args.ckpt + '/figure.png'
            plt.savefig(imgname)
            plt.gcf().clear()
    print("Training Done")
    print("Best epoch " +str(best_epoch) + ', auc score '+str(best_accu))

if __name__ == '__main__':
    assert LooseVersion(torch.__version__) >= LooseVersion('0.3.0'), \
        'PyTorch>=0.3.0 is required'

    parser = argparse.ArgumentParser()
    # Model related arguments


    # Path related arguments

    parser.add_argument('--root_path', default='/home/wynonna/Documents/Research/Brats2018/course_pro/PRO3/data/',
                        help='root directory of data')
    parser.add_argument('--ckpt', default='./saved_models',
                        help='folder to output ciheckpoints')
    parser.add_argument('--num_round', default=3, type=int)

    # Data related arguments

    parser.add_argument('--num_classes', default=10, type=int,
                        help='number of classes')
    parser.add_argument('--num_workers', default=3, type=int,
                        help='number of data loading workers')
    parser.add_argument('--shuffle', default=True, type=bool,
                        help='if shuffle the data during training')
    parser.add_argument('--rotate_range', default=30, type=int,
                        help='if shuffle the data during training')

    # optimization related arguments
    parser.add_argument('--random_sample', action='store_true', default=True, help='whether to sample the dataset with random sampler')
    parser.add_argument('--num_gpus', default=1, type=int, help='number of GPUs to use')
    parser.add_argument('--batch_size', default=64, type=int,
                        help='training batch size')
    parser.add_argument('--num_epochs', default=50, type=int,
                        help='epochs for training')
    parser.add_argument('--start_epoch', default=0, type=int,
                        help='epoch to start training. useful if continue from a checkpoint')
    parser.add_argument('--lr', default=1e-4, type=float,
                        help='start learning rate')
    parser.add_argument('--lr_pow', default=0.95, type=float,
                        help='power in poly to drop learning rate')
    parser.add_argument('--optim', default='RMSprop', help='optimizer')
    parser.add_argument('--alpha', default='0.9', type=float, help='alpha in RMSprop')
    # parser.add_argument('--betas', default='(0.9,0.999)', type=float, help='betas in Adam')
    parser.add_argument('--eps', default=10**(-4), type=float, help='eps in RMSprop')
    parser.add_argument('--weight_decay', default=1e-3, type=float, help='weights regularizer')
    parser.add_argument('--momentum', default=0.8, type=float, help='momentum for RMSprop')
    parser.add_argument('--save_epochs_steps', default=1, type=int,
                        help='frequency to save models after a particular number of epochs')
    parser.add_argument('--save_epochs_steps_before', default=10, type=int,
                        help='frequency to save models after a particular number of epochs')
    parser.add_argument('--particular_epoch', default=40, type=int,
                        help='after this number, we will save models more frequently')
    parser.add_argument('--resume', default='',
                        help='the checkpoint that resumes from')


    args = parser.parse_args()
    print("Input arguments:")
    for key, val in vars(args).items():
        print("{:16} {}".format(key, val))

    # train_file = open(args.train_path, 'r')
    # train_dir = train_file.readlines()

    args.ckpt = os.path.join(args.ckpt, str(args.num_round))
    print('Models are saved at %s' % (args.ckpt))

    if not os.path.isdir(args.ckpt):
        os.makedirs(args.ckpt)

    if args.start_epoch > 1:
        args.resume = args.ckpt + '/' + str(args.start_epoch) + '_checkpoint.pth.tar'

    args.running_lr = args.lr
    args.epoch_iters = math.ceil(int(60000/args.batch_size))
    args.max_iters = args.epoch_iters * args.num_epochs


    main(args)
