import argparse
import time

import torch
from torch import nn
from torch.nn import functional as F
from torch.autograd import Variable
from torch import optim
from torch.nn import Module
from torch.utils.data import DataLoader
from torchvision.datasets import MNIST
from torchvision.models import resnet18
from torchvision import transforms

from cluttered_mnist_data import load_cluttered_mnist


class MLP2Layers(nn.Module):
    def __init__(self, in_features, hidden_units, n_classes):
        super().__init__()
        self.in_features = in_features
        self.fc1 = nn.Linear(in_features, hidden_units)
        self.fc2 = nn.Linear(hidden_units, hidden_units)
        self.dropout = nn.Dropout(0.5)
        self.fc3 = nn.Linear(hidden_units, n_classes)

    def forward(self, x):
        x = x.view(-1, self.in_features)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.dropout(x)
        x = self.fc3(x)
        return x


class Conv2Layers(nn.Module):
    def __init__(self, n_classes):
        super().__init__()
        self.conv2d = nn.Conv2d(1, 8, 10, stride=5)
        self.fc1 = nn.Linear(11*11*8, 256)
        self.dropout = nn.Dropout(0.5)
        self.fc2 = nn.Linear(256, n_classes)

    def forward(self, x):
        x = F.relu(self.conv2d(x))
        x = x.view(-1, 11*11*8)
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        x = self.fc2(x)
        return x


class ConvNet(nn.Module):
    def __init__(self, n_classes):
        super().__init__()
        # self.conv1 = nn.Conv2d(1, 10, 5)
        # self.pool1 = nn.MaxPool2d(2, 2)
        # self.conv2 = nn.Conv2d(10, 20, 5)
        # self.pool2 = nn.MaxPool2d(2, 2)
        self.features = nn.Sequential(
            nn.Conv2d(1, 10, 5),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),
            nn.Conv2d(10, 20, 5),
            nn.ReLU(),
            nn.MaxPool2d(2, 2)
        )
        self.fc = nn.Sequential(
            nn.Linear(20*12*12, 256),
            nn.ReLU(),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(128, n_classes)
        )

    def forward(self, x):
        # x = self.pool1(F.relu(self.conv1(x)))
        # x = self.pool2(F.relu(self.conv2(x)))
        x = self.features(x)
        x = x.view(-1, 20*12*12)
        # x = F.relu(self.fc1(x))
        # x = self.dropout(x)
        # x = self.fc2(x)
        x = self.fc(x)
        return x


class AverageMeter(object):
    """
    Computes and stores the average and
    current value.
    """
    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


def train_model(model, optimizer, criterion, device,
                trainloader, testloader, validloader=None, max_epoch=100):
    model = model.to(device)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=10)
    print('Start training...')
    best_valid_acc = 0
    for epoch in range(max_epoch):
        print(f'Epoch {epoch+1} | ', end='')
        print('lr: {} | '.format(','.join([str(group['lr']) for group in optimizer.param_groups])), end='')
        epoch_loss_train = AverageMeter()
        epoch_acc_train = AverageMeter()
        epoch_tic = time.time()

        # training
        model.train()
        for batch, (samples, labels) in enumerate(trainloader):
            optimizer.zero_grad()

            samples, labels = Variable(samples.to(device)), Variable(labels.to(device))
            output = model(samples)
            loss = criterion(output, labels)
            loss.backward()
            optimizer.step()

            epoch_loss_train.update(loss.item(), labels.shape[0])
            _, predicted = torch.max(output.data, 1)
            acc = (predicted==labels).sum().item() / labels.shape[0]
            epoch_acc_train.update(acc, labels.shape[0])

        epoch_loss_valid = AverageMeter()
        epoch_acc_valid = AverageMeter()
        model.eval()
        if validloader is not None:
            with torch.no_grad():
                for batch, (samples, labels) in enumerate(validloader):
                    samples, labels = samples.to(device), labels.to(device)
                    output = model(samples)
                    loss = criterion(output, labels)
                    _, predicted = torch.max(output.data, 1)
                    acc = (predicted==labels).sum().item() / labels.shape[0]

                    epoch_loss_valid.update(loss.item(), labels.shape[0])
                    epoch_acc_valid.update(acc, labels.shape[0])

            if epoch_acc_valid.avg > best_valid_acc:
                best_valid_acc = epoch_acc_valid.avg
        scheduler.step(epoch_loss_train.avg)

        print('Loss: train={:.3f}, valid={:.3f} | '.format(epoch_loss_train.avg, epoch_loss_valid.avg), end='')
        print('Acc.: train={:.2f}%, valid={:.2f}% | '.format(100*epoch_acc_train.avg, 100*epoch_acc_valid.avg), end='')
        print('Time: {:.1f}s'.format(time.time()-epoch_tic))

    # test on leave-out testing set
    acc_test = AverageMeter()
    for batch, (samples, labels) in enumerate(testloader):
        samples, labels = samples.to(device), labels.to(device)
        output = model(samples)
        loss = criterion(output, labels)
        _, predicted = torch.max(output.data, 1)
        acc = (predicted==labels).sum().item() / labels.shape[0]
        acc_test.update(acc, labels.shape[0])

    print('Training is done. Best valid. acc.={:.2f}%, test acc.={:.2f}%'.format(best_valid_acc*100, acc_test.avg*100))
    return acc_test


if __name__ == "__main__":
    mnist_train = DataLoader(MNIST('mnist', transform=transforms.ToTensor()), batch_size=500)
    mnist_test = DataLoader(MNIST('mnist', train=False, transform=transforms.ToTensor()), batch_size=500)

    cluttered_train, cluttered_valid = load_cluttered_mnist('./mnist/cluttered', batch_size=500, train=True)
    cluttered_test = load_cluttered_mnist('./mnist/cluttered', batch_size=500, train=False)

    baselines = []
    criterion = nn.CrossEntropyLoss()
    device = torch.device('cuda')

    # Experiments
    name =  '2 Layer FC with 256 hiddens for MNIST'
    print('\n\n'+name)
    model = MLP2Layers(28*28, 256, 10)
    optimizer = optim.Adam(model.parameters(), lr=1e-3)
    baselines.append({
        'name': name,
        'acc': train_model(model, optimizer, criterion, device, mnist_train, mnist_test, max_epoch=300)
    })

    name =  '2 Layer FC with 64 hiddens for 60x60 Cluttered MNIST'
    model = MLP2Layers(60*60, 64, 10)
    optimizer = optim.Adam(model.parameters(), lr=0.01, weight_decay=5e-5)
    baselines.append({
        'name': name,
        'acc': train_model(model, optimizer, criterion, device, cluttered_train, cluttered_test, cluttered_valid, max_epoch=300)
    })

    name =  '2 Layer FC with 256 hiddens for 60x60 Cluttered MNIST'
    print('\n\n'+name)
    model = MLP2Layers(60*60, 256, 10)
    optimizer = optim.Adam(model.parameters(), lr=0.01, weight_decay=1e-3)
    baselines.append({
        'name': name,
        'acc': train_model(model, optimizer, criterion, device, cluttered_train, cluttered_test, cluttered_valid, max_epoch=300)
    })

    name =  'Conv(1, 8, 10, 5) + FC with 256 hiddens for 60x60 Cluttered MNIST'
    print('\n\n'+name)
    model = Conv2Layers(10)
    optimizer = optim.Adam(model.parameters(), lr=1e-3, weight_decay=0.003)
    baselines.append({
        'name': name,
        'acc': train_model(model, optimizer, criterion, device, cluttered_train, cluttered_test, cluttered_valid, max_epoch=600)
    })

    name =  'ConvNet for 60x60 Cluttered MNIST'
    print('\n\n'+name)
    model = ConvNet(10)
    optimizer = optim.Adam(model.parameters(), lr=1e-3, weight_decay=0.003)
    baselines.append({
        'name': name,
        'acc': train_model(model, optimizer, criterion, device, cluttered_train, cluttered_test, cluttered_valid, max_epoch=300)
    })

    for model in baselines:
        print(model['name'], model['acc'])





