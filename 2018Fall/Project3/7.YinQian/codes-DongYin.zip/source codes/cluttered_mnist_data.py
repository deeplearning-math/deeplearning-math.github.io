import torch
from torchvision.datasets import MNIST
from torchvision import transforms
from torch.utils.data import DataLoader, TensorDataset
from torch.utils.data.sampler import SubsetRandomSampler
import numpy as np
from pathlib import Path


def clutter(batch, dataset, out_size=60, n_steps=4):
    n, c, w_i = batch.shape[:3]
    w_o = out_size
    data = np.zeros(shape=(n, c, w_o, w_o), dtype=np.float32)
    for k in range(n):
        i, j = np.random.randint(0, w_o-w_i, size=2)
        data[k, :, i:i+w_i, j:j+w_i] += batch[k]
        for _ in range(n_steps):
            clt = dataset[np.random.randint(0, len(dataset) - 1)]
            c1, c2 = np.random.randint(0, w_i - 8, size=2)
            i1, i2 = np.random.randint(0, w_o - 8, size=2)
            data[k, :, i1:i1+8, i2:i2+8] += clt[:, c1:c1+8, c2:c2+8]
    data = np.clip(data, 0., 1.)
    return data


def load_cluttered_mnist(root, batch_size, random_seed, valid_size=0.1,
                         shuffle=True, num_workers=1, pin_memory=False, train=True):

    fpath = Path(root) / ('train.pt' if train else 'test.pt')
    dataset = TensorDataset(*torch.load(fpath))

    if train:
        num_train = len(dataset)
        indices = list(range(num_train))
        split = int(np.floor(valid_size * num_train))

        if shuffle:
            np.random.seed(random_seed)
            np.random.shuffle(indices)

        train_idx, valid_idx = indices[split:], indices[:split]

        train_sampler = SubsetRandomSampler(train_idx)
        valid_sampler = SubsetRandomSampler(valid_idx)

        train_loader = torch.utils.data.DataLoader(
            dataset, batch_size=batch_size, sampler=train_sampler,
            num_workers=num_workers, pin_memory=pin_memory)

        valid_loader = torch.utils.data.DataLoader(
            dataset, batch_size=batch_size, sampler=valid_sampler,
            num_workers=num_workers, pin_memory=pin_memory)

        return train_loader, valid_loader

    else:
        test_loader = torch.utils.data.DataLoader(
            dataset, batch_size=batch_size, shuffle=False,
            num_workers=num_workers, pin_memory=pin_memory)

        return test_loader


if __name__ == '__main__':
    np.random.seed(75)

    def get_cluttered_mnist(dataset):
        dataloader = DataLoader(dataset, batch_size=500)
        allsamples, _ = zip(*dataset)
        cluttered = []
        labels = []
        for samples, ys in dataloader:
            cluttered.append(clutter(samples, allsamples))
            labels.append(ys)
        cluttered = torch.FloatTensor(np.concatenate(cluttered, axis=0))
        labels = torch.cat(labels)
        return cluttered, labels

    mnist_train = MNIST('mnist', download=True, transform=transforms.ToTensor())
    torch.save(get_cluttered_mnist(mnist_train), '.data/cluttered/train.pt')

    mnist_test = MNIST('mnist', train=False, transform=transforms.ToTensor())
    torch.save(get_cluttered_mnist(mnist_test), './data/cluttered/test.pt')

    print('Cluttered MNIST Dataset is generated!')
