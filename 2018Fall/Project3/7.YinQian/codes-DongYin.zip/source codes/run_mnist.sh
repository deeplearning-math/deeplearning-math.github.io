for num_glimpses in {2..7}
do
    python main.py --num_glimpses $num_glimpses --patch_size 8 --glimpse_scale 1 --dataset mnist
done
