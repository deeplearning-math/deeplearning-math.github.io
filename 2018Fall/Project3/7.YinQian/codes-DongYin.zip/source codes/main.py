import torch
from trainer import Trainer
from config import get_config
from utils import prepare_dirs, save_config
from data_loader import get_test_loader, get_train_valid_loader
from cluttered_mnist_data import load_cluttered_mnist


def main(config):

    prepare_dirs(config)

    torch.manual_seed(config.random_seed)
    kwargs = {}

    print(config.dataset)

    if config.dataset == 'mnist':
        if config.use_gpu:
            torch.cuda.manual_seed(config.random_seed)
            kwargs = {'num_workers': 0, 'pin_memory': True}

        train_valid_loader = get_train_valid_loader(config.data_dir, config.batch_size,
                                                    config.random_seed, config.valid_size,
                                                    config.shuffle, **kwargs)
        test_loader = get_test_loader(config.data_dir, config.batch_size, **kwargs)

        trainer = Trainer(config, train_valid_loader, test_loader)

        save_config(config)
        trainer.train()
        trainer.test()

    elif config.dataset == 'cluttered_mnist':
        if config.use_gpu:
            torch.cuda.manual_seed(config.random_seed)
            kwargs = {'num_workers': 0, 'pin_memory': True}

        train_valid_loader = load_cluttered_mnist('./data/cluttered', config.batch_size,
                                                  config.random_seed, config.valid_size,
                                                  config.shuffle, **kwargs, train=True)
        test_loader = load_cluttered_mnist('./data/cluttered', config.batch_size,
                                           config.random_seed, **kwargs, train=False)

        trainer = Trainer(config, train_valid_loader, test_loader)

        save_config(config)
        trainer.train()
        trainer.test()


if __name__ == '__main__':
    config, unparsed = get_config()
    main(config)
