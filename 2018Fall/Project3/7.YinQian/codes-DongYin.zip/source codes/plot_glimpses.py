import pickle
import argparse
import numpy as np
import matplotlib.pyplot as plt
from utils import denormalize, bounding_box


def parse_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plot_dir', type=str, required=True,
                        help='path to directory containing pickle dumps')
    parser.add_argument('--epoch', type=int, required=True,
                        help='epoch of desired plot')
    parser = vars(parser.parse_args())
    return parser['plot_dir'], parser['epoch']


def main(plot_dir, epoch):

    glimpses = pickle.load(open(plot_dir + 'g_{}.p'.format(epoch), 'rb'))
    locations = pickle.load(open(plot_dir + 'l_{}.p'.format(epoch), 'rb'))
    glimpses = np.concatenate(glimpses)

    if len(plot_dir.split('_')) == 8:
        size = int(plot_dir.split('_')[5][0])
    else:
        size = int(plot_dir.split('_')[6][0:2])

    img_shape = glimpses.shape[1]
    coords = [denormalize(img_shape, l) for l in locations]

    fig, ax = plt.subplots()

    ax.imshow(glimpses[8], cmap='Greys_r')
    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)

    c = coords[4]
    c1 = c[8]
    rect = bounding_box(c1[0], c1[1], size, color='r')
    ax.add_patch(rect)

    plt.show()


if __name__ == '__main__':
    args = parse_arguments()
    main(*args)
