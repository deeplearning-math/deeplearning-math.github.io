for num_glimpses in {4..8}
do
    python main.py --num_glimpses $num_glimpses --patch_size 12 --glimpse_scale 3 --dataset cluttered_mnist
done
