
import tensorflow as tf
import numpy as np
import math
import matplotlib.pyplot as plt
import time


losses = []

lambd = 1
regularizer = 0
learn_rate = 5e-4
archi = [16,32,32,64,128]
# archi = [32,64,64,128,128]
keep_prob = 1
stddev = 0.1#0.05
regularizer = tf.contrib.layers.l2_regularizer(scale=5e-4)

TotTrainData = 35000
TotTestData = 5000
num_iters = 1000000
num_iters2 = 200
batch_size = 500
num_batch = (TotTrainData//batch_size)
TotTrainData = num_batch*batch_size

input_dim1 = 64
input_dim2 = 64
output_dim = 1

dataset_pre = np.load('dimg.npy')
# dataset_pre = dataset_pre[:40000]
# dataset0 = np.load('ellpack_z.npy')
# dataset_temp = np.zeros((dataset0.shape[0],dataset0.shape[1]))
# for i in range(dataset0.shape[1]):
#     dataset_temp[:,i] = (dataset0[:,i]-np.amin(dataset0[:,i]))/(np.amax(dataset0[:,i])-np.amin(dataset0[:,i]))
dd1 = np.loadtxt('poisson_square.csv',delimiter=',')
dd2 = np.loadtxt('poisson_circ.csv',delimiter=',')
dataset2_pre = np.concatenate((dd1,dd2),axis=0)
# dataset2_pre = np.load('dp.npy')
# dataset2_pre = dataset2_pre[:40000]
# print(dataset2_pre.shape)
dataset = np.zeros((dataset_pre.shape[0],dataset_pre.shape[1]))
dataset2 = np.zeros((dataset2_pre.shape[0],1))

np.random.seed(1000)
dataset_index = np.random.permutation(dataset_pre.shape[0])
for i in range(dataset_pre.shape[0]):
	dataset[i,:] = dataset_pre[dataset_index[i],:]
	dataset2[i,:] = dataset2_pre[dataset_index[i]]
# dataset2 = dataset2[:,5].reshape(dataset2.shape[0],1)

# dataset2 = dataset2_pre[:,0].reshape(dataset2_pre.shape[0],1)

dataset_reshaped = dataset.reshape((dataset.shape[0],input_dim1,input_dim2,1))
x_data = dataset_reshaped[0:TotTrainData,:,:,:]
y_data_pre = dataset2[0:TotTrainData,:].reshape(TotTrainData,output_dim)
x_data_pred = dataset_reshaped[0:1000,:,:,:]
y_data_pred_pre = dataset2[0:1000,:].reshape(1000,output_dim)
x_data_test = dataset_reshaped[TotTrainData:TotTrainData+TotTestData,:,:,:]
y_data_test_pre = dataset2[TotTrainData:TotTrainData+TotTestData,:].reshape(TotTestData,output_dim)

y_data = np.zeros((y_data_pre.shape[0],y_data_pre.shape[1]))
y_data_pred = np.zeros((y_data_pred_pre.shape[0],y_data_pred_pre.shape[1]))
y_data_test = np.zeros((y_data_test_pre.shape[0],y_data_test_pre.shape[1]))
for i in range(y_data.shape[1]):
    y_data[:,i] = (y_data_pre[:,i]-np.amin(y_data_pre[:,i]))/(np.amax(y_data_pre[:,i])-np.amin(y_data_pre[:,i]))
    y_data_pred[:,i] = (y_data_pred_pre[:,i]-np.amin(y_data_pre[:,i]))/(np.amax(y_data_pre[:,i])-np.amin(y_data_pre[:,i]))
    y_data_test[:,i] = (y_data_test_pre[:,i]-np.amin(y_data_pre[:,i]))/(np.amax(y_data_pre[:,i])-np.amin(y_data_pre[:,i]))
    # dataset2_pre[:,i] = (dataset1[:,i]-np.mean(dataset1[:,i]))/(np.std(dataset1[:,i]))
# print(np.amax(dataset),np.amin(dataset))
# print(np.amax(dataset2),np.amin(dataset2))
print('--load finish--')


def get_loss(loss):
    print(loss)
    losses.append(loss)

def conv2d(x, w1, w2, win, wout, wx, wy):
	with tf.name_scope('mat_pred'):
    # stride [1, x_movement, y_movement, 1]
    # Must have strides[0] = strides[3] = 1
	    w = tf.Variable(tf.truncated_normal([w1,w2,win,wout], stddev=stddev))
	    b = tf.Variable(tf.zeros([wout]))
	    tf.add_to_collection(tf.GraphKeys.REGULARIZATION_LOSSES, w)
	    return tf.nn.relu((tf.nn.conv2d(x, w, strides=[1,wx,wy,1], padding='SAME'))+b)

	
def add_layer(L_Prev, num_nodes_LPrev, num_nodes_LX, activation_LX):
	with tf.name_scope('mat_pred'):
		Weights_LX = tf.Variable(tf.random_normal([num_nodes_LPrev,num_nodes_LX],stddev=stddev),name = 'w')
		tf.add_to_collection(tf.GraphKeys.REGULARIZATION_LOSSES, Weights_LX)
		biases_LX = tf.Variable(tf.zeros([1,num_nodes_LX]),name = 'b')
		xW_plus_b_LX = tf.matmul(L_Prev,Weights_LX)+biases_LX
		if activation_LX is None:
			LX = xW_plus_b_LX
		else:
			LX = tf.add(xW_plus_b_LX,activation_LX(xW_plus_b_LX))
		return LX



x = tf.placeholder(tf.float32, [None, input_dim1, input_dim2, 1])  
y = tf.placeholder(tf.float32, [None, output_dim])

## conv1 layer ##
if True:
	# c1 = conv2d(x,3,3,1,32,2,2)		#20x20x1 --> 10x10x16
	# c2 = conv2d(c1,3,3,32,32,1,1)	#10x10x16 --> 5x5x32
	# c3 = conv2d(c2,3,3,32,64,2,2)	#5x5x32 --> 3x3x32
	# c4 = conv2d(c3,3,3,64,64,1,1)	#3x3x32 --> 2x2x64
	# c5 = conv2d(c4,3,3,64,128,2,2)	#2x2x64 --> 1x1x64
	# c6 = conv2d(c5,3,3,64,128,2,2)
	# c7 = conv2d(c6,3,3,128,128,2,2)
	# c8 = conv2d(c7,3,3,128,128,2,2)
	# c1 = conv2d(x,3,3,1,16,2,2)		#20x20x1 --> 10x10x16
	# c2 = conv2d(c1,3,3,16,32,2,2)	#10x10x16 --> 5x5x32
	# c3 = conv2d(c2,3,3,32,32,2,2)	#5x5x32 --> 3x3x32
	# c4 = conv2d(c3,3,3,32,32,2,2)	#3x3x32 --> 2x2x64
	# c5 = conv2d(c4,3,3,32,64,2,2)	#2x2x64 --> 1x1x64
	c1 = conv2d(x,3,3,1,archi[0],2,2)		#20x20x1 --> 10x10x16
	c2 = conv2d(c1,3,3,archi[0],archi[1],2,2)	#10x10x16 --> 5x5x32
	c3 = conv2d(c2,3,3,archi[1],archi[2],2,2)	#5x5x32 --> 3x3x32
	c4 = conv2d(c3,3,3,archi[2],archi[3],2,2)	#3x3x32 --> 2x2x64
	c5 = conv2d(c4,3,3,archi[3],archi[4],2,2)	#2x2x64 --> 1x1x64
else:
	c1 = conv2d(x,3,3,1,32,2,2)		#20x20x1 --> 10x10x16
	c2 = conv2d(c1,3,3,32,64,2,2)	#10x10x16 --> 5x5x32
	c3 = conv2d(c2,3,3,64,128,2,2)	#5x5x32 --> 3x3x32
	c4 = conv2d(c3,3,3,128,256,2,2)	#3x3x32 --> 2x2x64
	c5 = conv2d(c4,3,3,256,256,2,2)	#2x2x64 --> 1x1x64

# stride [1, x_movement, y_movement, 1]
#cp1 = tf.layers.average_pooling2d(c1,(18,18),strides=1)


## fully connected layer ##
flat1 = tf.reshape(c5, [-1, 4*archi[4]])
L1 = add_layer(flat1,4*archi[4],128,tf.nn.tanh)
L2 = add_layer(L1,128,32,tf.nn.tanh)
# L3 = add_layer(L2,256,128,tf.nn.tanh)
# L4 = add_layer(L3,128,64,tf.nn.tanh)
# L5 = add_layer(L4,64,32,tf.nn.tanh)
# L6 = add_layer(L5,32,16,tf.nn.tanh)
# L7 = add_layer(L6,16,8,tf.nn.tanh)
# L8 = add_layer(L7,8,4,tf.nn.tanh)
#h_fc1_drop = tf.nn.dropout(L1, keep_prob)

prediction = add_layer(L2,32,output_dim,None)

reg_variables = tf.get_collection(tf.GraphKeys.REGULARIZATION_LOSSES)
reg_term = tf.contrib.layers.apply_regularization(regularizer, reg_variables)

# the error between prediction and real data
loss = tf.reduce_mean(tf.reduce_mean(tf.square(y-prediction))+reg_term)

saver = tf.train.Saver()#tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='mat_pred'))

def FirstOrder():
	train = tf.train.AdamOptimizer(learn_rate).minimize(loss)
	#train = tf.train.GradientDescentOptimizer(learn_rate).minimize(loss)
	iii = 0
	best_loss = 100000#7.7710e-05

	with tf.Session() as sess:
		init = tf.global_variables_initializer()
		sess.run(init)
		# savefileid = 'save_'+str(archi[0])+'_'+str(archi[1])+'_'+str(archi[2])+'_'+str(archi[3])+'_'+str(archi[4])+'/model'
		savefileid = '3save2/model'
		saver.restore(sess, "3save1/model")

		plt.figure()
		plt.ion()

		for step in range(num_iters):
			start = time.time()
			for batch_i in range(num_batch):
				x_batch = x_data[batch_i*batch_size:(batch_i+1)*batch_size,:,:,:]
				y_batch = y_data[batch_i*batch_size:(batch_i+1)*batch_size,:]
				sess.run([train],feed_dict={x:x_batch,y:y_batch})
				losses.append(np.mean(sess.run(loss,feed_dict={x:x_batch,y:y_batch})))
				iii = iii+1
			end = time.time()
			if losses[iii-1] < 1e-9:
				break
			print('iter: {0}, loss = {1}, time = {2}'.format(step,losses[iii-1],(end-start)))
			if (step+1)%10 == 0 :
				if losses[-1] < best_loss:
					saver.save(sess, savefileid)
					best_loss = losses[-1]

			if (step+1)%5 == 0:
				plt.gcf().clear()
				# prediction1 = sess.run(prediction,feed_dict={x:x_data_test})
				# # prediction2 = sess.run(prediction,feed_dict={x:x_data_pred})

				# ### Test data plot ###		
				
				# y_data_test1 = y_data_test[:,0]
				# y_data_test2 = y_data_test[:,1]
				# y_data_test3 = y_data_test[:,2]
				# y_data_test4 = y_data_test[:,3]
				# y_data_test5 = y_data_test[:,4]
				# y_data_test6 = y_data_test[:,5]

				# plt.subplot(2,3,1)
				# plt.scatter(y_data_test1,prediction1[:,0])
				# plt.plot(y_data_test1,y_data_test1,'r-')
				# plt.plot(y_data_test1,y_data_test1+0.05,'c-')
				# plt.plot(y_data_test1,y_data_test1-0.05,'c-')

				# plt.subplot(2,3,2)
				# plt.scatter(y_data_test2,prediction1[:,1])
				# plt.plot(y_data_test2,y_data_test2,'r-')
				# plt.plot(y_data_test2,y_data_test2+0.05,'c-')
				# plt.plot(y_data_test2,y_data_test2-0.05,'c-')

				# plt.subplot(2,3,3)
				# plt.scatter(y_data_test3,prediction1[:,2])
				# plt.plot(y_data_test3,y_data_test3,'r-')
				# plt.plot(y_data_test3,y_data_test3+0.05,'c-')
				# plt.plot(y_data_test3,y_data_test3-0.05,'c-')

				# plt.subplot(2,3,4)
				# plt.scatter(y_data_test4,prediction1[:,3])
				# plt.plot(y_data_test4,y_data_test4,'r-')
				# plt.plot(y_data_test4,y_data_test4+0.05,'c-')
				# plt.plot(y_data_test4,y_data_test4-0.05,'c-')

				# plt.subplot(2,3,5)
				# plt.scatter(y_data_test5,prediction1[:,4])
				# plt.plot(y_data_test5,y_data_test5,'r-')
				# plt.plot(y_data_test5,y_data_test5+0.05,'c-')
				# plt.plot(y_data_test5,y_data_test5-0.05,'c-')

				# plt.subplot(2,3,6)
				# plt.scatter(y_data_test6,prediction1[:,5])
				# plt.plot(y_data_test6,y_data_test6,'r-')
				# plt.plot(y_data_test6,y_data_test6+0.05,'c-')
				# plt.plot(y_data_test6,y_data_test6-0.05,'c-')

				prediction1 = sess.run(prediction,feed_dict={x:x_data_test})
				prediction2 = sess.run(prediction,feed_dict={x:x_data_pred})

				### Test data plot ###		
				
				y_data_test1 = y_data_test[:,0]
				y_data_test2 = y_data_pred[:,0]

				plt.subplot(1,2,1)
				plt.scatter(y_data_test1,prediction1[:,0])
				plt.plot(y_data_test1,y_data_test1,'r-')
				plt.plot(y_data_test1,y_data_test1+0.05,'c-')
				plt.plot(y_data_test1,y_data_test1-0.05,'c-')

				plt.subplot(1,2,2)
				plt.scatter(y_data_test2,prediction2[:,0])
				plt.plot(y_data_test2,y_data_test2,'r-')
				plt.plot(y_data_test2,y_data_test2+0.05,'c-')
				plt.plot(y_data_test2,y_data_test2-0.05,'c-')

				plt.draw(); plt.pause(0.01)
		plt.ioff
		plt.show()

		
def SecondOrderOptimizer():
	train = tf.contrib.opt.ScipyOptimizerInterface(loss, options={'maxiter': num_iters2})
    
	with tf.Session() as sess:
		init = tf.global_variables_initializer()
		sess.run(init)
		saver.restore(sess, "save_cnn_reg5/model")
        #writer = tf.summary.FileWriter("logs/",sess.graph)
		# sess.run(tf.global_variables_initializer())
		train.minimize(sess, fetches=[loss],loss_callback=get_loss,feed_dict={x:x_data,y:y_data})
		prediction1 = sess.run(prediction,feed_dict={x:x_data_test})
		prediction2 = sess.run(prediction,feed_dict={x:x_data_pred})
		saver.save(sess, "save_cnn_reg5/model")


	y_data_test1 = y_data_test[:,0]
	y_data_test2 = y_data_pred[:,0]

	plt.subplot(1,2,1)
	plt.scatter(y_data_test1,prediction1[:,0])
	plt.plot(y_data_test1,y_data_test1,'r-')
	plt.plot(y_data_test1,y_data_test1+0.05,'c-')
	plt.plot(y_data_test1,y_data_test1-0.05,'c-')

	plt.subplot(1,2,2)
	plt.scatter(y_data_test2,prediction2[:,0])
	plt.plot(y_data_test2,y_data_test2,'r-')
	plt.plot(y_data_test2,y_data_test2+0.05,'c-')
	plt.plot(y_data_test2,y_data_test2-0.05,'c-')


def Test_func():
	sess = tf.Session()
	init = tf.global_variables_initializer()
	sess.run(init)
	savefileid = 'save6mat/model'#'save_'+str(archi[0])+'_'+str(archi[1])+'_'+str(archi[2])+'_'+str(archi[3])+'_'+str(archi[4])+'/model'
	print(savefileid)
	saver.restore(sess, savefileid)
	from time import time
	start_time = time()
	prediction1 = sess.run(prediction,feed_dict={x:x_data_test})
	print(x_data_test.shape[0])
	end_time = time()
	timetaken = end_time-start_time
	hours, rest = divmod(timetaken,3600)
	minutes, seconds = divmod(rest, 60)
	print(seconds)
	# prediction2 = sess.run(prediction,feed_dict={x:x_data_pred})
	accuracy_arr = np.zeros((prediction1.shape[0],6))


	for i in range(prediction1.shape[0]):
		for j in range(prediction1.shape[1]):
			accuracy_arr[i,j] = np.absolute(prediction1[i,j]-y_data_test[i,j])#/y_data_test[i,j]

	mean_acc = np.mean(accuracy_arr,axis=0)
	rel_mean = np.zeros((prediction1.shape[1]))
	for i in range(prediction1.shape[1]):
		rel_mean[i] = mean_acc[i]/np.mean(y_data_test[:,i])
	print('relative accuracy:',rel_mean.reshape(6,1))
	# np.savetxt('ttttttt.csv',rel_mean.reshape(6,1),delimiter=',')

	### Test data plot ###		
	
	y_data_test1 = y_data_test[:,0]
	# y_data_test2 = y_data_pred[:,0]
	y_data_test2 = y_data_test[:,1]
	y_data_test3 = y_data_test[:,2]
	y_data_test4 = y_data_test[:,3]
	y_data_test5 = y_data_test[:,4]
	y_data_test6 = y_data_test[:,5]

	# plt.subplot(1,2,1)
	# plt.scatter(y_data_test1,prediction1[:,0])
	# plt.plot(y_data_test1,y_data_test1,'r-')
	# plt.plot(y_data_test1,y_data_test1+0.05,'c-')
	# plt.plot(y_data_test1,y_data_test1-0.05,'c-')

	# plt.subplot(1,2,2)
	# plt.scatter(y_data_test2,prediction2[:,0])
	# plt.plot(y_data_test2,y_data_test2,'r-')
	# plt.plot(y_data_test2,y_data_test2+0.05,'c-')
	# plt.plot(y_data_test2,y_data_test2-0.05,'c-')

	plt.subplot(2,3,1)
	plt.scatter(y_data_test1,prediction1[:,0])
	plt.plot(y_data_test1,y_data_test1,'r-')
	plt.plot(y_data_test1,y_data_test1+0.05,'c-')
	plt.plot(y_data_test1,y_data_test1-0.05,'c-')

	plt.subplot(2,3,2)
	plt.scatter(y_data_test2,prediction1[:,1])
	plt.plot(y_data_test2,y_data_test2,'r-')
	plt.plot(y_data_test2,y_data_test2+0.05,'c-')
	plt.plot(y_data_test2,y_data_test2-0.05,'c-')

	plt.subplot(2,3,3)
	plt.scatter(y_data_test3,prediction1[:,2])
	plt.plot(y_data_test3,y_data_test3,'r-')
	plt.plot(y_data_test3,y_data_test3+0.05,'c-')
	plt.plot(y_data_test3,y_data_test3-0.05,'c-')

	plt.subplot(2,3,4)
	plt.scatter(y_data_test4,prediction1[:,3])
	plt.plot(y_data_test4,y_data_test4,'r-')
	plt.plot(y_data_test4,y_data_test4+0.05,'c-')
	plt.plot(y_data_test4,y_data_test4-0.05,'c-')

	plt.subplot(2,3,5)
	plt.scatter(y_data_test5,prediction1[:,4])
	plt.plot(y_data_test5,y_data_test5,'r-')
	plt.plot(y_data_test5,y_data_test5+0.05,'c-')
	plt.plot(y_data_test5,y_data_test5-0.05,'c-')

	plt.subplot(2,3,6)
	plt.scatter(y_data_test6,prediction1[:,5])
	plt.plot(y_data_test6,y_data_test6,'r-')
	plt.plot(y_data_test6,y_data_test6+0.05,'c-')
	plt.plot(y_data_test6,y_data_test6-0.05,'c-')


losses = []
FirstOrder()
# SecondOrderOptimizer()
# Test_func()
plt.show()

		

