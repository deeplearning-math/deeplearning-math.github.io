import numpy as np
from sklearn.decomposition import PCA
fea0=np.loadtxt('feature_square.csv',delimiter=',')
fea1=np.loadtxt('feature_circ.csv',delimiter=',')
feap0=fea0
feap1=fea1
feap=np.concatenate((feap0,feap1),axis=0)
X = feap[0:80000,:].reshape(80000,391)
X=(X-np.mean(X))/np.std(X)
#feap=np.zeros((28,391))
#for i in range(28):
#    feap[i,:]=fea[i*3,:];
#X = feap[:,:].reshape(28,391)
X_embedded = PCA(n_components=2).fit_transform(X)
print(X_embedded.shape)
np.savetxt('feature_2_part.csv',X_embedded,delimiter=',')
label=np.ones((80000,1))
label[40000:80000,0]=0
np.savetxt('label.csv',label,delimiter=',')