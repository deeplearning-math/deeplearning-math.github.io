fea1=csvread('feature_square.csv');
fea2=csvread('feature_circ.csv');
label=ones(80000,1);
label(40001:80000,1)=0;
fea=[fea1;fea2];
randIndex=randperm(size(fea,1));
feaN=fea(randIndex,:);
labelN=label(randIndex,:);

feac=feaN(1:72000,:);
feat=feaN(72001:end,:);
labc=labelN(1:72000,:);
labt=labelN(72001:end,:);
SVMModel=fitcsvm(feac,labc);
num1=size(labc,1);num2=size(labt,1);
labeltrain= predict(SVMModel,feac);
labeltest = predict(SVMModel,feat);

training_accuracy=sum(abs(labeltrain-labc)==0)/num1;
testing_accuracy=sum(abs(labeltest-labt)==0)/num2;

