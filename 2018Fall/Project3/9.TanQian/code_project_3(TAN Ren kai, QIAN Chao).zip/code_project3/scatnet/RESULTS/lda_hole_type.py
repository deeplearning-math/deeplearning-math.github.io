import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
#import random
np.random.seed(1)
# Importing the dataset
# dataset = pd.read_csv('Wine.csv')
# X = dataset.iloc[:, 0:13].values
# y = dataset.iloc[:, 13].values

datasize =80000
feature_size=391
#a=np.loadtxt('feature.csv',delimiter=',')
fea0=np.loadtxt('feature_square.csv',delimiter=',')
fea1=np.loadtxt('feature_circ.csv',delimiter=',')
feap0=fea0
feap1=fea1
a=np.concatenate((feap0,feap1),axis=0)
b=np.loadtxt('label.csv',delimiter=',')



print(a.shape)
print(b.shape)
print('accuracy')


X00=a
y00=b
y0 = y00[0:datasize].reshape(datasize,1)
X0 = 1/np.amax(X00)*X00


X = np.zeros((datasize,feature_size))
y = np.zeros((datasize,1))
perm_index = np.random.permutation(datasize)
for i in range(datasize):
    X[i] = X0[perm_index[i]]
    y[i] = y0[perm_index[i]]

# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.1, random_state = 0)

# Feature Scaling
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)

# Applying LDA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
lda = LDA(n_components = 2)
X_train = lda.fit_transform(X_train, y_train)
X_test = lda.transform(X_test)

# Fitting Logistic Regression to the Training set
from sklearn.linear_model import LogisticRegression
classifier = LogisticRegression(random_state = 0)
classifier.fit(X_train, y_train)

# Predicting the Test set results
y_pred = classifier.predict(X_test)

# Making the Confusion Matrix
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, y_pred)

# Visualising the Training set results
# from matplotlib.colors import ListedColormap
X_set, y_set = X_train, y_train
print('train predict:',classifier.predict(X_set[:20]))
print('train real  :',y_set[:20].reshape(1,20))


# Visualising the Test set results
# from matplotlib.colors import ListedColormap
X_set, y_set = X_test, y_test
print('test predict:',classifier.predict(X_set[:20]))
print('test_real  :',y_set[:20].reshape(1,20))

train_accuracy1=np.sum(np.abs(classifier.predict(X_train).reshape(72000,1)-y_train)==0)/72000
test_accuracy2=np.sum(np.abs(classifier.predict(X_test).reshape(8000,1)-y_test)==0)/8000
#bad_accuracy=sum(y_test*classifier.predict(X_test).reshape(3000,1))/sum(y_test)
#good_accuracy=sum((y_test==0)*(classifier.predict(X_test).reshape(3000,1)==0))/sum(y_test==0)
print(train_accuracy1)
print(test_accuracy2)
#print(bad_accuracy)
#print(good_accuracy)
