fea=csvread('feature_2_circ.csv');
label=load('label_volfrac_circ.txt');
[B,I]=sort(label);
ln=[0.78 0.82 1.0];
num=zeros(3,1);
num2=ones(3+1,1);
for i=1:3
    num(i,1)=sum(label==ln(i));
    num2(i+1,1)=sum(num(1:i,1))+1;
end

color={'r.';'b.';'g.'};
figure(1);
for i=1:3
a=num2(i,1);
b=num2(i+1)-1;
plot(fea(I(a:b),1),fea(I(a:b),2),color{i},'MarkerSize',10);
hold on;
end
legend('0.78 volume fraction','0.82 volume fraction','1.0 volume fraction');