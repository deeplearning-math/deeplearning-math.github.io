import numpy as np
from sklearn.decomposition import PCA
feap=np.loadtxt('feature_square.csv',delimiter=',')
X = feap[0:40000,:].reshape(40000,391)
X=(X-np.mean(X))/np.std(X)
#feap=np.zeros((28,391))
#for i in range(28):
#    feap[i,:]=fea[i*3,:];
#X = feap[:,:].reshape(28,391)
X_embedded = PCA(n_components=2).fit_transform(X)
print(X_embedded.shape)
np.savetxt('feature_2_square.csv',X_embedded,delimiter=',')