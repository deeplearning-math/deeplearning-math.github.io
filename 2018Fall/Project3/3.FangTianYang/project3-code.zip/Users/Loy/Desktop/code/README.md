
# README

## Prerequisite

The programs use `tqdm` library to display a progress bar. Install it with:

```
pip3 install tqdm
```


## RAM

To train RAM models, in `ram` directory run the following command:

```
python3 main.py --data-dir <dataset_dir>
```


## CNN

To train CNN models, in `cnn` directory execute:

```
python3 main.py --data-dir <dataset_dir>
```

