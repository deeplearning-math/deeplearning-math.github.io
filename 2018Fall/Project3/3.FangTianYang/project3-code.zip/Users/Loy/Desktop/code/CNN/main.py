from __future__ import print_function

import argparse
import time
import sys
import os
sys.path.append('/Users/Loy/.local/share/virtualenvs/project2-LB_FCPEM/lib/python3.7/site-packages/')

from tqdm import tqdm
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torchvision import datasets, transforms


class AverageMeter(object):
    """
    Computes and stores the average and
    current value.
    """
    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        # self.conv1 = nn.Conv2d(1, 8, kernel_size=10, stride=5)
        # self.fc1 = nn.Linear(11 * 11 * 8, 10)
        self.conv1 = nn.Conv2d(1, 10, kernel_size=6, stride=2)
        self.conv2 = nn.Conv2d(10, 20, kernel_size=7, stride=1)
        self.conv2_drop = nn.Dropout2d()
        self.fc1 = nn.Linear(320, 50)
        self.fc2 = nn.Linear(50, 10)

    def forward(self, x):
        # x = F.relu(self.conv1(x))
        # x = x.view(-1, 11 * 11 * 8)
        # x = F.relu(self.fc1(x))
        # return F.log_softmax(x, dim=1)
        x = F.relu(F.max_pool2d(self.conv1(x), 2))
        x = F.relu(F.max_pool2d(self.conv2_drop(self.conv2(x)), 2))
        x = x.view(-1, 320)
        x = F.relu(self.fc1(x))
        x = F.dropout(x, training=self.training)
        x = self.fc2(x)
        return F.log_softmax(x, dim=1)


def train(args, model, device, train_loader, optimizer, scheduler, epoch):
    model.train()
    tic = time.time()
    loss_avg = AverageMeter()
    acc_avg = AverageMeter()

    with tqdm(total=len(train_loader.dataset)) as pbar:
        for batch_idx, (data, target) in enumerate(train_loader):
            data, target = data.to(device), target.to(device)
            optimizer.zero_grad()
            output = model(data)
            loss = F.nll_loss(output, target)
            loss.backward()
            optimizer.step()
            pred = output.max(1, keepdim=True)[1]
            correct = pred.eq(target.view_as(pred)).sum().item()
            # import pdb; pdb.set_trace()

            loss_avg.update(loss.item())
            acc_avg.update(100. * correct / len(target))

            toc = time.time()
            desc = "{:.1f}s - loss: {:6.3f} - acc: {:6.3f}".format(
                toc-tic, loss.item(), 100. * correct / len(target)
            )
            pbar.set_description(desc)
            pbar.update(len(data))

    scheduler.step(loss_avg.avg)
    return loss_avg.avg, acc_avg.avg


def test(args, model, device, test_loader):
    model.eval()
    test_loss = 0
    correct = 0
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            output = model(data)
            test_loss += F.nll_loss(output, target, reduction='sum').item() # sum up batch loss
            pred = output.max(1, keepdim=True)[1] # get the index of the max log-probability
            # import pdb; pdb.set_trace()
            correct += pred.eq(target.view_as(pred)).sum().item()

    test_loss /= len(test_loader.dataset)
    test_acc = 100. * correct / len(test_loader.dataset)
    return test_loss, test_acc


def main():
    # Training settings
    parser = argparse.ArgumentParser(description='PyTorch MNIST Example')
    parser.add_argument('--data-dir', type=str, default='./data',
                        help='the directory containing training dataset')
    parser.add_argument('--batch-size', type=int, default=64, metavar='N',
                        help='input batch size for training (default: 64)')
    parser.add_argument('--test-batch-size', type=int, default=1000, metavar='N',
                        help='input batch size for testing (default: 1000)')
    parser.add_argument('--epochs', type=int, default=10, metavar='N',
                        help='number of epochs to train (default: 10)')
    parser.add_argument('--lr', type=float, default=0.01, metavar='LR',
                        help='learning rate (default: 0.01)')
    parser.add_argument('--momentum', type=float, default=0.5, metavar='M',
                        help='SGD momentum (default: 0.5)')
    parser.add_argument('--no-cuda', action='store_true', default=False,
                        help='disables CUDA training')
    parser.add_argument('--seed', type=int, default=1, metavar='S',
                        help='random seed (default: 1)')
    parser.add_argument('--log-interval', type=int, default=10, metavar='N',
                        help='how many batches to wait before logging training status')
    parser.add_argument('--resume', default=False, action='store_true',
                        help='whether to resume from checkpoint')
    parser.add_argument('--ckpt-dir', type=str,
                        help='the directory for storing checkpoints')
    args = parser.parse_args()
    use_cuda = not args.no_cuda and torch.cuda.is_available()

    # torch.manual_seed(args.seed)

    device = torch.device("cuda" if use_cuda else "cpu")

    kwargs = {'num_workers': 1, 'pin_memory': True} if use_cuda else {}
    train_loader = torch.utils.data.DataLoader(
        datasets.MNIST(args.data_dir, train=True, download=True,
                       transform=transforms.Compose([
                           transforms.ToTensor(),
                           transforms.Normalize((0.1307,), (0.3081,))
                       ])),
        batch_size=args.batch_size, shuffle=True, **kwargs)
    test_loader = torch.utils.data.DataLoader(
        datasets.MNIST(args.data_dir, train=False, transform=transforms.Compose([
                           transforms.ToTensor(),
                           transforms.Normalize((0.1307,), (0.3081,))
                       ])),
        batch_size=args.test_batch_size, shuffle=True, **kwargs)


    model = Net().to(device)
    optimizer = optim.SGD(model.parameters(), lr=args.lr, momentum=args.momentum)
    # optimizer = optim.RMSprop(model.parameters(), lr=args.lr)
    # optimizer = optim.Adam(model.parameters(), lr=args.lr)
    scheduler = ReduceLROnPlateau(optimizer, 'min', patience=10, verbose=True)

    if args.resume:
        ckpt = torch.load(os.path.join(args.ckpt_dir, '60x60_ckpt.pth.tar'))
        start_epoch = ckpt['epoch']
        model.load_state_dict(ckpt['model_state'])
        optimizer.load_state_dict(ckpt['optim_state'])
        scheduler.load_state_dict(ckpt['sched_state'])
    else:
        start_epoch = 1

    for epoch in range(start_epoch, args.epochs + 1):
        print(f'\nEpoch: {epoch}/{args.epochs} - LR: {optimizer.param_groups[0]["lr"]}')
        train_loss, train_acc = train(args, model, device, train_loader, optimizer, scheduler, epoch)
        test_loss, test_acc = test(args, model, device, test_loader)
        print(f'train loss: {train_loss:.3f} - train acc: {train_acc:.3f}'
              f' - test loss: {test_loss:.3f} - test acc: {test_acc:.3f}')

        if args.ckpt_dir:
            torch.save({
                'epoch': epoch + 1,
                'model_state': model.state_dict(),
                'optim_state': optimizer.state_dict(),
                'sched_state': scheduler.state_dict()
            }, os.path.join(args.ckpt_dir, '60x60_ckpt.pth.tar'))


if __name__ == '__main__':
    main()
