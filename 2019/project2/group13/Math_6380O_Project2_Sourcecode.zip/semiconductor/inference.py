import torch
import datetime
import torch.nn as nn
import torch.optim as optim
import numpy as np
import torchvision
import matplotlib.pyplot as plt
import time
import os
import copy
from model import build_data_loader, base_model, create_model
import tqdm
from flashtorch.saliency import Backprop
from PIL import Image

base_dir = r'logs/1214_0131/'
model_path = os.path.join(base_dir, 'model.pt')
data_dir = r"data/test"
output_path = os.path.join(base_dir, 'outputs.csv')
# Number of classes in the dataset
num_classes = 2

# Batch size for training (change depending on how much memory you have)
batch_size = 64

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


def run_eval(model, dataloader):
    running_tp = running_tn = running_fp = running_fn = 0
    for (inputs, labels), (filepath, _) in tqdm.tqdm(dataloader):
        with torch.no_grad():
            inputs = inputs[:, 0:1, ...]
            inputs = inputs.to(device)
            outputs = model(inputs)
            _, preds = torch.max(outputs, 1)
            preds = preds.cpu()

            running_tp += torch.sum((preds == 1) & (labels.data == 1))
            running_fp += torch.sum((preds == 1) & (labels.data == 0))
            running_tn += torch.sum((preds == 0) & (labels.data == 0))
            running_fn += torch.sum((preds == 0) & (labels.data == 1))

    epoch_precision = running_tp.double() / (running_tp + running_fp)
    epoch_recall = running_tp.double() / (running_tp + running_fn)
    epoch_acc = (running_tp + running_tn).double() / (running_tp + running_tn + running_fp + running_fn)
    epoch_f1 = 2 * epoch_precision * epoch_recall / (epoch_precision + epoch_recall)

    print('Eval: prec=%.4f, recall=%.4f, acc=%.4f, f1=%.4f' % (
        epoch_precision, epoch_recall, epoch_acc, epoch_f1
    ))

activation = {}
def get_activation(name):
    def hook(model, input, output):
        activation[name] = output.detach().cpu().numpy()
    return hook

def save_figures(model, inputs, labels, filepaths):
    inputs = inputs.detach().cpu()
    labels = labels.detach().cpu()
    inputs = inputs.numpy()
    activation['base'] = inputs

    print('Start visualization')
    for name, item in tqdm.tqdm(activation.items()): # item: [B, C, H, W]
        break
        for c in range(min(item.shape[1], 16)):
            filename = 'layer_%s_channel_%d.png' % (name, c)
            for row in range(3):
                for col in range(3):
                    id = row * 3 + col + 1
                    plt.subplot(3, 3, id)
                    fig = item[id-1, c]
                    if np.max(fig) - np.min(fig) < 1e-3:
                        fig *= 0.0
                    fig = (fig - np.min(fig)) / (np.max(fig) - np.min(fig))
                    plt.imshow(fig)
                    plt.axis('off')
            plt.subplots_adjust(wspace=0.01, hspace=0.01)
            plt.savefig(filename, bbox_inches='tight')

    for i in range(len(inputs)):
        input_sample = torch.Tensor(inputs[i:i+1])
        input_sample.requires_grad = True
        backprop = Backprop(model)
        backprop.calculate_gradients(input_sample, labels[i], guided=True, use_gpu=False)
        grads = input_sample.grad
        print(filepaths[i], torch.max(grads), torch.min(grads))
        plt.subplot(1, 2, 1)
        plt.imshow(grads[0, 0])
        plt.subplot(1, 2, 2)
        img = Image.open(filepaths[i])
        img = img.convert('RGB')
        plt.imshow(img)
        label = filepaths[i].split('/')[2]
        plt.savefig('saliency_%d_%s.png' % (i, label))


def run_inference(model, dataset):
    fw = open(output_path, 'w')
    print('Total %d batches for inference, batch size=%d' % (len(dataset), batch_size))
    fw.write('id,label\n')
    for (inputs, _), (filepath, _) in tqdm.tqdm(dataset):
        with torch.no_grad():
            inputs = inputs[:, 0:1, ...]
            inputs = inputs.to(device)
            outputs = model(inputs)

            pred = torch.argmax(outputs, -1).detach().cpu().numpy()
            for i in range(len(inputs)):
                filename = os.path.split(filepath[i])[-1].split('.')[-2]
                fw.write(filename + ',' + str(1 - pred[i]) + '\n')

def main():
    image_datasets, dataloaders_dict = build_data_loader(['test', 'val'], shuffle=True)
    model = create_model(False)
    model.load_state_dict(torch.load(model_path))
    dataset = dataloaders_dict['test']
    model = model.to(device)
    # model.eval()
    # run_eval(model, dataloaders_dict['val'])

    for i, layer in enumerate(model.features):
        if str(layer).startswith('_Dense') or str(layer).startswith('Conv'):
            layer.register_forward_hook(get_activation(str(i+1)))

    for (inputs, labels), (filepath, _) in tqdm.tqdm(dataloaders_dict['val']):
        model.to(torch.device('cpu'))
        inputs = inputs[:, 0:1, ...]
        inputs = inputs
        outputs = model(inputs)
        save_figures(model, inputs, torch.argmax(outputs, -1), filepath)
        break

    # run_inference(model, dataset)


if __name__ == '__main__':
    main()