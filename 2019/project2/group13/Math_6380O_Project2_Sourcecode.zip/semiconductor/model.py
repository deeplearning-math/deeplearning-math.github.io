import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import torchvision
from torchvision import datasets, models, transforms
from torch.utils.tensorboard import SummaryWriter
import torchsummary
import matplotlib.pyplot as plt
import datetime
import time
import os
import copy
import tqdm

# Top level data directory. Here we assume the format of the directory conforms
#   to the ImageFolder structure
data_dir = r"data"
log_dir = os.path.join('logs', (datetime.datetime.now().strftime('%m%d_%H%M')))
# data_dir = r'C:\Users\dy.octa\Store\semi-conductor-image-classification-first'

base_model = torchvision.models.densenet121

# Number of classes in the dataset
num_classes = 2

# Batch size for training (change depending on how much memory you have)
batch_size = 64

# Number of epochs to train for
num_epochs = 20
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def train_model(model, dataloaders, criterion, optimizer, num_epochs=25):
    os.makedirs(log_dir, exist_ok=True)
    since = time.time()
    tb_writer = SummaryWriter(log_dir)
    val_acc_history = []

    best_model_wts = copy.deepcopy(model.state_dict())
    best_f1 = 0.0
    torchsummary.summary(model, (1, 224, 224))

    for epoch in range(num_epochs):
        print('Epoch {}/{}'.format(epoch, num_epochs - 1))
        print('-' * 10)

        # Each epoch has a training and validation phase
        for phase in ['train', 'val']:
            if phase == 'train':
                model.train()  # Set model to training mode
            else:
                model.eval()  # Set model to evaluate mode

            running_loss = 0.0
            running_tp = running_tn = running_fp = running_fn = 0

            # Iterate over data.
            for (inputs, labels), filenames in tqdm.tqdm(dataloaders[phase]):
                inputs = inputs[:, 0:1, ...]
                inputs = inputs.to(device)
                labels = labels.to(device)

                # zero the parameter gradients
                optimizer.zero_grad()

                # forward
                # track history if only in train
                with torch.set_grad_enabled(phase == 'train'):
                    # Get model outputs and calculate loss
                    outputs = model(inputs)
                    loss = criterion(outputs, labels)
                    _, preds = torch.max(outputs, 1)

                    # backward + optimize only if in training phase
                    if phase == 'train':
                        loss.backward()
                        optimizer.step()

                # statistics
                running_loss += loss.item() * inputs.size(0)
                running_tp += torch.sum((preds == 1) & (labels.data == 1))
                running_fp += torch.sum((preds == 1) & (labels.data == 0))
                running_tn += torch.sum((preds == 0) & (labels.data == 0))
                running_fn += torch.sum((preds == 0) & (labels.data == 1))

            epoch_loss = running_loss / len(dataloaders[phase].dataset)
            epoch_precision = running_tp.double() / (running_tp + running_fp)
            epoch_recall = running_tp.double() / (running_tp + running_fn)
            epoch_acc = (running_tp + running_tn).double() / (running_tp + running_tn + running_fp + running_fn)
            epoch_f1 = 2 * epoch_precision * epoch_recall/ (epoch_precision + epoch_recall)

            print('%s: loss=%.4f, prec=%.4f, recall=%.4f, acc=%.4f, f1=%.4f' %(
                phase, epoch_loss, epoch_precision, epoch_recall, epoch_acc, epoch_f1
            ))
            names = ['loss', 'precision', 'recall', 'acc', 'f1']
            values = [epoch_loss, epoch_precision, epoch_recall, epoch_acc, epoch_f1]
            names = [phase + '/' + name for name in names]
            for name, value in zip(names, values):
                tb_writer.add_scalar(name, value, epoch)

            # deep copy the model
            if phase == 'val' and epoch_f1 > best_f1:
                best_f1 = epoch_f1
                best_model_wts = copy.deepcopy(model.state_dict())
            if phase == 'val':
                val_acc_history.append(epoch_f1)

        print()

    time_elapsed = time.time() - since
    print('Training complete in {:.0f}m {:.0f}s'.format(time_elapsed // 60, time_elapsed % 60))
    print('Best val f1: {:4f}'.format(best_f1))

    # load best model weights
    model.load_state_dict(best_model_wts)
    return model, val_acc_history


class ImageFolder(datasets.ImageFolder):
    def __getitem__(self, index):
        return super(ImageFolder, self).__getitem__(index), self.imgs[index]  # return image path

def build_data_loader(types=['train', 'val'], shuffle=True):
    # Data augmentation and normalization for training
    # Just normalization for validation
    normalizer = transforms.Normalize([0.2474], [0.1650])
    all_transforms = transforms.Compose([
        transforms.ToTensor(),
        normalizer,
        # transforms.Lambda(lambda t: t[..., 0]) # Pick only 1 channel
    ])
    print("Initializing Datasets and Dataloaders...")

    # Create training and validation datasets
    image_datasets = {x: ImageFolder(os.path.join(data_dir, x), all_transforms) for x in types}
    # Create training and validation dataloaders
    dataloaders_dict = {
        x: torch.utils.data.DataLoader(image_datasets[x], batch_size=batch_size, shuffle=shuffle, num_workers=4)
        for x in types}

    return image_datasets, dataloaders_dict


def build_optimizer(model_ft):
    # Send the model to GPU
    model_ft = model_ft.to(device)

    params_to_update = model_ft.parameters()
    # print("Params to learn:")
    # for name, param in model_ft.named_parameters():
    #     if param.requires_grad == True:
    #         print("\t", name)

    # Observe that all parameters are being optimized
    optimizer_ft = optim.SGD(params_to_update, lr=0.001, momentum=0.9)

    return optimizer_ft


def create_model(pretrained=True):
    model_ft = base_model(pretrained=pretrained)
    model_ft.features[0] = nn.Conv2d(1, 64, kernel_size=7, stride=2,
                                     padding=3, bias=False)
    model_ft.classifier = nn.Linear(1024, num_classes)
    return model_ft

def run():
    # Setup the loss fxn
    criterion = nn.CrossEntropyLoss()
    model_ft = create_model()

    image_datasets, dataloaders_dict = build_data_loader()
    optimizer_ft = build_optimizer(model_ft)

    # Train and evaluate
    model_ft, hist = train_model(model_ft, dataloaders_dict, criterion, optimizer_ft, num_epochs=num_epochs)

    torch.save(model_ft.state_dict(), os.path.join(log_dir, 'model.pt'))


if __name__ == '__main__':
    run()
