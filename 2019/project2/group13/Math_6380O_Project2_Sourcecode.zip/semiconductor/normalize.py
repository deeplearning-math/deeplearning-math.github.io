import os, glob, tqdm, random, shutil
from PIL import Image
import numpy as np
from matplotlib import pyplot as plt

data_path = r'C:\Users\dy.octa\Store\semi-conductor-image-classification-first\train'

images = []
for f in tqdm.tqdm(glob.iglob(os.path.join(data_path, '*', '*.jpg'))):
    img = Image.open(f)
    img.load()
    images.append(np.asarray(img) / 256)

# plt.imshow(images[0])
# plt.show()
images = np.asarray(images)
print(np.mean(images), np.var(images))

# out_path = r'C:\Users\dy.octa\Store\semi-conductor-image-classification-first\val'
# f_list = list(glob.iglob(os.path.join(data_path, 'bad_1', '*.jpg')))
# random.shuffle(f_list)
# f_list = f_list[:100]
# for f in f_list:
#     fname = os.path.split(f)[-1]
#     shutil.move(f, os.path.join(out_path, 'bad_1', fname))
#
# f_list = list(glob.iglob(os.path.join(data_path, 'good_0', '*.jpg')))
# random.shuffle(f_list)
# f_list = f_list[:900]
# for f in f_list:
#     fname = os.path.split(f)[-1]
#     shutil.move(f, os.path.join(out_path, 'good_0', fname))
#
