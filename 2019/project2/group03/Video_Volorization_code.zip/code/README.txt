## Requirement
Required python libraries:

```
tensorflow 1.2.0
OpenCV 3.4.2.16
```

Tested on Ubuntu 16.04 + Nvidia 1080Ti + Cuda 8.0 + cudnn 7.0


## Training

For the video dataset, please download the DAVIS dataset and generate the optical flow by PWC-Net by yourself. 

For the image dataset, please download the ImageNet dataset.

```
python main.py --model YOUR_MODEL_NAME --data_dir data
```

## Testing

```
python main.py --model ckpt_woflow --test_dir /PATH/TO/TEST_DIR
```
If you want to test your gray videos,please convert them to frames first.


