Use train.py to pre-train model and keep parameters.
Use retrain.py to train.
Use plot_mse.py to visualize.