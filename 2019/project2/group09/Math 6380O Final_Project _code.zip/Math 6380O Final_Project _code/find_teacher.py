import torch
import pickle
import os
from tensorboardX import SummaryWriter
import torch.nn as nn
from model import get_model,get_model_small,get_pairwise_model
from utils import get_sparsity
from torch.optim.lr_scheduler import MultiStepLR
import matplotlib.pyplot as plt
# torch.manual_seed(1)
using_pairwise_model=True
p_w=1.0
p_v=1.0
using_cuda=True
using_slbi=False
fix_train_set=False
save_init=False
n=2
number_sample=50 # multiply by batch_size
input_size=150
total_step=40000
batch_size=256

l1_lambda=0e-3


if using_slbi:
    from slbi_noconv import SLBI
    mu=100
    kappa=1
    lr=1e-1
    fc_lambda=0.008
    save_mask=True
elif l1_lambda==0.0 :
    momentum=0.9
    lr=1e-2
    weight_decay=1e-4
    nesterov=True
else:
    weight_decay=0.0
    momentum=0.0
    lr=1e-2
    nesterov=False

# setting names
if using_slbi:
    run_name="find_teacher_slbi_{}_{}_{}".format(kappa,mu,fc_lambda)
    if save_mask and not os.path.exists("masks/{}_{}/".format(run_name,n)):
        os.makedirs("masks/{}_{}/".format(run_name,n))
else:
    run_name="dev_find_teacher_weaker_wd1e-4"
    # run_name="lasso_1e-5"
save_filename="results/{}_{}".format(run_name,n)
tensorboard_name="tblogs/{}_{}".format(run_name,n)
writer = SummaryWriter(tensorboard_name)




# check conflict
assert not (l1_lambda!=0 and weight_decay!=0) # can only use l1 or weight decay
assert not (using_slbi and l1_lambda!=0)

if using_pairwise_model:
    with torch.no_grad():
        teacher,student=get_pairwise_model([input_size,60,10],[input_size,int(n*60),10],p_w=p_w,p_v=p_v)
else:
    teacher=get_model([input_size,60,10])
    student=get_model([input_size,int(n*60),10])

if save_init:
    teacher_student={
        "teacher":teacher.state_dict(),
        "student":student.state_dict(),
    }
    torch.save(teacher_student,"masks/{}_{}/init.t7".format(run_name,n))
# student=get_model_small([input_size,10])
if using_cuda:
    teacher.cuda()
    student.cuda()

loss_fn=nn.MSELoss(reduction='elementwise_mean')
if using_slbi:
    from utils import init_slbi
    optimizer=init_slbi(model=student,lr=lr,mu=mu,kappa=kappa,fc_lambda=fc_lambda,momentum=0.0)
    scheduler = MultiStepLR(optimizer, milestones=[35000], gamma=0.25)
else:
    optimizer = torch.optim.SGD(student.parameters(), lr=lr, momentum=momentum,nesterov=nesterov,weight_decay=weight_decay)
    scheduler = MultiStepLR(optimizer, milestones=[10000,15000,20000,25000,30000,35000], gamma=0.25)



with torch.no_grad():
    test_set=torch.rand([batch_size*10,input_size])
    if using_cuda:
        test_set=test_set.cuda()
    y_test=teacher(test_set)


results=[]
test_results=[]


for step in range(total_step):
    with torch.no_grad():
        x=torch.rand([batch_size,input_size])
        if using_cuda:
            x=x.cuda()
        y=teacher(x)
    optimizer.zero_grad()

    y_pred=student(x)
    loss=loss_fn(y_pred,y)
    if step%100==0:
        print(step,loss.item())
        writer.add_scalar("train_mse",loss.item(),global_step=step)
        # y_zero=torch.zeros_like(y)
        # print("baseline {}".format(loss_fn(y_zero,y)))

    results.append((step,loss.item()))
    # for name, param in student.named_parameters():
    #     print(param)
    if l1_lambda!=0:
        loss+=l1_lambda*sum([torch.sum(param.abs()) for name, param in student.named_parameters() ])
        if step%100==0:
            print(step,loss.item())
    loss.backward()
    optimizer.step()
    scheduler.step()
    if step%100==0:
        with torch.no_grad():
            y_pred_test=student(test_set)
            test_loss=loss_fn(y_pred_test,y_test)
            test_results.append((step,test_loss.item()))
        if using_slbi:
            # print([ i for i in optimizer.get_z_state_dict()])
            mask_dict=optimizer.generate_strong_mask_dict()
            total=0
            non_zeros=0
            # print(mask_dict)
            for key in mask_dict.keys():
                total+=mask_dict[key].numel()
                non_zeros+=mask_dict[key].sum()
            print(non_zeros)
            sparse_rate=1-(non_zeros/float(total))
            print(sparse_rate)
            writer.add_scalar("Sparse rate",sparse_rate,global_step=step)
            if step%1000==0 and save_mask:
                state={"mask":mask_dict,"non_zeros":non_zeros,"total":total}
                torch.save(state,"masks/{}_{}/{}.t7".format(run_name,n,step))
                pass
        if step%1000==0:# why in step 0 there is difference?
            # recode norm of W and V
            print("plot the norm!")
            student_dict=student.state_dict()
            # print(student_dict.keys())
            fig=plt.figure()
            v=student_dict["2.weight"]
            # print(v.shape)
            plt.plot(v.norm(dim=0).cpu().numpy())
            plt.ylim(0,0.3)
            # plt.show()
            writer.add_figure("V norm @iter {}".format(step), fig, global_step=step,close=True)
            


# weight cdf
check_lst=[1e2,1e1,1e0,1e-1,1e-2,1e-3,1e-4,1e-5,1e-6]
for i in range(len(check_lst)):
    zeros,total=get_sparsity(student,check_lst[i])
    print(check_lst[i],float(zeros)/float(total),zeros,total)
    writer.add_scalar("finalsparserate",float(zeros)/float(total),global_step=i)

if using_slbi:
    pass

writer.close()

with open(save_filename+"train"+".pkl","wb") as file:
    pickle.dump(results,file)

with open(save_filename+"test"+".pkl","wb") as file:
    pickle.dump(test_results,file)