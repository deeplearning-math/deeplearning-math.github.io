import pickle
import matplotlib.pyplot as plt
import numpy as np
names=[
    "results/lasso_1_train.pkl",
    "results/lasso_2_train.pkl",
    "results/lasso_4_train.pkl",
    "results/lasso_8_train.pkl",
]
fig_name="randomdata&testMSE"


fig=plt.figure()

for name in names:
    with open(name,"rb") as file:
        result=np.array(pickle.load(file))
        # print(np.min(result[:,1]))
        plt.plot(result[:,0],result[:,1],alpha=0.5,label=name)
    pass
# plt.yscale("log")
plt.legend(["1","2","4","8"])
plt.title(fig_name)
plt.xlabel("Iteration")
plt.ylabel("MSE")
plt.ylim(0)
plt.savefig(fig_name+".png")
# plt.show()

