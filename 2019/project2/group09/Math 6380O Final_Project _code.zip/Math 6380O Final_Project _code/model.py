import torch 
import torch.nn as nn




def get_model(layer_list):
    assert len(layer_list)==3
    model = nn.Sequential(
            nn.Linear(layer_list[0],layer_list[1]),
            nn.ReLU(),
            nn.Linear(layer_list[1],layer_list[2]),
            )
    return model

def get_model_small(layer_list):
    assert len(layer_list)==2
    model = nn.Sequential(
            nn.Linear(layer_list[0],layer_list[1]),
            )
    return model

def get_pairwise_model(layer_list_teacher=[10,20,30],layer_list_student=[10,40,30],p_w=1.0,p_v=1.0):
        teacher=get_model(layer_list_teacher)
        student=get_model(layer_list_student)

        teacher_dict=teacher.state_dict()
        student_dict=student.state_dict()

        print(teacher_dict.keys())
        # print(student_dict.keys())

        new_state_dict={}
        for key in teacher_dict.keys():
                if key=="0.weight":# process V
                        print("=======> processing W")
                        # print(key)
                        # print(teacher_dict[key].shape)
                        # print(student_dict[key].shape)
                        new_tensor=torch.zeros_like(student_dict[key])
                        teacher_shape=teacher_dict[key].shape
                        new_tensor[0:teacher_shape[0],0:teacher_shape[1]]=teacher_dict[key]
                        new_tensor=p_w*new_tensor+student_dict[key]
                        #column normalize
                        new_tensor=torch.nn.functional.normalize(new_tensor, p=2, dim=1)
                        # print(new_tensor.shape)
                        # print(new_tensor.norm(dim=1))
                        new_tensor=new_tensor*student_dict[key].norm(dim=1).mean()
                        # print(new_tensor.norm(dim=1))
                        # print(student_dict[key].norm(dim=1).mean())
                        new_state_dict[key]=new_tensor
                elif key=="2.weight":# process W
                        print("=======> processing V")
                        new_tensor=torch.zeros_like(student_dict[key])
                        teacher_shape=teacher_dict[key].shape
                        new_tensor[0:teacher_shape[0],0:teacher_shape[1]]=teacher_dict[key]
                        new_tensor=p_v*new_tensor+student_dict[key]
                        new_tensor=torch.nn.functional.normalize(new_tensor, p=2, dim=0)
                        new_tensor=new_tensor*student_dict[key].norm(dim=0).mean()
                        new_state_dict[key]=new_tensor
                elif key=="0.bias" or key=="2.bias":# process W bias
                        # print("=======> processing V")
                        new_tensor=torch.zeros_like(student_dict[key])
                        teacher_shape=teacher_dict[key].shape
                        new_tensor[0:teacher_shape[0]]=teacher_dict[key]
                        new_tensor=p_v*new_tensor+student_dict[key]
                        new_tensor=torch.nn.functional.normalize(new_tensor, p=2, dim=0)
                        new_tensor=new_tensor*student_dict[key].norm(dim=0).mean()
                        new_state_dict[key]=new_tensor
                else:
                        new_state_dict[key]=student_dict[key]
        
        student.load_state_dict(new_state_dict)
        return teacher,student



        

        pass

if __name__ =="__main__":
        get_pairwise_model()