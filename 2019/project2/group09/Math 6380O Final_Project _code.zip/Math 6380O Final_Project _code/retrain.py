import torch
import pickle
import os
from tensorboardX import SummaryWriter
import torch.nn as nn
from model import get_model
from utils import get_sparsity
import argparse
from torch.optim.lr_scheduler import MultiStepLR
torch.manual_seed(599)


parser = argparse.ArgumentParser(description='final project')
# Datasets
parser.add_argument('--n',default=1, type=int)
#parser.add_argument('--save_init', default=1, type=int)
parser.add_argument('--sparseratio', default=0.2, type=float)
parser.add_argument('--using_teacher', default=1, type=int)
parser.add_argument('--using_student', default=1, type=int)
parser.add_argument('--lr', default=1e-1, type=float)
parser.add_argument('--using_mask', default=0, type=int)
args = parser.parse_args()



#loadding mask
print("======> loading masks")
n=args.n
lr=args.lr
sparseratio=args.sparseratio
using_mask=args.using_mask
mask_name="SGD_BASELINE_WD0_mom0.9_nes_{}_{}".format(lr,n)
if using_mask==True:
    state=torch.load("C:\\Users\\Z\\Desktop\\small_teacher_network\\masks\\{}\\{}.t7".format(mask_name,sparseratio))
    mask=state["mask"]
else:
    state=torch.load("C:\\Users\\Z\\Desktop\\small_teacher_network\\masks\\{}\\random{}.t7".format(mask_name,sparseratio))
    mask=state['random_mask']
for key in mask.keys():
    mask[key]=mask[key].float()
    
print(state.keys())
print("loading mask from {} @ {} with sparsity {}".format(mask_name,n,state["sparseratio"]))


using_cuda=False
using_slbi=False
#using_init=True
using_teacher=args.using_teacher
using_student=args.using_student
using_mask=args.using_mask
lr=args.lr


if using_slbi:
    from slbi_noconv import SLBI
    mu=100
    kappa=1
    fc_lambda=0.1
    save_mask=True

# parameter setting
run_name="retrain_with_{}_{}_{}_lr{}_{}_{}".format('init_teacher'*using_teacher,'init_student'*using_student,'using_mask'*using_mask,lr,sparseratio,n)
save_filename="C:\\Users\\Z\\Desktop\\small_teacher_network\\results\\{}_{}".format(run_name,n)
tensorboard_name="tblogs/{}_{}".format(run_name,n)
writer = SummaryWriter(tensorboard_name)

fix_train_set=False
number_sample=50 # multiply by batch_size
input_size=150
total_step=40000  
batch_size=256

l1_lambda=0e-5
# l1_lambda=0

assert not (using_slbi and l1_lambda!=0)


teacher=get_model([input_size,60,10])
student=get_model([input_size,n*60,10])
#if using_init:
teacher_student=torch.load("C:\\Users\\Z\\Desktop\\small_teacher_network\\masks\\{}\\init.t7".format(mask_name))
#    teacher.load_state_dict(teacher_student["teacher"])
if using_teacher:
    teacher.load_state_dict(teacher_student["teacher"])
if using_student:
    student.load_state_dict(teacher_student["student"])

    
if using_cuda:
    teacher.cuda()
    student.cuda()
#apply mask
for name, param in student.named_parameters():
    # print(name)
    # print(name=="0.weight")
    if name in mask.keys():
#        print("here")
        if using_cuda:
            param.data.mul_(mask[name].cuda())
        else:
            param.data.mul_(mask[name])
print(mask.keys())


loss_fn=nn.MSELoss(reduction='elementwise_mean')
if using_slbi:
    from utils import init_slbi
    optimizer=init_slbi(model=student,lr=lr,mu=mu,kappa=kappa,fc_lambda=fc_lambda,momentum=0.0)
else:
    optimizer = torch.optim.SGD(student.parameters(), lr=lr, momentum=0.9,nesterov=True,weight_decay=0.0)

scheduler = MultiStepLR(optimizer, milestones=[10000,15000,20000,25000,30000,35000], gamma=0.25)

with torch.no_grad():
    test_set=torch.rand([batch_size*10,input_size])
    if using_cuda:
        test_set=test_set.cuda()
    y_test=teacher(test_set)


results=[]
test_results=[]


for step in range(total_step):
    with torch.no_grad():
        x=torch.rand([batch_size,input_size])
        if using_cuda:
            x=x.cuda()
        y=teacher(x)
    optimizer.zero_grad()

    y_pred=student(x)
    loss=loss_fn(y_pred,y)
    if step%100==0:
        print(step,loss.item())
        writer.add_scalar("train_mse",loss.item(),global_step=step)
    results.append((step,loss.item()))
    # for name, param in student.named_parameters():
    #     print(param)
    if l1_lambda!=0:
        loss+=l1_lambda*sum([torch.sum(param.abs()) for name, param in student.named_parameters() ])
        if step%100==0:
            print(step,loss.item())
    loss.backward()

    # setting zeros
    for k, m in student.named_parameters():
        # print(k, m)
        # print(k)
        if k in mask:
            # weight_copy = m.weight.data.abs().clone()
            # mask_mat = weight_copy.gt(0).float().cuda()
            if using_cuda:
                m.grad.data.mul_(mask[k].cuda())
            else:
                m.grad.data.mul_(mask[k])
    # assert 0
    optimizer.step()
    scheduler.step()

    if step%100==0:
        with torch.no_grad():
            y_pred_test=student(test_set)
            test_loss=loss_fn(y_pred_test,y_test)
            test_results.append((step,test_loss.item()))
        if using_slbi:
            # print([ i for i in optimizer.get_z_state_dict()])
            mask_dict=optimizer.generate_strong_mask_dict()
            total=0
            non_zeros=0
            # print(mask_dict)
            for key in mask_dict.keys():
                total+=mask_dict[key].numel()
                non_zeros+=mask_dict[key].sum()
            print(non_zeros)
            sparse_rate=1-(non_zeros/float(total))
            print(sparse_rate)
            writer.add_scalar("Sparse rate",sparse_rate,global_step=step)
            if step%1000==0 and save_mask:
                state={"mask":mask_dict,"non_zeros":non_zeros,"total":total}
                torch.save(state,"masks/{}_{}/{}.t7".format(run_name,n,step))
                pass


# weight cdf
check_lst=[1e2,1e1,1e0,1e-1,1e-2,1e-3,1e-4,1e-5,1e-6,0.0]
for i in range(len(check_lst)):
    zeros,total=get_sparsity(student,check_lst[i])
    print(check_lst[i],float(zeros)/float(total),zeros,total)
    writer.add_scalar("finalsparserate",float(zeros)/float(total),global_step=i)

if using_slbi:
    pass

writer.close()

student_net=student.state_dict(),
torch.save(student_net,"C:\\Users\\Z\\Desktop\\small_teacher_network\\masks\\{}\\student_net_{}_{}.t7".format(mask_name,"using_student"*using_student,sparseratio))

teacher_net=teacher.state_dict(),
torch.save(teacher_net,"C:\\Users\\Z\\Desktop\\small_teacher_network\\masks\\{}\\teacher_net_{}_{}.t7".format(mask_name,"using_student"*using_student,sparseratio))




with open(save_filename+"train"+".pkl","wb") as file:
    pickle.dump(results,file)

with open(save_filename+"test"+".pkl","wb") as file:
    pickle.dump(test_results,file)