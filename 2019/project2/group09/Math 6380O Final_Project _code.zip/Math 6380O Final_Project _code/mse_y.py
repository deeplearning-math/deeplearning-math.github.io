# -*- coding: utf-8 -*-
"""
Created on Sat Dec 14 15:19:39 2019

@author: Z
"""
import torch
import pickle as pkl
import os
from tensorboardX import SummaryWriter
import torch.nn as nn
import sys
sys.path
sys.path.append('C:\\Users\\Z\\Desktop\\small_teacher_network\\') 
from model import get_model
#from utils import get_sparsity
import argparse
from torch.optim.lr_scheduler import MultiStepLR
import argparse
from torch.optim.lr_scheduler import MultiStepLR
torch.manual_seed(1000)


parser = argparse.ArgumentParser(description='final project')
parser.add_argument('--sparseratio', default=0.2, type=float)
args = parser.parse_args()


sparseratio=0.8
n=10
lr=1e-1
using_teacher=0
using_student=1
using_mask=1


teacher=get_model([150,60,10])
student1=get_model([150,n*60,10])
student2=get_model([150,n*60,10])

mask_name="SGD_BASELINE_WD0_mom0.9_nes_{}_{}".format(lr,n)
student1_dict=torch.load("C:\\Users\\Z\\Desktop\\small_teacher_network\\masks\\{}\\student_net_{}_{}.t7".format(mask_name,"using_student"*using_student,sparseratio))
student2_dict=torch.load("C:\\Users\\Z\\Desktop\\small_teacher_network\\masks\\{}\\student_net_{}_{}.t7".format(mask_name,"using_student"*(1-using_student),sparseratio))
teacher_dict=torch.load("C:\\Users\\Z\\Desktop\\small_teacher_network\\masks\\{}\\teacher_net_{}_{}.t7".format(mask_name,"using_student"*(1-using_student),sparseratio))


teacher.load_state_dict(teacher_dict[0])
student1.load_state_dict(student1_dict[0])
student2.load_state_dict(student2_dict[0])
    
x=torch.rand([200,150])
y1=student1(x)  
y2=student2(x)
y=teacher(x)

  
loss_fn=nn.MSELoss(reduction='elementwise_mean',size_average=True)
print(loss_fn(y1,y2))
print(loss_fn(y,y2))
print(loss_fn(y1,y)) 
    
    
