import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from collections import OrderedDict
import pickle as pkl

def smooth(data,weight):
    scalar = data.values
    last = scalar[0]
    smoothed = []
    for point in scalar:
        smoothed_val = last * weight + (1 - weight) * point
        smoothed.append(smoothed_val)
        last = smoothed_val
    return smoothed


path="C:\\Users\\Z\\Desktop\\small_teacher_network\\results\\"

#random mask
file_dict=OrderedDict([
    ["random_sparseness",path+"retrain_with_init_teacher_init_student__lr0.1_0.8_1_1train.pkl",],     
    ["one_shot_pruning",path+"retrain_with_init_teacher_init_student_using_mask_lr0.1_0.8_1_1train.pkl",],
    ])
file_dict=OrderedDict([
    ["random_sparseness",path+"retrain_with_init_teacher_init_student__lr0.1_0.8_10_10train.pkl",],     
    ["one_shot_pruning",path+"retrain_with_init_teacher_init_student_using_mask_lr0.1_0.8_10_10train.pkl",],
    ])


plt.figure()
for run_name in file_dict.keys():
    with open(file_dict[run_name],"rb") as file:
        df=pd.DataFrame(pkl.load(file),columns=['step','mse']) 
    plt.plot(df["step"],smooth(df["mse"],0.9),label=run_name)
    pass
plt.title("Training process when lr=0.1,n=10")

plt.xlabel("Iteration")
plt.ylabel("MSE")
plt.ylim(0,0.005)
#plt.yscale("log")
plt.legend()
plt.show()




#sparse ratio

file_dict=OrderedDict([ 
    ["0.2 Sparsity",path+"retrain_with_init_teacher_init_student_using_mask_lr0.01_0.8_1_1train.pkl",],
    ["0.4 Sparsity",path+"retrain_with_init_teacher_init_student_using_mask_lr0.01_0.6_1_1train.pkl",],
    ["0.6 Sparsity",path+"retrain_with_init_teacher_init_student_using_mask_lr0.01_0.4_1_1train.pkl",],
    ["0.8 Sparsity",path+"retrain_with_init_teacher_init_student_using_mask_lr0.01_0.2_1_1train.pkl",],
    ["benchmark",path+"SGD_BASELINE_WD0_mom0.9_nes_0.01_1train.pkl",],
    ])

file_dict=OrderedDict([ 
    ["0.2 Sparsity",path+"retrain_with_init_teacher_init_student_using_mask_lr0.01_0.8_10_10train.pkl",],
    ["0.4 Sparsity",path+"retrain_with_init_teacher_init_student_using_mask_lr0.01_0.6_10_10train.pkl",],
    ["0.6 Sparsity",path+"retrain_with_init_teacher_init_student_using_mask_lr0.01_0.4_10_10train.pkl",],
    ["0.8 Sparsity",path+"retrain_with_init_teacher_init_student_using_mask_lr0.01_0.2_10_10train.pkl",],
    ["benchmark",path+"SGD_BASELINE_WD0_mom0.9_nes_0.01_10train.pkl",],
    ])


file_dict=OrderedDict([ 
    ["0.2 Sparsity",path+"retrain_with_init_teacher_init_student_using_mask_lr0.1_0.8_1_1train.pkl",],
    ["0.4 Sparsity",path+"retrain_with_init_teacher_init_student_using_mask_lr0.1_0.6_1_1train.pkl",],
    ["0.6 Sparsity",path+"retrain_with_init_teacher_init_student_using_mask_lr0.1_0.4_1_1train.pkl",],
    ["0.8 Sparsity",path+"retrain_with_init_teacher_init_student_using_mask_lr0.1_0.2_1_1train.pkl",],
    ["benchmark",path+"SGD_BASELINE_WD0_mom0.9_nes_0.1_1train.pkl",],
    ])

file_dict=OrderedDict([ 
    ["0.2 Sparsity",path+"retrain_with_init_teacher_init_student_using_mask_lr0.1_0.8_10_10train.pkl",],
    ["0.4 Sparsity",path+"retrain_with_init_teacher_init_student_using_mask_lr0.1_0.6_10_10train.pkl",],
    ["0.6 Sparsity",path+"retrain_with_init_teacher_init_student_using_mask_lr0.1_0.4_10_10train.pkl",],
    ["0.8 Sparsity",path+"retrain_with_init_teacher_init_student_using_mask_lr0.1_0.2_10_10train.pkl",],
    ["benchmark",path+"SGD_BASELINE_WD0_mom0.9_nes_0.1_10train.pkl",],
    ])
    
    
    
plt.figure()
for run_name in file_dict.keys():
    with open(file_dict[run_name],"rb") as file:
        df=pd.DataFrame(pkl.load(file),columns=['step','mse']) 
    plt.plot(df["step"],smooth(df["mse"],0.7),label=run_name,linewidth = 1)
    pass
plt.title("Training process when lr=0.1,n=10")
plt.xlabel("Iteration")
plt.ylabel("MSE")
#plt.ylim(0,0.007)
plt.yscale("log")
plt.legend()
plt.show()




# initialization
file_dict=OrderedDict([ 
    ["keep_teacher&student_net",path+"retrain_with_init_teacher_init_student_using_mask_lr0.01_0.8_1_1train.pkl",],
    ["keep_student_net",path+"retrain_with__init_student_using_mask_lr0.01_0.8_1_1train.pkl",],
    ["keep_teacher_net",path+"retrain_with_init_teacher__using_mask_lr0.01_0.8_1_1train.pkl",],
    ["keep_none",path+"retrain_with___using_mask_lr0.01_0.8_1_1train.pkl",],
    ["benchmark",path+"SGD_BASELINE_WD0_mom0.9_nes_0.01_1train.pkl",],
    ])

file_dict=OrderedDict([ 
    ["keep_teacher&student_net",path+"retrain_with_init_teacher_init_student_using_mask_lr0.01_0.8_10_10train.pkl",],
    ["keep_student_net",path+"retrain_with__init_student_using_mask_lr0.01_0.8_10_10train.pkl",],
    ["keep_teacher_net",path+"retrain_with_init_teacher__using_mask_lr0.01_0.8_10_10train.pkl",],
    ["keep_none",path+"retrain_with___using_mask_lr0.01_0.8_10_10train.pkl",],
    ["benchmark",path+"SGD_BASELINE_WD0_mom0.9_nes_0.01_10train.pkl",],
    ])
file_dict=OrderedDict([ 
    ["keep_teacher&student_net",path+"retrain_with_init_teacher_init_student_using_mask_lr0.1_0.8_1_1train.pkl",],
    ["keep_student_net",path+"retrain_with__init_student_using_mask_lr0.1_0.8_1_1train.pkl",],
    ["keep_teacher_net",path+"retrain_with_init_teacher__using_mask_lr0.1_0.8_1_1train.pkl",],
    ["keep_none",path+"retrain_with___using_mask_lr0.1_0.8_1_1train.pkl",],
    ["benchmark",path+"SGD_BASELINE_WD0_mom0.9_nes_0.1_1train.pkl",],
    ]) 
    
file_dict=OrderedDict([ 
    ["keep_teacher&student_net",path+"retrain_with_init_teacher_init_student_using_mask_lr0.1_0.8_10_10train.pkl",],
    ["keep_student_net",path+"retrain_with__init_student_using_mask_lr0.1_0.8_10_10train.pkl",],
    ["keep_teacher_net",path+"retrain_with_init_teacher__using_mask_lr0.1_0.8_10_10train.pkl",],
    ["keep_none",path+"retrain_with___using_mask_lr0.1_0.8_10_10train.pkl",],
    ["benchmark",path+"SGD_BASELINE_WD0_mom0.9_nes_0.1_10train.pkl",],
    ])
 
    
plt.figure()
for run_name in file_dict.keys():
    with open(file_dict[run_name],"rb") as file:
        df=pd.DataFrame(pkl.load(file),columns=['step','mse']) 
    plt.plot(df["step"],smooth(df["mse"],0.99),label=run_name,linewidth = 1)
    pass
plt.title("Training process when lr=0.1,n=10")
plt.xlabel("Iteration")
plt.ylabel("MSE")
plt.ylim(bottom=0.0003,top=0.001)
#plt.ylim(bottom=0.0001,top=0.01)
plt.yscale("log")
plt.legend()
plt.show()