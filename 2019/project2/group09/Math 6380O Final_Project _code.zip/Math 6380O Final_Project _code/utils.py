import torch
def get_sparsity(net,threshold=1e-4):
    zeros=0
    total=0
    for name , param in net.named_parameters():
        zeros+=torch.sum(param.data.abs()<=threshold)
        total+=param.data.numel()
    return zeros,total
    pass
from slbi_noconv import SLBI
def init_slbi(model,lr,mu,kappa,fc_lambda,momentum):
    name_list = []
    slbi_list = []
    for name, p in model.named_parameters():
        name_list.append(name)
        if 'bias' not in name:
            slbi_list.append(name)
        # print(name)
        # print(p.size())
    optimizer = SLBI(model.parameters(), lr=lr, weight_decay=0, momentum=momentum,\
    nesterov=False, mu=mu, kappa=kappa, fc_lambda=fc_lambda, conv_lambda=1, \
    bn_lambda=1)
    optimizer.assign_name(name_list)
    optimizer.initialize_slbi(slbi_list)
    return optimizer
    pass