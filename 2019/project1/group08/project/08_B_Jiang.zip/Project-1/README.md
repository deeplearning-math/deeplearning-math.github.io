# Project-1

Identification of Raphael’s paintings from the forgeries


## Run code

Copy paintings of Raphael or forgeries images into `Project1-Raphael` folder

Run notebook `Project1.ipynb`
