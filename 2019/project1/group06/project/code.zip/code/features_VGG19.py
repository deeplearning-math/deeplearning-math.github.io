import numpy as np
from numpy.random import RandomState

from keras.datasets import mnist
from keras.applications.vgg19 import VGG19
from keras.applications.vgg19 import preprocess_input
from keras.models import Model

import cv2

from sklearn.manifold import TSNE
from sklearn.linear_model import SGDClassifier

import matplotlib.pyplot as plt

(x_train, y_train), (x_test, y_test) = mnist.load_data()

prng = RandomState(42)
num = 5000
#Extract a subset of 5000 samples from MNIST training
random_permute=prng.permutation(np.arange(0,60000))[0:num]

x = np.zeros((num, 28, 28))
y = np.zeros(num)
for i in range(x.shape[0]):
  x[i] = x_train[random_permute[i]]
  y[i] = y_train[random_permute[i]]

def change_size(x):
  x_resize = np.zeros((x.shape[0], 224, 224))
  for i in range(x.shape[0]):
    x_resize[i] = cv2.resize(x[i], (224, 224))

  x_channel = x_resize[:,:,:,np.newaxis]
  x_final = np.concatenate( (x_channel,x_channel), axis=3 )
  x_final = np.concatenate( (x_final,x_channel), axis=3 )
  return x_final

base_model = VGG19(include_top=True,weights='imagenet')
model = Model(inputs=base_model.input, outputs=base_model.get_layer('fc2').output)

def get_features(x):
  x_input = change_size(x)
  x_pre = preprocess_input(x_input)
  features = model.predict(x_pre, batch_size = 8)
  return features

f_train = get_features(x)

def feature_visilization(features,labels):

    tsne = TSNE(n_components=2, init='pca', random_state=501)
    X_tsne = tsne.fit_transform(features)

    x_min, x_max = X_tsne.min(0), X_tsne.max(0)
    X_norm = (X_tsne - x_min) / (x_max - x_min)  # 归一化
    
    plt.figure()
    for i in range(len(X_norm)):
        #print(type(X_norm[i,0]))
        #print(X_norm[i,0])
        plt.text(float(X_norm[i, 0]), float(X_norm[i, 1]), str(int(labels[i])), color=plt.cm.Set3(int(labels[i])),
                 fontdict={'weight': 'bold', 'size': 9})
    plt.xticks([])
    plt.yticks([])
    plt.show()
    

feature_visilization(f_train,y)

clf = SGDClassifier(alpha=0.01, max_iter=20, fit_intercept=True)
clf.fit(f_train, y)

f_test = get_features(x_test)

clf.score(f_test, y_test)


'''
!free -m

!dd if=/dev/zero of=/var/swapfile bs=1024 count=2048k

!dd if=/dev/zero of=/var/swapfile bs=1G count=4

!free -m
'''