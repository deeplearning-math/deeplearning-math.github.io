MNIST.PY: extract the feature of MNIST dataset by the scattering net and use SVM to do classification
painting.PY: extract the feature of Raphael�s painting by VGG19 and use SVM to do classification
Visualize the features.PY: visualize the features by unsupervised learning methods