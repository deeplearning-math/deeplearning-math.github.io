import vgg19
#import mnist
import tensorflow as tf
import matplotlib.pyplot as plt
import numpy as np
#from PIL import Image
 
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
from sklearn.decomposition import PCA
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
import sklearn.metrics as skmetrics


#for i in range(27,28):
#    im=Image.open('./Raphael Project final copy/'+str(i)+'.tiff')
#    im = im.convert('RGB')
#    im.save('./Raphael Project final copy/jpg/'+str(i)+'.jpg')

#a=np.load('./PCA.npy')

train_images=tf.zeros([1,224,224,3],dtype=tf.float32)
print(train_images)
with tf.Session() as sess:
    print(train_images.eval().shape)
#train_images=tf.concat([train_images,img_resized], 0)
for i in range(1,29):
    img = tf.gfile.FastGFile('./Raphael Project final copy/jpg/'+str(i)+'.jpg', "rb").read()

#    img = tf.gfile.GFile('./Raphael Project final copy/jpg/1.jpg', "rb").read()
    with tf.Session() as sess:
        # 用ipeg格式将图像解码得到三维矩阵(png格式用decode_png)
        # 解码后得到结果为张量
        img_data = tf.image.decode_png(img)
        img_resized = tf.image.resize_images(img_data, [224, 224], method=0)
        test=tf.expand_dims(img_resized, 0)
        train_images=tf.concat([train_images,test],0)
        # 打印出得到的三维矩阵
        #print(img_data.eval().shape)
        print(img_resized.eval().shape)
        # 使用pyplot可视化得到的图像
        #plt.imshow(img_data.eval())
        plt.imshow(img_resized.eval()/255)
        #print(img_resized.eval())
        plt.axis('off')
        #plt.savefig('./Raphael Project final copy/1.jpg', dpi=1000)   
        plt.show()
        
train=train_images[1:29,:,:,]
#with tf.Session() as sess:
#    train2=train.eval()
#print( train2.shape)
#print(train1.shape)



#print(label)

vgg = vgg19.Vgg19()
vgg.build(train/255)

#with tf.Session() as sess:
#    print(train_images[0,:,:,:].eval())
    
#red, green, blue = tf.split(axis=3, num_or_size_splits=3, value=test)



#print(vgg.conv1_1)
#print(vgg.fc7)

#feature vector 
with tf.Session() as sess:
    train1=vgg.fc7.eval()
print(train1.shape)

#[28,150528]
#with tf.Session() as sess:
#    train2=train.eval()
#train1=train2.reshape(28,-1)

with tf.Session() as sess:
    X=vgg.conv3_1.eval()
    plt.imshow(X[0,:,:,0]/255,cmap=plt.cm.gray)
    plt.axis('off')
    plt.show()
print(X.shape)


#pca = PCA(n_components=3)
#pca.fit(X)
#newX=pca.transform(X)
#print(newX.shape)
#
#fig = plt.figure()
#ax = fig.gca(projection='3d')
#ax.scatter(newX[:, 0], newX[:, 1], newX[:, 2], c=label, cmap=cm.nipy_spectral)
#plt.show()

#SVM
#X_train, X_test, y_train, y_test = train_test_split(X, label, test_size=0.5, random_state=0)
X_train=train1[[1,2,3,4,5,7,8,10,11,12,13,14,15,16,17,18,20,21,23,26,27],:]
X_test=train1[[0,6,9,19,22,24,25],:]
y_train=np.array([0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,0,0,0,0,0])
y_test=np.array([0,0,0,0,0,0,0])
print(X_train.shape)
param_grid = {'C': [1, 1e2, 1e3, 5e3, 1e4, 5e4, 1e5], 'gamma': [1e-10, 1e-9, 1e-8, 1e-7, 1e-6, 1e-5, 0.0001, 0.0005, 0.001, 0.005, 0.01, 0.1]}
clf0 = GridSearchCV(SVC(kernel='rbf'), param_grid)
clf = clf0.fit(X_train, y_train)
print("Best estimator found by grid search : ", clf.best_estimator_)

y_pred = clf.predict(X_test)
print(y_pred)
print(y_test)
print('Accuracy score :', skmetrics.accuracy_score(y_pred, y_test))
print('Confusion matrix :', skmetrics.confusion_matrix(y_pred, y_test))

y_pred = clf.predict(X_train)
print('Accuracy score :', skmetrics.accuracy_score(y_pred, y_train))
print('Confusion matrix :', skmetrics.confusion_matrix(y_pred, y_train))


#train1=train1.reshape(28,-1)
pca = PCA(n_components=0.98)
pca.fit(train1)
newX=pca.transform(train1)
print(newX[:,0].shape)
print(pca.explained_variance_ratio_)
print(pca.explained_variance_)
print(pca.n_components_)

xValue = list(range(1, pca.n_components_+1))
yValue = pca.explained_variance_ratio_

plt.xlabel('n_components')
plt.ylabel('explained_variance_ratio')
plt.scatter(xValue, yValue, s=20, marker='o')
plt.xlim(0, 25)
plt.ylim(0, 1)
plt.show()
X=newX[:,0:2]
print(X.shape)

label=np.array([2,0,0,0,0,0,2,0,0,2,1,1,1,1,1,1,1,1,1,0,0,0,2,0,2,2,0,0])
plt.scatter(newX[:,0], newX[:,1], s=20, marker='o',c=label, cmap=cm.nipy_spectral)










