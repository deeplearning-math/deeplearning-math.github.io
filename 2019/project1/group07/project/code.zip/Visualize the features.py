# -*- coding: utf-8 -*-
"""
Created on Wed May 15 12:10:12 2019


# need to install pydiffmap package
You can refer to 
https://pydiffmap.readthedocs.io/en/master/


@author: KL
"""

from time import time
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter
from pydiffmap import diffusion_map as dm    # need to install pydiffmap package
from sklearn import manifold
from scipy.io import loadmat    # to load matlab data
import seaborn as sns
import pandas as pd
#Data proposessing
#X = loadmat("C:/Users/TW/Desktop/face.mat")   #Load data
#Y = X['Y']
#Y = np.reshape(Y,(10304, 33))
#Y = Y.T
#Y = np.float64(Y)    # take out the face data and reshape it for Diffusimap calculation 

Y = np.load("D:/LEI_files/LEI_COURE/vgg19features.npy")

n_points = 28
n_neighbors = 5
n_components = 2
fig = plt.figure(figsize=(15, 8))
plt.suptitle("Manifold Learning with %i points, %i neighbors"
             % (28, n_neighbors), fontsize=14)
label = np.array([0.5,1,1,1,1,1,0.5,1,1,0.5,0,0,0,0,0,0,0,0,0,0,1,1,0.5,1,0.5,0.5,1,1])

###############################################################################
#Diffusion map

t0 = time()
neighbor_params = {'n_jobs': -1, 'algorithm': 'ball_tree'}
mydmap = dm.DiffusionMap.from_sklearn(n_evecs=2, k=200, epsilon='bgh', alpha=1.0, neighbor_params=neighbor_params)
Y1 = mydmap.fit_transform(Y)
t1 = time()

print("Diffusion map: %.2g sec" % (t1 - t0))
ax = fig.add_subplot(141)
plt.scatter(Y1[:, 0], Y1[:, 1], cmap=plt.cm.Spectral)
plt.title("Diffusion map (%.2g sec)" % (t1 - t0))
ax.xaxis.set_major_formatter(NullFormatter())
ax.yaxis.set_major_formatter(NullFormatter())
plt.axis('tight')

# plot beautiful maps
Y1D = np.column_stack((Y1,label))
Y1D = pd.DataFrame({'first':Y1D[:, 0],'second':Y1D[:, 1],'Category':Y1D[:, 2]})
g =sns.scatterplot(x="first", y="second",
              hue="Category",
              palette=['red','orange','green'], legend='full',
              data=Y1D)
###############################################################################
#MDS
t0 = time()
mds = manifold.MDS(n_components, max_iter=2000, n_init=1)
Y2 = mds.fit_transform(Y)
t1 = time()
print("MDS: %.2g sec" % (t1 - t0))
ax = fig.add_subplot(142)
plt.scatter(Y2[:, 0], Y2[:, 1], cmap=plt.cm.Spectral)
plt.title("MDS (%.2g sec)" % (t1 - t0))
ax.xaxis.set_major_formatter(NullFormatter())
ax.yaxis.set_major_formatter(NullFormatter())
plt.axis('tight')

Y2D = np.column_stack((Y2,label))
Y2D = pd.DataFrame({'first':Y2D[:, 0],'second':Y2D[:, 1],'Category':Y2D[:, 2]})
g =sns.scatterplot(x="first", y="second",
              hue="Category",
              palette=['red','orange','green'], legend='full',
              data=Y2D)


###############################################################################
#Isomap
t0 = time()
Y3 = manifold.Isomap(n_neighbors, n_components).fit_transform(Y)
t1 = time()
print("Isomap: %.2g sec" % (t1 - t0))
ax = fig.add_subplot(143)
plt.scatter(Y3[:, 0], Y3[:, 1], cmap=plt.cm.Spectral)
plt.title("Isomap (%.2g sec)" % (t1 - t0))
ax.xaxis.set_major_formatter(NullFormatter())
ax.yaxis.set_major_formatter(NullFormatter())
plt.axis('tight')

Y3D = np.column_stack((Y3,label))
Y3D = pd.DataFrame({'first':Y3D[:, 0],'second':Y3D[:, 1],'Category':Y3D[:, 2]})
g =sns.scatterplot(x="first", y="second",
              hue="Category",
              palette=['red','orange','green'], legend='full',
              data=Y3D)

###############################################################################
# LLE
t0 = time()
Y4 = manifold.LocallyLinearEmbedding(n_neighbors, n_components,
                                    eigen_solver='auto',
                                    method='standard').fit_transform(Y)
t1 = time()
print("%s: %.2g sec" % ('standard', t1 - t0))
ax = fig.add_subplot(144)
plt.scatter(Y4[:, 0], Y4[:, 1], cmap=plt.cm.Spectral)
plt.title("%s (%.2g sec)" % ('LLE', t1 - t0))
ax.xaxis.set_major_formatter(NullFormatter())
ax.yaxis.set_major_formatter(NullFormatter())
plt.axis('tight')
plt.figure()

Y4D = np.column_stack((Y4,label))
Y4D = pd.DataFrame({'first':Y4D[:, 0],'second':Y4D[:, 1],'Category':Y4D[:, 2]})
g =sns.scatterplot(x="first", y="second",
              hue="Category",
              palette=['red','orange','green'], legend='full',
              data=Y4D)

###############################################################################
#Diffusion map
# Plot all the images according to the order from dmapsort
#sort the diffusion map by the first eigenvecor
Y1sort = np.argsort(Y1[:,0])
j=1
for i in Y1sort:
    t = Y[i].reshape(64, 64)
    plt.subplot(1,28,j,frameon=False)
    plt.imshow(t)
    j=j+1
    plt.axis('off')
plt.axis('off')
plt.figure()

Y1label = np.zeros((28,1))
for i in Y1sort:
    Y1label[i] = label[Y1sort[i]] 
Y1sortResult = np.column_stack((Y1sort,Y1label)).T

#MDS
plt.figure()
j=1
#sort the MDS by the first eigenvecor and display all the images
Y2sort = np.argsort(Y2[:,0])
plt.figure()
j=1
for i in Y2sort:
    t = Y[i].reshape(64, 64)
    plt.subplot(1,28,j,frameon=False)
    plt.imshow(t)
    j=j+1
    plt.axis('off')
plt.axis('off')
plt.figure()

Y2label = np.zeros((28,1))
for i in Y2sort:
    Y2label[i] = label[Y2sort[i]] 
Y2sortResult = np.column_stack((Y2sort,Y2label)).T
#sort the Isomap by the first eigenvecor and display the images
Y3sort = np.argsort(Y3[:,0])
plt.figure()
j=1
for i in Y3sort:
    t = Y[i].reshape(64, 64)
    plt.subplot(1,28,j,frameon=False)
    plt.imshow(t)
    j=j+1
    plt.axis('off')
plt.axis('off')
plt.figure()

Y3label = np.zeros((28,1))
for i in Y3sort:
    Y3label[i] = label[Y3sort[i]] 
Y3sortResult = np.column_stack((Y3sort,Y3label)).T
#sort the LLE by the first eigenvecor and display the images
Y4sort = np.argsort(Y4[:,0])
plt.figure()
j=1
for i in Y4sort:
    t = Y[i].reshape(64, 64)
    plt.subplot(1,28,j,frameon=False)
    plt.imshow(t)
    j=j+1
    plt.axis('off')
plt.axis('off')
plt.figure()

Y4label = np.zeros((28,1))
for i in Y4sort:
    Y4label[i] = label[Y4sort[i]] 
Y4sortResult = np.column_stack((Y4sort,Y4label)).T