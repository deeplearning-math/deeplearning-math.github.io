ResNet_SVM.ipynb
Extract features using ResNet, visualize and classify with SVM.

ScatNetFeature.py
Extract features using ScatNet.

ScatNetSVM.ipynb
classify with SVM on the features extracted.

ScatNet_VGG
use a VGG network instead of SVM for ScatNet features.