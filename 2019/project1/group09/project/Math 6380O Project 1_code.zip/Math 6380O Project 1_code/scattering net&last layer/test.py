import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
from sklearn import preprocessing
from scipy.signal import convolve2d
import os
import torch
from torch.utils.data.dataset import Dataset
from collections import OrderedDict
import torchvision.transforms as transforms

from load_data import *
import torch.optim
from torchvision import datasets, transforms
import torch.nn.functional as F
from kymatio import Scattering2D
import torch
import argparse
import kymatio.datasets as scattering_datasets
import torch.nn as nn

from utils import *

train_dict=OrderedDict([
        # '1. 185x354.TIF': 2,
        ('2. 202x216.TIF', 1),
        ('3. 272x369.TIF', 1),
        ('4. 363x189.tiff', 1),
        ('5. 379x281.tiff', 1),
        ('6. 197x168.tiff', 1),
        # '7. 243x413 .tiff': 2,
        ('8. 329x232.tif', 1),
        ('9. 279x187.tif', 1),
        # '10. 269x227.TIF': 2,
        ('11. 394x248.jpg', 0),
        ('12. 305x492.jpg', 0),
        ('13. 206x184.jpg', 0),
        ('14. 279x152.jpg', 0),
        ('15. 279x152.jpg', 0),
        ('16. 335x476.jpg', 0),
        ('17. 283x300.jpg', 0),
        ('18. 217x278.jpg', 0),
        ('19. 283x191.jpg', 0),
        # '20. 135x390.tif': 2,
        ('21. 203x258.jpg', 1),
        ('22. 257x375.jpg', 1),
        # '23. 84x68.tif': 2,
        ('24. 203x224.tif', 1),
        # '25. 156x115.tif': 2,
        # '26. 197x187.tif': 2,
        ('27. 278x419.tiff', 1),
        # '28. 267x264.TIF': 1
        ])

test_dict=OrderedDict([
        ('1. 185x354.TIF', 2),
        ('7. 243x413 .tiff', 2),
        ('10. 269x227.TIF', 2),
        ('20. 135x390.tif', 2),
        ('23. 84x68.tif', 2),
        ('25. 156x115.tif',2),
        ('26. 197x187.tif', 2),
        ])

    # train_loader,test_loader=cv_loader.gen_cv(i)

# train_dict={}
# test_dict={}

transform=transforms.Compose([
            transforms.RandomCrop((64,64)),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize((0.5,), (0.25,)),
        ])
        

train_dataset=CustomDataset(train_dict,transform)
train_loader = torch.utils.data.DataLoader(
        train_dataset,
        batch_size=100, shuffle=True,
        num_workers=4, pin_memory=True)
# TODO load one picture each time 



# train_loader,test_loader=cv_loader.gen_cv(i)# TODO
epochs=1500
K=417
lr=1e-3

scattering = Scattering2D(shape = (64, 64), J=4).cuda()

model = nn.Sequential(
    View(K, 4, 4),
    nn.BatchNorm2d(K),
    View(K * 4 * 4),
    nn.Linear(K * 4 * 4 ,128),
    nn.ReLU(),
    nn.Linear(128,2)
).cuda()
criterion = nn.CrossEntropyLoss().cuda()
optimizer = torch.optim.Adam(model.parameters(), lr=lr)

#train_code
top1 = AverageMeter()

for epoch in range(epochs):
    for i, (images, target) in enumerate(train_loader):
        images, target=images.cuda(), target.cuda()
        out=model(scattering(images))
        loss=criterion(out,target)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        train_accuracy=accuracy(out,target)[0]
        top1.update(train_accuracy.item(), len(target))
        print("epoch {} loss {:.6f} avg {:.6f} acc {:.3f}".format(epoch,loss.item(),top1.avg,train_accuracy.item()))
        if epoch%500==0:
            top1.reset()

print("here")
res_dict={}
print(test_dict)
for key in test_dict.keys():
    print(key)
    test_dict=OrderedDict([(key,1),])
    test_dataset=CustomDataset(test_dict,transform)
    test_loader = torch.utils.data.DataLoader(
        test_dataset,
        batch_size=1, shuffle=True,
        num_workers=1, pin_memory=True)
    # test code
    top1 = AverageMeter()
    test_sample=500
    model.eval()
    with torch.no_grad():
        for epoch in range(test_sample):
            for i, (images, target) in enumerate(test_loader):
                images, target=images.cuda(), target.cuda()
                out=model(scattering(images))
                train_accuracy=accuracy(out,target)[0]
                top1.update(train_accuracy.item(), len(target))
    res_dict[key]=top1.avg
print(res_dict)

