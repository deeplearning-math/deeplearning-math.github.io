import numpy as np 
import pickle as pkl
import random

with open("{}.pkl".format("default"),"rb") as file:
    train_set,test_set=pkl.load(file)

indexes=[i for i in range(len(test_set[1]))]
random.shuffle(indexes)

print(test_set[0].shape)
print(test_set[1].shape)

n_samples=1000

subset_x=test_set[0][indexes[0:n_samples],:]
subset_y=test_set[1][indexes[0:n_samples],:]

print(subset_x.shape)
print(subset_y.shape)

np.savetxt("metadata.tsv",subset_y,delimiter="\t")
np.savetxt("data.tsv",subset_x,delimiter="\t")