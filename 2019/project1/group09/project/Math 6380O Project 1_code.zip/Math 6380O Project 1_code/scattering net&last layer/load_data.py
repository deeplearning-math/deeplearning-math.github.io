import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
from sklearn import preprocessing
from scipy.signal import convolve2d
import os
import torch
from torch.utils.data.dataset import Dataset
from collections import OrderedDict
import torchvision.transforms as transforms





class CustomDataset(Dataset):
    def __init__(self,name2lable,transform):
        self.transform=transform
        self.datalist=[]
        for name in name2lable:
            self.datalist.append( (Image.open(r'./deeplearning_data/{}'.format(name)).convert('L'), name2lable[name]) ) 
        self.len=len(self.datalist)
    def __getitem__(self, index):
        image,label=self.datalist[index]
        return self.transform(image),label
    def __len__(self):
        return self.len

def get_dataloader(name2lable):
    transform=transforms.Compose([
                transforms.RandomCrop((64,64)),
                transforms.RandomHorizontalFlip(),
                transforms.ToTensor(),
                transforms.Normalize((0.5,), (0.25,)),
            ])

    train_dataset=CustomDataset(name2lable,transform)

    train_loader = torch.utils.data.DataLoader(
            train_dataset,
            batch_size=100, shuffle=True,
            num_workers=4, pin_memory=True)
    return train_loader

class crossvalidation():
    def __init__(self):

        name2lable=OrderedDict([
        # '1. 185x354.TIF': 2,
        ('2. 202x216.TIF', 1),
        ('3. 272x369.TIF', 1),
        ('4. 363x189.tiff', 1),
        ('5. 379x281.tiff', 1),
        ('6. 197x168.tiff', 1),
        # '7. 243x413 .tiff': 2,
        ('8. 329x232.tif', 1),
        ('9. 279x187.tif', 1),
        # '10. 269x227.TIF': 2,
        ('11. 394x248.jpg', 0),
        ('12. 305x492.jpg', 0),
        ('13. 206x184.jpg', 0),
        ('14. 279x152.jpg', 0),
        ('15. 279x152.jpg', 0),
        ('16. 335x476.jpg', 0),
        ('17. 283x300.jpg', 0),
        ('18. 217x278.jpg', 0),
        ('19. 283x191.jpg', 0),
        # '20. 135x390.tif': 2,
        ('21. 203x258.jpg', 1),
        ('22. 257x375.jpg', 1),
        # '23. 84x68.tif': 2,
        ('24. 203x224.tif', 1),
        # '25. 156x115.tif': 2,
        # '26. 197x187.tif': 2,
        ('27. 278x419.tiff', 1),
        # '28. 267x264.TIF': 1
        ])
        self.name2lable=name2lable
        self.index=0
        self.count=len(name2lable)
        pass

    def gen_cv(self,index):
        now=0
        train_dict=OrderedDict()
        test_dict=OrderedDict()
        for key in self.name2lable.keys():
            if now==index:
                test_dict[key]=self.name2lable[key]
            else:
                train_dict[key]=self.name2lable[key]
            now+=1
        print("train_image {} test_image {}".format(len(train_dict),len(test_dict)))
        assert len(test_dict)==1

        train_loader=get_dataloader(train_dict)
        test_loader=get_dataloader(test_dict)
        return train_loader,test_loader
