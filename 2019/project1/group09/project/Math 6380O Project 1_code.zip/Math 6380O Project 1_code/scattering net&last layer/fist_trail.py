import struct,os
import numpy as np
from sklearn.metrics import accuracy_score,classification_report
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
import matplotlib.pyplot as plt
import pickle

### data loading start ###
def loadfeature (file):
    fr=open(file,'rb')
    inf = pickle.load(fr)
    inf = np.array(inf)
    # print(np.shape(inf))
    return inf
### data loading end ###

#main
if __name__=="__main__":
    with open("{}.pkl".format("default"),"rb") as file:
        train_set,test_set=pickle.load(file)
    train_image,train_label=train_set
    test_image,test_label=test_set
    print(train_image.shape)

    # train_image = loadfeature('train_vgg_flatten.pkl')
    # train_label = loadfeature("train_vgg_label.pkl")
    # test_image = loadfeature("test_vgg_flatten.pkl")
    # test_label = loadfeature("test_vgg_label.pkl") #load data
    # ###random forest start###
    # rfc = RandomForestClassifier(n_estimators=100,n_jobs=8)
    # rfc.fit(train_image, train_label)
    # predict = rfc.predict(test_image)
    # print("accuracy_score: %.4lf" % accuracy_score(predict, test_label))
    # print("Classification report for classifier %s:\n%s\n" % (rfc, classification_report(test_label, predict)))
    # ###random forest end###

    ###logistic regression start###
    # lr = LogisticRegression()
    # lr.fit(train_image, train_label)
    # predict = lr.predict(test_image)
    # print("accuracy_score: %.4lf" % accuracy_score(predict, test_label))
    # print("Classification report for classifier %s:\n%s\n" % (lr, classification_report(test_label, predict)))
    ###logistic regression end###

    # ###SVM start###
    # svc = SVC()
    # svc.fit(train_image,train_label)
    # predict = svc.predict(test_image)
    # print("accuracy_score: %.4lf" % accuracy_score(predict,test_label))
    # print("Classification report for classifier %s:\n%s\n" % (svc, classification_report(test_label, predict)))
    # ###SVM end###

    ###LDA start###
    lda = LinearDiscriminantAnalysis()
    lda.fit(train_image, train_label)
    predict = lda.predict(test_image)
    print("accuracy_score: %.4lf" % accuracy_score(predict, test_label))
    print("Classification report for classifier %s:\n%s\n" % (lda, classification_report(test_label, predict)))
    ##LDA end###

