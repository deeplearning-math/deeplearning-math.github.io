import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
from sklearn import preprocessing
from scipy.signal import convolve2d
import os
import torch
from torch.utils.data.dataset import Dataset
from collections import OrderedDict
import torchvision.transforms as transforms

from load_data import *
import torch.optim
from torchvision import datasets, transforms
import torch.nn.functional as F
from kymatio import Scattering2D
import torch
import argparse
import kymatio.datasets as scattering_datasets
import torch.nn as nn

from utils import *

use_scattering=False

cv_res=[]

cv_loader=crossvalidation()
print(cv_loader.count)
for i in range(20):
    print("here!!!",i)
    # train_loader,test_loader=cv_loader.gen_cv(i)
    train_loader,test_loader=cv_loader.gen_cv(i)
    epochs=1500
    K=417
    lr=1e-3
    if use_scattering:
        scattering = Scattering2D(shape = (64, 64), J=4).cuda()
        model = nn.Sequential(
        View(K, 4, 4),
        nn.BatchNorm2d(K),
        View(K * 4 * 4),
        nn.Linear(K * 4 * 4 ,128),
        nn.ReLU(),
        nn.Linear(128,2)).cuda()
    else:
        scattering = nn.Sequential(
        nn.Conv2d(1,24,3,stride=2),
        nn.BatchNorm2d(24),
        nn.ReLU(),
        nn.Conv2d(24,64,3,stride=2),
        nn.BatchNorm2d(64),
        nn.ReLU(),
        nn.Conv2d(64,128,3,stride=1),
        nn.BatchNorm2d(128),
        nn.AvgPool2d(3)
        ).cuda()

        model = nn.Sequential(        
        View(128*4*4),
        nn.Linear(128*4*4 ,128),
        nn.ReLU(),
        nn.Linear(128,2)).cuda()

    criterion = nn.CrossEntropyLoss().cuda()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    #train_code
    top1 = AverageMeter()

    for epoch in range(epochs):
        for i, (images, target) in enumerate(train_loader):
            # print(target)
            images, target=images.cuda(), target.cuda()
            # print(scattering(images).shape)
            out=model(scattering(images))
            loss=criterion(out,target)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            train_accuracy=accuracy(out,target)[0]
            top1.update(train_accuracy.item(), len(target))
            print("epoch {} loss {:.6f} avg {:.6f} acc {:.3f}".format(epoch,loss.item(),top1.avg,train_accuracy.item()))
            if epoch%500==0:
                top1.reset()

    # test code
    top1 = AverageMeter()
    test_sample=500
    model.eval()
    with torch.no_grad():
        for epoch in range(test_sample):
            for i, (images, target) in enumerate(test_loader):
                images, target=images.cuda(), target.cuda()
                out=model(scattering(images))
                train_accuracy=accuracy(out,target)[0]
                top1.update(train_accuracy.item(), len(target))
                print("epoch {} loss {:.6f} avg {:.6f} acc {:.3f}".format(epoch,loss.item(),top1.avg,train_accuracy.item()))
                if epoch%500==0:
                    top1.reset()
    cv_res.append(top1)
print([i.avg for i in cv_res])

