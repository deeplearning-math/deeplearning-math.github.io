# -*- coding: utf-8 -*-
"""
Created on Tue Sep 24 16:01:25 2019

@author: Z
"""

import keras
import tensorflow as tf
import cv2 as cv
import numpy as np
import pickle as pkl
(x_train, y_train), (x_test, y_test) = keras.datasets.mnist.load_data()    #每次train,test data都是一样的


'''
import matplotlib.pyplot as plt
#%matplotlib inline # Only use this if using iPython
image_index = 7777 # You may select anything up to 60,000
print(y_train[image_index]) # The label is 8
plt.imshow(x_train[image_index], cmap='Greys')
'''

#x_train, y_train = x_train[:10000], y_train[:10000]
#x_test, y_test = x_test[:1000], y_test[:1000]


x_train = [cv.cvtColor(cv.resize(i, (32, 32)), cv.COLOR_GRAY2RGB)
           for i in x_train
           ]

x_train = np.concatenate([i[np.newaxis]
                          for i in x_train
                          ]).astype(np.float32)

x_test = [cv.cvtColor(cv.resize(i, (32,32)), cv.COLOR_GRAY2RGB)
          for i in x_test
          ]
x_test = np.concatenate([i[np.newaxis]
                         for i in x_test
                         ]).astype(np.float32)

x_train = x_train / 255
x_test = x_test / 255
print(x_train.shape, y_train.shape) 
print(x_test.shape, y_test.shape)  


from keras.applications.vgg19 import VGG19
from keras.applications.resnet import ResNet50
from keras.models import Model
import numpy as np
#############################     VGG
#with minibatches会不会快一点
base_model = VGG19(weights='imagenet', include_top=False,input_shape=(32,32, 3))
#model = Model(inputs=base_model.input, outputs=base_model.get_layer('block5_pool').output)

vgg_features =base_model.predict(x_train)
print(vgg_features.shape)

vgg_features2 = base_model.predict(x_test)
print(vgg_features2.shape)

with open("{}.pkl".format('C:/Users/Z/Desktop/train_vgg'),"wb") as file:
        pkl.dump(vgg_features,file)

with open("{}.pkl".format('C:/Users/Z/Desktop/train_vgg_label'),"wb") as file:
        pkl.dump(y_train,file)        

with open("{}.pkl".format('C:/Users/Z/Desktop/test_vgg'),"wb") as file:
        pkl.dump(vgg_features2,file)

with open("{}.pkl".format('C:/Users/Z/Desktop/test_vgg_label'),"wb") as file:
        pkl.dump(y_test,file)
        
########################### resnet
        
base_model2 = ResNet50(weights='imagenet', include_top=False,input_shape=(32, 32, 3)) 
model2 = ResNet50(weights='imagenet', pooling=max, include_top = False)     #不声明input_shape=(48, 48, 3)也可以直接用

#resnet_features = model2.predict(x_train[:100])#(100,2,2,2048)
resnet_features = base_model2.predict(x_train)
print(resnet_features.shape)

resnet_features2 = base_model2.predict(x_test)
print(resnet_features2.shape)

with open("{}.pkl".format('C:/Users/Z/Desktop/train_resnet'),"wb") as file:
        pkl.dump(resnet_features,file)

with open("{}.pkl".format('C:/Users/Z/Desktop/train_resnet_label'),"wb") as file:
        pkl.dump(y_train,file)        

with open("{}.pkl".format('C:/Users/Z/Desktop/test_resnet'),"wb") as file:
        pkl.dump(resnet_features2,file)

with open("{}.pkl".format('C:/Users/Z/Desktop/test_resnet_label'),"wb") as file:
        pkl.dump(y_test,file)        
        
        

with open("{}.pkl".format('C:/Users/Z/Desktop/pretrained/RESNET/train_resnet'),"rb") as file:
    test=pkl.load(file)
    vgg_train_flatten=np.array([i.flatten() for i in train_vgg ])
    
with open("{}.pkl".format('C:/Users/Z/Desktop/train_resnet_flatten'),"wb") as file:
        pkl.dump(test2,file)     
#with open("{}.csv".format('C:/Users/Z/Desktop/test_resnet_label'),"wb") as file:
#        pkl.dump(test,file) 

