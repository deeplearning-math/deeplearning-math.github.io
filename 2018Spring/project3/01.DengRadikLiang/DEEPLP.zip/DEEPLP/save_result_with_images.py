#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Apr 12 20:41:12 2018
# read the log and save two plots
@author: ddeng
"""
import numpy as np
import pdb

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import os
import sys

def read_log(file_path):
    # read log and return dictionary
    # epoch, lr, loss, accuracy
    data = {}
    with open(file_path, 'r') as file:
        for index, line in enumerate(file):
            if index ==0:
                keys = line.rstrip('\r\n').split(',')
                nums = len(keys)
                for key in keys:
                    data[key] = []
            else:
                numbers = line.rstrip('\r\n') .split(',')
                for i in range(nums):
                    data[keys[i]].append( float(numbers[i]))
    return data
            
def save_display( log_path, name):
    ##############################################
    
    data = read_log(log_path)
    epochs = data['iteration']
    lr = data['learning rate']
    test_loss = data['loss']
    test_acc = data['accuracy']
    
    # test_loss, test_acc vs epochs
    plt.figure(1)
    plt.plot(epochs, test_loss,'r-', epochs, test_acc, 'b-')
    
    red_patch = mpatches.Patch(color='red', label='Test_loss')
    blue_patch = mpatches.Patch(color='blue', label='Test_accuracy')
    plt.legend(handles=[red_patch, blue_patch])
    plt.xlabel('Epochs')
    plt.ylabel('loss or accuracy')
    plt.title('Loss and Accuracy on Test set vs Epochs')
    plt.savefig(name + '-.png')
    plt.show()
    
    
def main():
    pdb.set_trace()
    #log_path = '/home/ddeng/ram/logs/100x100_cluttered/100x100_cluttered_8_12x12_4_sgd_loss.log'
    #img_name = '100_cluttered_ram' 
    log_path = '/home/ddeng/ram/logs/100x100_cluttered_cnn/100x100_cnn_loss.log'
    img_name = '100_cluttered_cnn'    
    save_display(log_path, img_name)


if __name__ == '__main__':
    main()
