#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May 17 11:25:34 2018
convolution network
@author: ddeng
"""

import chainer
from chainer import Link, Chain
import chainer.functions as F
import chainer.links as L
import numpy as np

class SimpleCNN(Chain):
    
    def __init__(self, input_channel, output_channel, filter_height, filter_width, stride, pad, mid_units, n_units, n_label):
        super(SimpleCNN, self).__init__(
            conv1 = L.Convolution2D(input_channel, output_channel, (filter_height, filter_width), stride, pad ),
            l1    = L.Linear(mid_units, n_units),
            l2    = L.Linear(n_units,  n_label),
        )
    
    
    def __call__(self, x, t):
        h1 = F.max_pooling_2d(F.relu(self.conv1(x)), 3)
        h2 = F.dropout(F.relu(self.l1(h1)))
        y = self.l2(h2)
        self.loss = F.softmax_cross_entropy(y, t)
        self.accuracy = F.accuracy(y, t)
        return self.loss
    
    def forward(self, x, t):
        h1 = F.max_pooling_2d(F.relu(self.conv1(x)), 3)
        h2 = F.dropout(F.relu(self.l1(h1)))
        y = self.l2(h2)
        return F.softmax_cross_entropy(y, t), F.accuracy(y, t)
