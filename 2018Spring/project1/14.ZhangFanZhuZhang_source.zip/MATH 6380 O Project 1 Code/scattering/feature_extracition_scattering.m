%% Feature extraction vis scattering transform 
tic
clear
clc
%% ==== configuration ====

path = '/Users/proteusfan/Documents/MATLAB/Project_1';
chdir(path)
addpath(genpath(pwd))

%% ==== scattering transformation ====

for i = 1:28
    % read one painting
    read_name = strcat('pic',num2str(i-1),'.npy');
    data = readNPY(read_name);
    [num_sample, ~, ~, num_channel] = size(data);
    
    feature_cell = cell(num_sample,1);
    for ii = 1:num_sample
        temp_feature = [];
        for channel = 1:num_channel
            pic = squeeze(data(ii,:,:,channel))/256;
            % scattering options
            filt_opt.J = 5;
            filt_opt.L = 6;
            filt_opt.Q = 1;
            scat_opt.M = 3;
            scat_opt.oversampling = 1;
            [Wop, filters] = wavelet_factory_2d(size(pic));
%             display_filter_bank_2d(filters);
            % scattering transformation
            S = format_scat(scat(pic,Wop));
            temp_feature = [temp_feature, sum(sum(S,2),3)'];
            fprintf('Painting: %d/%d, sample: %d/%d, channel: %d/%d.\n',...
                i, 28, ii, num_sample, channel, num_channel);
        end
        feature_cell{ii} = temp_feature;
    end
    feature = cell2mat(feature_cell);
    save_name = strcat('pic',num2str(i-1),'.mat');
    save(fullfile(path, 'feature', save_name), 'feature');
    clear data
end

toc
    