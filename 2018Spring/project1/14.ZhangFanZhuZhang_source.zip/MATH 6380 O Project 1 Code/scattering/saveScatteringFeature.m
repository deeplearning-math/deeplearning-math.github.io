%% save features into one file

feature_cell = cell(28,1);

for i = 1:28
    read_name = strcat('pic',num2str(i-1),'.mat');
    load(read_name,'feature');
    feature_cell{i} = feature;
end