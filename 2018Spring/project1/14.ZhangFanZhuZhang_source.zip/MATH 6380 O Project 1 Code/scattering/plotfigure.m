clear
close all
%% data
data = readNPY('pic10.npy');

%% original figure
pic = squeeze(data(10,:,:,2))/256;
figure();
imagesc(pic);
title('Sample randomly picked');

%% scatter net
% scattering options
filt_opt.J = 5;
filt_opt.L = 6;
filt_opt.Q = 1;
scat_opt.M = 3;
scat_opt.oversampling = 1;
[Wop, filters] = wavelet_factory_2d(size(pic));

figure();
display_filter_bank_2d(filters);
legend('all the filters');

% scattering transformation
S = scat(pic,Wop);
figure();
image_scat(S, false, false);
legend('scattering coefficients');