#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Feb 26 11:55:38 2018

@author: proteusfan
"""

#%% load the data
#import scipy.io
import numpy as np

#data = scipy.io.loadmat('scatteringFeature.mat')
#data = data['feature_cell']
#
#featurePainting = [data[0,0]]
#featureSample = data[0,0]
#for iter in range(1,len(data)):
#    featurePainting.append(data[iter,0])
#    featureSample = np.concatenate([featureSample, data[iter,0]],axis = 0)
#
#labelPainting = np.array([0] + [1]*5 + [0] + [1]*2 + [0] + [-1]*9 +\
#        [0] + [1]*2 + [0] + [1] + [0]*2 + [1]*2)
#
#labelSample = np.repeat(labelPainting, 200)
#
#np.savez('scatteringFeatureLabel.npz', featurePainting = featurePainting,
#         featureSample = featureSample, labelPainting = labelPainting, 
#         labelSample = labelSample)

feature = np.load('scatteringFeatureLabel.npz')
featurePainting = feature['featurePainting']
featureSample = feature['featureSample']
labelPainting = feature['labelPainting']
labelSample = feature['labelSample']

indexPainting = np.logical_or(labelPainting == 1, labelPainting == -1)
indexSample = np.logical_or(labelSample == 1, labelSample == -1)

featurePaintingTF = featurePainting[indexPainting]
featureSampleTF = featureSample[indexSample]
labelPaintingTF = labelPainting[indexPainting]
labelSampleTF = labelSample[indexSample]

#%% Visualization
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt

pca = PCA(n_components = 10)
tsne = TSNE(n_components=2)

feature_rd = {}
feature_rd['pca'] = pca.fit_transform(featureSample)[:,2:4] # PCA-2 vs PCA-3
feature_rd['tsne'] = tsne.fit_transform(featureSample)

for method in ['pca', 'tsne']:
    plt.scatter(feature_rd[method][labelSample==1, 0], feature_rd[method][labelSample==1, 1], s=1, label = 'Raphael')
    plt.scatter(feature_rd[method][labelSample==-1, 0], feature_rd[method][labelSample==-1, 1], s=1, label = 'Not Raphael')
    plt.scatter(feature_rd[method][labelSample==0, 0], feature_rd[method][labelSample==0, 1], s=1, label = 'Not Known')
    plt.legend()
    plt.title(method)
    plt.show()
    
#%% Classification via SVM
from sklearn.model_selection import LeaveOneGroupOut
from sklearn.svm import SVC

## ==== classification without unknown ====
groups = np.repeat(range(21),200)
logo = LeaveOneGroupOut()

acc_loo = 0;
acc_sample_loo = 0;
for train_index, test_index in logo.split(featureSampleTF, labelSampleTF, groups):
    X_train, X_test = featureSampleTF[train_index], featureSampleTF[test_index]
    y_train, y_test = labelSampleTF[train_index], labelSampleTF[test_index]
    clf_TF = SVC(C=1.0, kernel = 'linear', degree = 2, decision_function_shape = 'ovo')
    clf_TF.fit(X_train, y_train)
    y_test_pred = clf_TF.predict(X_test)
    acc_sample_loo_temp = (y_test == y_test_pred).mean()
    acc_sample_loo += acc_sample_loo_temp
    acc_loo += acc_sample_loo_temp > 0.5
    print('sample accuracy in this iteration: %f.' % acc_sample_loo_temp)
acc_sample_loo /= 21;
acc_loo /= 21;

print('sample accuracy is %f, painting accuracy is %f.' % (acc_sample_loo, acc_loo))





