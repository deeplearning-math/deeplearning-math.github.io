import numpy as np
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import matplotlib.colors
import random
import scipy.io as spio

res_data = np.load('data/res-feat.npy')
vgg_data = np.load('data/vgg-feat.npy')
id_to_label = [-1, 1, 1, 1, 1, 1, -1, 1, 1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, 1, -1, 1, -1, -1, 1, 1]

all_samples = list()
all_labels = list()
colors=["red", "gold", "limegreen"]
pure_lables = list()


for sample in res_data:
    tmp_label = id_to_label[int(sample[-1])]
    if tmp_label > -1:
        all_samples.append(sample[:-1])
        all_labels.append(colors[id_to_label[int(sample[-1])]+1])
        pure_lables.append(int(sample[-1])+1)

PCA_model = PCA(n_components=2)
all_embedding = np.asarray(all_samples)
new_features = PCA_model.fit_transform(all_embedding)
first_feature = new_features[:, 0]
second_feature = new_features[:, 1]
plt.scatter(first_feature, second_feature, c=all_labels, s=2)
plt.savefig('PCA_res.png')

all_samples = list()
all_labels = list()
colors=["red", "gold", "limegreen"]
pure_lables = list()

for sample in vgg_data:
    tmp_label = id_to_label[int(sample[-1])]
    if tmp_label > -1:
        all_samples.append(sample[:-1])
        all_labels.append(colors[id_to_label[int(sample[-1])]+1])
        pure_lables.append(int(sample[-1])+1)

# colors=["red", "gold", "limegreen"]
# cmap = matplotlib.colors.ListedColormap(colors)
PCA_model = PCA(n_components=2)
all_embedding = np.asarray(all_samples)
new_features = PCA_model.fit_transform(all_embedding)
first_feature = new_features[:, 0]
second_feature = new_features[:, 1]
plt.scatter(first_feature, second_feature, c=all_labels, s=2)
plt.savefig('PCA_vgg.png')

scatter_samples = list()
scatter_labels = list()
for i in range(28):
    if id_to_label[i] < 0:
        continue
    f_name = 'data/feature/pic' + str(i) + '.mat'
    tmp_feature = spio.loadmat(f_name)['feature']
    for sample in tmp_feature:
        scatter_samples.append(sample)
        scatter_labels.append(colors[id_to_label[i]+1])
PCA_model = PCA(n_components=2)
all_embedding = np.asarray(scatter_samples)
new_features = PCA_model.fit_transform(all_embedding)
first_feature = new_features[:, 0]
second_feature = new_features[:, 1]
plt.scatter(first_feature, second_feature, c=scatter_labels, s=2)
plt.savefig('PCA_scatter.png')


print('end')
