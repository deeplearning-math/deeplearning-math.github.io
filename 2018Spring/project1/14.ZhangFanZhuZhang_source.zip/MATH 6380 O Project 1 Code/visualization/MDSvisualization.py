import numpy as np
from sklearn import manifold
import matplotlib.pyplot as plt
import matplotlib.colors
import random

res_data = np.load('data/res-feat.npy')
vgg_data = np.load('data/vgg-feat.npy')
id_to_label = [-1, 1, 1, 1, 1, 1, -1, 1, 1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, 1, -1, 1, -1, -1, 1, 1]


all_samples = list()
all_labels = list()
colors=["red", "gold", "limegreen"]
pure_lables = list()


for sample in res_data:
    # print(sample[-1])
    tmp_label = id_to_label[int(sample[-1])]
    if tmp_label > -1:
        all_samples.append(sample[:-1])
        all_labels.append(colors[id_to_label[int(sample[-1])]+1])
        pure_lables.append(int(sample[-1])+1)

MDS = manifold.MDS()
all_embedding = np.asarray(all_samples)
new_features = MDS.fit_transform(all_embedding)
first_feature = new_features[:, 0]
second_feature = new_features[:, 1]
plt.scatter(first_feature, second_feature, c=all_labels)
plt.savefig('MDS_res.png')

all_samples = list()
all_labels = list()
colors=["red", "gold", "limegreen"]
pure_lables = list()

for sample in vgg_data:
    tmp_label = id_to_label[int(sample[-1])]
    if tmp_label > -1:
        all_samples.append(sample[:-1])
        all_labels.append(colors[id_to_label[int(sample[-1])]+1])
        pure_lables.append(int(sample[-1])+1)

MDS = manifold.MDS()
all_embedding = np.asarray(all_samples)
new_features = MDS.fit_transform(all_embedding)
first_feature = new_features[:, 0]
second_feature = new_features[:, 1]
plt.scatter(first_feature, second_feature, c=all_labels)
plt.savefig('MDS_vgg.png')


print('end')
