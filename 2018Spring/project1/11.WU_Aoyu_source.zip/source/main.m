%% MATH 6380o. Deep Learning: Towards Deeper Understanding 
%% By WU Aoyu

clear
%% Environment Set
% ScatNet (http://www.di.ens.fr/data/software/scatnet/license/)
path('scatnet-0.2',path);
addpath_scatnet;

%% Data Load (http://ufldl.stanford.edu/wiki/index.php/Using_the_MNIST_Dataset)
TrainImages = loadMNISTImages('train-images-idx3-ubyte');
TrainLabels = loadMNISTLabels('train-labels-idx1-ubyte');
NTrain = length(TrainLabels);

TestImages = loadMNISTImages('t10k-images-idx3-ubyte');
TestLabels = loadMNISTLabels('t10k-labels-idx1-ubyte');
NTest = length(TestLabels);

%% Random Sample Data
% Training Data Size: 400
RandTrain = randperm(NTrain,400);
TrainImages = TrainImages(:,:,RandTrain);
TrainLabels = TrainLabels(RandTrain);

% Test Data Size: 100
RandTest = randperm(NTest,100);
TestImages = TestImages(:,:,RandTest);
TestLabels = TestLabels(RandTest);


%% Scattering Net
% Feature Extraction
ScatNetFeature = [];
for i = 1:length(TrainLabels)
    ScatNetFeature(i,:) = ExtractScatNet(getImageByIdx(TrainImages,i));
    if (mod(i,100)==0)
        fprintf('Scattering net feature extraction: %s. \n',i);
    end
end

% Visualize by tSNE
ScatNetY = tsne(ScatNetFeature);
figure;
gscatter(ScatNetY(:,1),ScatNetY(:,2),TrainLabels);

% Train
ScatNetModelSVM = fitcecoc(ScatNetFeature,TrainLabels);

% Test
runScatNetTest(TestImages,TestLabels,ScatNetModelSVM)

%% Transfer Learning: AlexNet
% 227 * 227 * 3 * N
TrainImagesResized = [];
for i = length(TrainLabels)
    resized = imresize(getImageByIdx(TrainImages,i),[227 227]);
    TrainImagesResized(:,:,:,i) = cat(3,resized,resized,resized);
end

for i = length(TestLabels)
    resized = imresize(getImageByIdx(TestImages,i),[227 227]);
    TestImagesResized(:,:,:,i) = cat(3,resized,resized,resized);
end

net = alexnet;
layer = 'fc7';
AlexFeature = activations(net,TrainImagesResized,layer);

% Visualize by tSNE
AlexY = tsne(AlexFeature);
figure;
gscatter(AlexY(:,1),AlexY(:,2),TrainLabels);

% Train
ScatNetModelSVM = fitcecoc(AlexFeature,TrainLabels);

% Test
runAlexTest(TestImages,TestLabels,net,layer,ScatNetModelSVM)
