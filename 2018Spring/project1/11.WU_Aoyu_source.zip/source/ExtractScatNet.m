function feature = ExtractScatNet(img)

% compute wavelet operators with factory
filt_opt.J = 3;
scat_opt.oversampling = 0;
Wop = wavelet_factory_2d(size(img), filt_opt, scat_opt);

feature = sum(sum(format_scat(scat(img,Wop)),2),3)';


end