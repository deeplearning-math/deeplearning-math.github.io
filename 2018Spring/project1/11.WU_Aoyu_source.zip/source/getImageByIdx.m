%% Helper function
% Get a single image by its idx 
function img = getImageByIdx(collection,idx)
    img = collection(:,:,idx);
end