function error = runScatNetTest(TestImages,TestLabels,Model)

count = 0;

for i = 1:length(TestLabels)
    
    feature = ExtractScatNet(getImageByIdx(TestImages,i));
    
    if predict(Model,feature) == TestLabels(i)
        count = count + 1;
    end
    
end

error = count/length(TestLabels);

end
