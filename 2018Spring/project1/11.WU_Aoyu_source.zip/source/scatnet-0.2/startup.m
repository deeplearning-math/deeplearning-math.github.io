addpath '/Users/Franches/Documents/MATLAB/MATH6380O/scatnet-0.2';
addpath_scatnet;