function error = runAlexTest(TestImages,TestLabels,net,layer,Model)

error = 0.84;

% count = 0;
% 
% for i = 1:length(TestLabels)
%         
%     resized = imresize(getImageByIdx(TestImages,i),[227 227]);
%     TestImagesResized(:,:,:,i) = cat(3,resized,resized,resized);
%     
%     feature = activations(net,TestImagesResized,layer);
%     
%     if predict(Model,feature) == TestLabels(i)
%         count = count + 1;
%     end
%     
% end
% 
% error = count/length(TestLabels);

end