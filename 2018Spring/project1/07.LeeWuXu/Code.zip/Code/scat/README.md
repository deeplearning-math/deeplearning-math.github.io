# tutorial_scat
# A Tutorial on using Scattering Transform of Image in Matlab

run tutorial.m
