% tutorial for image processing using 
% scattering toolbox 
% author : laurent sifre laurent.sifre@polytechnique.edu

%%
clear;
addpath('common')
addpath('combined')
addpath('display')
addpath('2d')
%%
%load an image
% name = 'Lena512';
X = load('../X.mat');
X_train = X.X_train;
X_test = X.X_test;

options.L = 1;

for i=1:1:length(X_train)
    x = double(X_train(i,:));
    x = reshape(x,28,28);
    [Sx,meta] = scatt(x, options);
    SX_train(:,:,i) = reshape(Sx, 1, []);
end
save(strcat('SX_train_176.mat'), 'SX_train');

for i=1:1:length(X_test)
    x = double(X_test(i,:));
    x = reshape(x,28,28);
    [Sx,meta] = scatt(x, options);
    SX_test(:,:,i) = reshape(Sx, 1, []);
end
save(strcat('SX_test_176.mat'), 'SX_test');