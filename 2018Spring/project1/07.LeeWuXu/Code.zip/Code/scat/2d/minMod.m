function y=minMod(a,b)
am=mod(a,b);
y=min(am,b-am);
